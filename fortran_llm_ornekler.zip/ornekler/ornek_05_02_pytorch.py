# Örnek 5.2: Üç matris çarpımı: ijk, jki ve matmul (PyTorch karşılığı)
import torch, time
torch.set_num_threads(1)
n = 512
A = torch.rand(n, n, dtype=torch.float64); B = torch.rand(n, n, dtype=torch.float64)
fl = 2.0 * n ** 3
def tm(fn):
    fn(); t0 = time.perf_counter(); r = fn(); return time.perf_counter() - t0, r
t1, C1 = tm(lambda: A @ B)
t2, C2 = tm(lambda: torch.einsum('ik,kj->ij', A, B))
print(f"A @ B (BLAS)   : {t1:7.3f} s  {fl / t1 / 1e9:7.2f} GFLOP/s")
print(f"einsum         : {t2:7.3f} s  {fl / t2 / 1e9:7.2f} GFLOP/s")
m = 64                                           # Python ucuz dongusu: yalniz 64x64
a, b = A[:m, :m].tolist(), B[:m, :m].tolist()
t0 = time.perf_counter()
c = [[sum(a[i][k] * b[k][j] for k in range(m)) for j in range(m)] for i in range(m)]
tp = time.perf_counter() - t0
print(f"saf Python (n={m}) : {tp:7.3f} s  {2.0 * m ** 3 / tp / 1e9:7.4f} GFLOP/s   (kutuphane degil!)")
print("max |A@B - einsum| =", (C1 - C2).abs().max().item())

