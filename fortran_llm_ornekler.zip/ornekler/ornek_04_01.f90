! Örnek 4.1: Embedding araması ve sinüs konum kodlaması
! Derleme: gfortran -O2  ornek_04_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program embed_pe
  use rng_mod
  implicit none
  integer, parameter :: V = 5, d = 4, T = 3
  real(dp) :: E(V,d), PE(0:3,d), X(T,d), freq
  integer :: ids(T), pos, i, t1
  call rng_seed(5)
  call randn2(E, 1.0_dp)
  do pos = 0, 3
    do i = 0, d/2 - 1
      freq = 1.0_dp / 10000.0_dp**(2.0_dp*i/d)
      PE(pos, 2*i+1) = sin(pos * freq)        ! 1 tabanli: 2i+1 -> sin
      PE(pos, 2*i+2) = cos(pos * freq)        !            2i+2 -> cos
    end do
  end do
  print '(A)', 'Konum kodlamasi PE(pos, :) :'
  do pos = 0, 3
    print '(A,I1,A,4F9.5)', 'pos=', pos, '  ', PE(pos,:)
  end do
  ids = [3, 5, 2]
  do t1 = 1, T
    X(t1,:) = E(ids(t1),:) + PE(t1-1,:)       ! embedding arama + konum
  end do
  print '(A)', 'Girdi matrisi X = E[ids] + PE (T x d):'
  do t1 = 1, T
    print '(4F10.5)', X(t1,:)
  end do
end program embed_pe
