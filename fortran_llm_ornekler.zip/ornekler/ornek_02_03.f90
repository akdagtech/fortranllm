! Örnek 2.3: Tek nöronda ileri ve geri geçiş (elle)
! Derleme: gfortran -O2  ornek_02_03.f90 -o ornek
program noron
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x, w, b, t, z, y, dLdy, dydz, dLdz, dw, db, h, dw_n, db_n
  x = 1.5_dp; w = 0.8_dp; b = -0.3_dp; t = 1.0_dp; h = 1.0e-6_dp
  ! ileri gecis
  z = w*x + b
  y = 1.0_dp / (1.0_dp + exp(-z))
  print '(A,F10.6,A,F10.6,A,F10.6)', 'z=', z, '  y=', y, '  L=', 0.5_dp*(y-t)**2
  ! geri gecis
  dLdy = y - t
  dydz = y * (1.0_dp - y)
  dLdz = dLdy * dydz
  dw = dLdz * x
  db = dLdz
  ! sayisal kontrol
  dw_n = (loss(w+h, b) - loss(w-h, b)) / (2*h)
  db_n = (loss(w, b+h) - loss(w, b-h)) / (2*h)
  print '(A,2F14.9)', 'dL/dw (geri yayilim, sayisal): ', dw, dw_n
  print '(A,2F14.9)', 'dL/db (geri yayilim, sayisal): ', db, db_n
contains
  function loss(ww, bb) result(l)
    real(dp), intent(in) :: ww, bb
    real(dp) :: l, yy
    yy = 1.0_dp / (1.0_dp + exp(-(ww*x + bb)))
    l = 0.5_dp * (yy - t)**2
  end function loss
end program noron
