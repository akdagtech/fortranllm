# Örnek 8.1: Sonraki token kaybı ve perplexity (elle) (PyTorch karşılığı)
import torch, math
import torch.nn.functional as F
p = torch.tensor([0.5, 0.25, 0.1, 0.8], dtype=torch.float64)
for t, v in enumerate(p, 1):
    print(f"adim {t}  P(dogru token)={v:5.2f}  -log P = {-torch.log(v):8.4f}")
logits = torch.log(p)[:, None]                        # her adim icin tek-sinifli logit: ayni olasilik
loss = -torch.log(p).sum()
print(f"toplam kayip      = {loss:8.4f}")
print(f"ortalama kayip    = {loss / 4:8.4f}")
print(f"perplexity        = {torch.exp(loss / 4):8.4f}")
print(f"V=50000 rastgele: kayip={math.log(50000):8.4f}  PPL={50000.0:9.1f}")

