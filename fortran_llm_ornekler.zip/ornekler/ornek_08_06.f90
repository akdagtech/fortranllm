! Örnek 8.6: Checkpoint ile devam: tam eşdeğerlik
! Derleme: gfortran -O2  ornek_08_06.f90 -o ornek
program ckpt_devam
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x(8), y(8), pA(2), pB(2), pC(2), p(2), m(2), v(2)
  integer :: step
  x = [0.5_dp, 1.0_dp, 1.5_dp, 2.0_dp, 2.5_dp, 3.0_dp, 3.5_dp, 4.0_dp]
  y = [1.2_dp, 1.9_dp, 3.1_dp, 3.8_dp, 5.2_dp, 5.9_dp, 7.1_dp, 7.8_dp]
  ! (A) kesintisiz 100 adim
  p = 0.0_dp; m = 0.0_dp; v = 0.0_dp; step = 0
  call train(p, m, v, step, 100); pA = p
  ! (B) 50 adim, kaydet, bellegi sil, yukle, 50 adim
  p = 0.0_dp; m = 0.0_dp; v = 0.0_dp; step = 0
  call train(p, m, v, step, 50)
  call save_state('ckpt.bin', p, m, v, step)
  p = -999.0_dp; m = -999.0_dp; v = -999.0_dp; step = -1      ! "program coktu"
  call load_state('ckpt.bin', p, m, v, step)
  call train(p, m, v, step, 50); pB = p
  ! (C) yalniz parametreleri yukle, optimizer durumunu sifirla
  p = 0.0_dp; m = 0.0_dp; v = 0.0_dp; step = 0
  call train(p, m, v, step, 50)
  m = 0.0_dp; v = 0.0_dp; step = 0                            ! optimizer durumu kayboldu
  call train(p, m, v, step, 50); pC = p
  print '(A,2F14.10)', '(A) kesintisiz          : ', pA
  print '(A,2F14.10)', '(B) tam durumla devam   : ', pB
  print '(A,2F14.10)', '(C) yalniz agirliklar   : ', pC
  print '(A,ES10.2)', '|A - B| = ', maxval(abs(pA - pB))
  print '(A,ES10.2)', '|A - C| = ', maxval(abs(pA - pC))
contains
  subroutine train(p, m, v, step, k)                 ! k adim Adam
    real(dp), intent(inout) :: p(2), m(2), v(2)
    integer, intent(inout) :: step
    integer, intent(in) :: k
    real(dp) :: g(2), mh(2), vh(2)
    real(dp), parameter :: lr = 0.05_dp, b1 = 0.9_dp, b2 = 0.999_dp, eps = 1.0e-8_dp
    integer :: it
    do it = 1, k
      step = step + 1
      g(1) = sum(2.0_dp * (p(1)*x + p(2) - y) * x) / 8
      g(2) = sum(2.0_dp * (p(1)*x + p(2) - y)) / 8
      m = b1*m + (1.0_dp - b1)*g
      v = b2*v + (1.0_dp - b2)*g**2
      mh = m / (1.0_dp - b1**step)
      vh = v / (1.0_dp - b2**step)
      p = p - lr * mh / (sqrt(vh) + eps)
    end do
  end subroutine train

  subroutine save_state(fn, p, m, v, step)
    character(len=*), intent(in) :: fn
    real(dp), intent(in) :: p(2), m(2), v(2)
    integer, intent(in) :: step
    integer :: u
    open(newunit=u, file=fn, access='stream', form='unformatted', status='replace')
    write(u) step, p, m, v
    close(u)
  end subroutine save_state

  subroutine load_state(fn, p, m, v, step)
    character(len=*), intent(in) :: fn
    real(dp), intent(out) :: p(2), m(2), v(2)
    integer, intent(out) :: step
    integer :: u
    open(newunit=u, file=fn, access='stream', form='unformatted', status='old')
    read(u) step, p, m, v
    close(u)
  end subroutine load_state
end program ckpt_devam
