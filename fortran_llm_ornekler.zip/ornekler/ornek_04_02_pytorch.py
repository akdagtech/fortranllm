# Örnek 4.2: Tek bir query için attention (elle hesap) (PyTorch karşılığı)
import torch, math
import torch.nn.functional as F
q = torch.tensor([1., 0.])
K = torch.tensor([[1., 0], [0, 1], [1, 1]]); V = K.clone()
s = K @ q / math.sqrt(2)                   # olcekli skorlar
w = torch.softmax(s, 0); o = w @ V
print("skorlar    =", [round(v, 4) for v in s.tolist()])
print("agirliklar =", [round(v, 4) for v in w.tolist()])
print("cikti      =", [round(v, 4) for v in o.tolist()])
ref = F.scaled_dot_product_attention(q[None, None, :], K[None], V[None])   # hazir fonksiyon
print("F.scaled_dot_product_attention =", [round(v, 4) for v in ref.flatten().tolist()])

