! Örnek 9.2: Bellek hesaplayıcısı: 1.5B, 7B, 13B, 70B
! Derleme: gfortran -O2  ornek_09_02.f90 -o ornek
program bellek
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: n(4), gb
  integer :: i
  n = [1.5e9_dp, 7.0e9_dp, 13.0e9_dp, 70.0e9_dp]
  gb = 1.0e9_dp
  print '(A)', '  model   FP32-agirlik  egitim(16B)  FP16-infer  INT8   INT4   min GPU(80GB)'
  do i = 1, 4
    print '(F6.1,A,F9.1,A,F12.1,A,F10.1,A,F7.1,F7.1,I9)', n(i)/gb, 'B', 4*n(i)/gb, ' GB', &
          16*n(i)/gb, ' GB', 2*n(i)/gb, ' GB', n(i)/gb, 0.5_dp*n(i)/gb, &
          ceiling(16*n(i)/gb/80.0_dp)
  end do
end program bellek
