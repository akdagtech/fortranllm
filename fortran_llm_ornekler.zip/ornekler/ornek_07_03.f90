! Örnek 7.3: Birebir tekrarları hash ile bul
! Derleme: gfortran -O2  ornek_07_03.f90 -o ornek
program dedup_tam
  implicit none
  integer, parameter :: nd = 6, w = 40
  character(len=w) :: docs(nd), nrm(nd)
  integer(8) :: h(nd)
  integer :: i, j, nuniq
  logical :: dup(nd)
  docs(1) = 'Bugun hava cok guzel.'
  docs(2) = 'Yarin yagmur yagacak.'
  docs(3) = 'BUGUN   hava  cok guzel.'          ! 1'in kopyasi (farkli yazim)
  docs(4) = 'Model egitimi icin veri gerekir.'
  docs(5) = 'yarin yagmur yagacak.'             ! 2'nin kopyasi
  docs(6) = 'Bugun hava cok kotu.'              ! yakin ama kopya degil
  do i = 1, nd
    nrm(i) = normalize(docs(i))
    h(i) = hash(nrm(i))
  end do
  dup = .false.
  do i = 1, nd
    do j = i+1, nd
      if (h(i) == h(j) .and. nrm(i) == nrm(j) .and. .not. dup(j)) then
        dup(j) = .true.
        print '(A,I0,A,I0,A,I0)', 'belge ', j, ' = belge ', i, ' kopyasi   hash=', h(i)
      end if
    end do
  end do
  nuniq = count(.not. dup)
  print '(A,I0,A,I0)', 'toplam ', nd, ' belge, tekil ', nuniq
contains
  function normalize(x) result(r)                  ! kucuk harf + tek bosluk
    character(len=*), intent(in) :: x
    character(len=len(x)) :: r
    integer :: i, c, k
    logical :: prev_sp
    r = ' '; k = 0; prev_sp = .true.
    do i = 1, len_trim(x)
      c = ichar(x(i:i))
      if (c >= 65 .and. c <= 90) c = c + 32
      if (c == 32) then
        if (prev_sp) cycle
        prev_sp = .true.
      else
        prev_sp = .false.
      end if
      k = k + 1; r(k:k) = char(c)
    end do
  end function normalize

  function hash(x) result(hh)                      ! polinom hash (mod asal)
    character(len=*), intent(in) :: x
    integer(8) :: hh
    integer :: i
    hh = 7_8
    do i = 1, len_trim(x)
      hh = mod(hh * 131_8 + ichar(x(i:i)), 1000000007_8)
    end do
  end function hash
end program dedup_tam
