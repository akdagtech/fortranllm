# Örnek 4.3: Causal self-attention matrisi (PyTorch karşılığı)
import torch, math
import torch.nn.functional as F
X = torch.tensor([[1., 0], [0, 1], [1, 1], [0.5, -0.5]])
T_, d = X.shape
S = X @ X.T / math.sqrt(d)
mask = torch.triu(torch.ones(T_, T_, dtype=torch.bool), diagonal=1)   # gelecegi maskele
A = torch.softmax(S.masked_fill(mask, float('-inf')), dim=-1)
O = A @ X
print("Attention agirliklari A:")
for i in range(T_):
    print(" ".join(f"{v:9.4f}" for v in A[i]), f"   satir toplami = {A[i].sum():.4f}")
print("Cikti O = A V:"); print(O)
ref = F.scaled_dot_product_attention(X[None], X[None], X[None], is_causal=True)[0]
print("SDPA(is_causal=True) ile fark:", (ref - O).abs().max().item())

