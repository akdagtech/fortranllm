! Örnek 1.7: Gradyan inişi: tek boyutta
! Derleme: gfortran -O2  ornek_01_07.f90 -o ornek
program gd1d
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x, lr, grad
  integer :: k
  x = 0.0_dp
  lr = 0.1_dp
  do k = 0, 10
    grad = 2.0_dp * (x - 3.0_dp)
    print '(A,I3,A,F9.5,A,F9.5)', 'adim ', k, '  x = ', x, '  f(x) = ', (x-3.0_dp)**2 + 1.0_dp
    x = x - lr * grad
  end do
end program gd1d
