! Örnek 12.4: Varyasyonel minimizasyon: gradyan inişi ile H ve He
! Derleme: gfortran -O2  ornek_12_04.f90 -o ornek
program varyasyonel
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer, parameter :: n = 20000
  real(dp), parameter :: pi = 3.141592653589793_dp
  real(dp) :: r(n), psi(n), dpsi(n), h, alpha, norm, tkin, vpot, zeta, g, lr
  integer :: i, it
  h = 40.0_dp / n
  do i = 1, n
    r(i) = i * h
  end do
  alpha = 1.3_dp
  psi = exp(-alpha * r); dpsi = -alpha * psi
  norm = sum(4*pi*r**2 * psi**2) * h
  tkin = 0.5_dp * sum(4*pi*r**2 * dpsi**2) * h / norm        ! <T> = 1/2 <grad psi|grad psi>
  vpot = -sum(4*pi*r * psi**2) * h / norm                    ! <V> = -<1/r>
  print '(A,F8.4)', '(a) alpha = ', alpha
  print '(A,F10.6,A,F10.6)', '    <T> sayisal = ', tkin, '   alpha^2/2 = ', alpha**2/2
  print '(A,F10.6,A,F10.6)', '    <V> sayisal = ', vpot, '   -alpha     = ', -alpha
  ! (b) gradyan inisi: E(alpha) = alpha^2/2 - alpha
  alpha = 0.3_dp; lr = 0.4_dp
  print '(A)', '(b) H atomu, gradyan inisi:'
  do it = 0, 10
    g = (eh(alpha + 1.0e-6_dp) - eh(alpha - 1.0e-6_dp)) / 2.0e-6_dp
    if (it <= 4 .or. it == 10) print '(A,I3,A,F9.5,A,F10.6)', '    adim', it, '  alpha=', alpha, '  E=', eh(alpha)
    alpha = alpha - lr * g
  end do
  zeta = 0.5_dp; lr = 0.3_dp
  print '(A)', '    He atomu, gradyan inisi:'
  do it = 0, 40
    g = (ehe(zeta + 1.0e-6_dp) - ehe(zeta - 1.0e-6_dp)) / 2.0e-6_dp
    if (it <= 3 .or. it == 40) print '(A,I3,A,F9.5,A,F10.6)', '    adim', it, '  zeta=', zeta, '  E=', ehe(zeta)
    zeta = zeta - lr * g
  end do
  print '(A,F10.6,A)', '    He varyasyonel: E = ', ehe(27.0_dp/16.0_dp), '  (deneysel -2.9037)'
contains
  function eh(a) result(e)
    real(dp), intent(in) :: a
    real(dp) :: e
    e = 0.5_dp*a**2 - a
  end function eh
  function ehe(z) result(e)
    real(dp), intent(in) :: z
    real(dp) :: e
    e = z**2 - 27.0_dp/8.0_dp*z
  end function ehe
end program varyasyonel
