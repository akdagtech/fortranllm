# Örnek 7.5: İçeriğe dayalı bölme: sızıntıyı önle (PyTorch karşılığı)
import hashlib, random
nu, nd = 1000, 100
docs = [f"dokuman {k} metni" for k in range(1, nu + 1)] + [f"dokuman {k} metni" for k in range(1, nd + 1)]
def kume(v): return 0 if v < 90 else 1 if v < 95 else 2          # egitim / dogrulama / test
sp_h = [kume(int(hashlib.md5(d.encode()).hexdigest(), 16) % 100) for d in docs]
random.seed(5)
sp_r = [kume(random.randrange(100)) for _ in docs]
cnt = lambda sp: [sp.count(i) for i in range(3)]
print("rastgele bolme  egitim/dogrulama/test :", cnt(sp_r))
print("hash tabanli    egitim/dogrulama/test :", cnt(sp_h))
print("rastgele bolmede kopyasi baska kumeye dusen belge :", sum(sp_r[j] != sp_r[nu + j] for j in range(nd)), "/ 100")
print("hash tabanli bolmede ayni sayi                    :", sum(sp_h[j] != sp_h[nu + j] for j in range(nd)), "/ 100")

