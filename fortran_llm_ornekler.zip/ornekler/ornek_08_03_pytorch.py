# Örnek 8.3: Warmup + cosine öğrenme oranı çizelgesi (PyTorch karşılığı)
import math, torch
p = torch.nn.Parameter(torch.zeros(1))
opt = torch.optim.AdamW([p], lr=6e-4)
warm, total, lmin = 100, 1000, 6e-5
def lam(t):                                           # LambdaLR: lr = lr0 * lam(t)
    if t < warm: return t / warm
    prog = (t - warm) / (total - warm)
    return (lmin + 0.5 * (6e-4 - lmin) * (1 + math.cos(math.pi * prog))) / 6e-4
sched = torch.optim.lr_scheduler.LambdaLR(opt, lam)
want = {0, 50, 100, 200, 400, 600, 800, 900, 1000}
print("  adim       lr")
for t in range(1001):
    if t in want: print(f"{t:6d}{opt.param_groups[0]['lr']:12.3e}")
    opt.step(); sched.step()

