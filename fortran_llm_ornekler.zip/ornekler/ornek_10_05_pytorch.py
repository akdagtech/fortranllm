# Örnek 10.5: KV cache ile ve cache'siz attention: aynı sonuç, daha az iş (PyTorch karşılığı)
import torch
torch.manual_seed(14)
T_, d = 6, 8
X = torch.randn(T_, d, dtype=torch.float64)
Wq, Wk, Wv = (0.4 * torch.randn(d, d, dtype=torch.float64) for _ in range(3))
def attend(q, K, V):
    return torch.softmax(K @ q / d ** 0.5, 0) @ V
n_no = n_ca = 0
O1, O2 = [], []
for t in range(1, T_ + 1):                      # (a) cache yok: her adimda tum K,V yeniden
    K, V = X[:t] @ Wk, X[:t] @ Wv; n_no += t
    O1.append(attend(X[t - 1] @ Wq, K, V))
Kc, Vc = [], []
for t in range(T_):                             # (b) KV cache
    Kc.append(X[t] @ Wk); Vc.append(X[t] @ Wv); n_ca += 1
    O2.append(attend(X[t] @ Wq, torch.stack(Kc), torch.stack(Vc)))
print("max |cikti(cache yok) - cikti(cache)| =", (torch.stack(O1) - torch.stack(O2)).abs().max().item())
print("K,V projeksiyon sayisi, cache yok :", n_no)
print("K,V projeksiyon sayisi, cache var :", n_ca)

