# Örnek 1.2: Modül ve eleman bazlı fonksiyon: sigmoid (PyTorch karşılığı)
import torch
x = torch.tensor([-2., -1., 0., 1., 2.], dtype=torch.float64)
for v in x:
    print(f"sigmoid({v:5.1f}) = {torch.sigmoid(v):8.4f}")      # torch.sigmoid zaten elemental
print("hepsi birden:", " ".join(f"{v:.4f}" for v in torch.sigmoid(x)))

