! Örnek 1.5: Zincir kuralını sayısal olarak doğrula
! Derleme: gfortran -O2  ornek_01_05.f90 -o ornek
program zincir
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x, g, dgdx, dfdg, ana, num, h
  x = 1.5_dp
  h = 1.0e-6_dp
  g    = x**2              ! ic fonksiyon
  dgdx = 2.0_dp * x        ! dg/dx
  dfdg = cos(g)            ! d sin(g) / dg
  ana  = dfdg * dgdx       ! zincir kurali
  num  = (sin((x+h)**2) - sin((x-h)**2)) / (2.0_dp*h)
  print '(A,F12.8)', 'zincir kurali : ', ana
  print '(A,F12.8)', 'sayisal turev : ', num
  print '(A,ES10.2)', 'fark          : ', abs(ana - num)
end program zincir
