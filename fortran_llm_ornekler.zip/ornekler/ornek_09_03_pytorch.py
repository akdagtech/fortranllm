# Örnek 9.3: Eğitim süresi tahmini: 6ND kuralı (PyTorch karşılığı)
import torch, torch.nn as nn
from torch.utils.flop_counter import FlopCounterMode
# 6 N D kuralini olc: 4 katmanli MLP, N = 4*256*256 parametre, D = 64 token
net = nn.Sequential(*[nn.Linear(256, 256, bias=False) for _ in range(4)])
x = torch.randn(64, 256)
with FlopCounterMode(display=False) as fc:
    net(x).sum().backward()
N = sum(p.numel() for p in net.parameters()); D = 64
print(f"olculen FLOP = {fc.get_total_flops():.3e}    6*N*D = {6*N*D:.3e}")
peak, mfu = 312e12, 0.40
for ad, n, d in [("124M, 20 token/param", 124e6, 20 * 124e6), ("124M, 300B token", 124e6, 300e9), ("7B, 1T token", 7e9, 1e12)]:
    flop = 6 * n * d; sec = flop / (peak * mfu)
    print(f"{ad:22s} FLOP={flop:9.2e}  GPU-gun={sec/86400:9.1f}  256 GPU ile {sec/86400/256:8.2f} gun")

