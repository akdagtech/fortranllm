# Örnek 5.9: GPU çekirdeği: CUDA Fortran taslağı (çalıştırılmadı) (PyTorch karşılığı)
import torch
dev = "cuda" if torch.cuda.is_available() else "cpu"
print("kullanilan cihaz:", dev)
n = 2048
A = torch.randn(n, n, device=dev); B = torch.randn(n, n, device=dev)
C = A @ B                                        # GPU'da cuBLAS, CPU'da BLAS cagrilir
if dev == "cuda":
    torch.cuda.synchronize()                     # asenkron calisma: olcmeden once bekle
print("C boyutu:", tuple(C.shape), " cihaz:", C.device)
# GPU icin tipik kullanim (GPU olmayan makinelerde calistirmayin):
#   model = model.to("cuda");  x = x.to("cuda")
#   with torch.autocast("cuda", dtype=torch.bfloat16): loss = model(x).mean()   # mixed precision
#   fast = torch.compile(model)                                              # cekirdek birlestirme

