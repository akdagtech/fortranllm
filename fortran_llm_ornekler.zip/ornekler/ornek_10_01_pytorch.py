# Örnek 10.1: Greedy decoding ve tekrar döngüsü (PyTorch karşılığı)
import torch
torch.manual_seed(42)
V = 6
vocab = ["bir", "varmis", "yokmus", "evvel", "zaman", "."]
P = torch.softmax(1.5 * torch.randn(V, V), dim=-1)       # sabit gecis tablosu (satir = onceki token)

cur, seq = 0, [0]
for _ in range(13):
    cur = P[cur].argmax().item()                         # greedy: en olasi token
    seq.append(cur)
print("uretilen kimlikler:", seq)
print(" ".join(vocab[i] for i in seq))

