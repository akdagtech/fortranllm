# Örnek 6.4: Kendi BPE tokenizer'ım: eğitim, kodlama, çözme (PyTorch karşılığı)
from collections import Counter
corpus = ("araba arabalar arabalarda kalem kalemler kalemlerden evde evden evlerden "
          "gelmek gelecek gelenler gelenlerden kitap kitaplar kitaplarda kitaplardan ")
ids = list(corpus.encode()); tok = {i: bytes([i]) for i in range(256)}
merges = []; n0 = len(ids)
show = lambda t: tok[t].decode().replace(" ", "_")
for m in range(1, 25):
    pairs = Counter(zip(ids, ids[1:]))
    (a, b), cnt = max(sorted(pairs.items()), key=lambda kv: kv[1])   # esitlikte ilk (Fortran ile ayni)
    if cnt < 2: break
    new = 255 + m; tok[new] = tok[a] + tok[b]; merges.append((a, b, new))
    out, i = [], 0
    while i < len(ids):
        if i < len(ids) - 1 and (ids[i], ids[i + 1]) == (a, b): out.append(new); i += 2
        else: out.append(ids[i]); i += 1
    ids = out
    print(f"{m:3d}  [{show(a)}] + [{show(b)}] -> [{show(new)}]".ljust(34), f"sayi={cnt:2d}  dizi={len(ids):4d}  bayt/token={n0/len(ids):5.2f}")
def encode(text):
    x = list(text.encode())
    for a, b, new in merges:
        out, i = [], 0
        while i < len(x):
            if i < len(x) - 1 and (x[i], x[i + 1]) == (a, b): out.append(new); i += 2
            else: out.append(x[i]); i += 1
        x = out
    return x
print("--- yeni kelimeleri kodla ---")
for w in ["kalemlerde", "arabalardan", "kitaplarda", "evlerde", "gelenlerde"]:
    t = encode(w); back = b"".join(tok[i] for i in t).decode()
    print(f"{w} -> {'|'.join(show(i) for i in t)}   token={len(t)}   geri-cozme dogru={back == w}")

