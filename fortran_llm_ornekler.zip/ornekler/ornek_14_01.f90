! Örnek 14.1: Düzgün elektron gazı: değişim, korelasyon ve Thomas–Fermi
! Derleme: gfortran -O2  ornek_14_01.f90 -o ornek
program lda_gaz
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp), parameter :: pi = 3.141592653589793_dp
  real(dp) :: rs(7), dens, ex, ec, tTF
  integer :: i
  rs = [0.5_dp, 1.0_dp, 2.0_dp, 3.0_dp, 4.0_dp, 5.0_dp, 6.0_dp]
  print '(A)', '  rs      n (a.u.)     eps_x     -0.4582/rs    eps_c(PW92)   t_TF(kinetik)'
  do i = 1, 7
    dens = 3.0_dp / (4.0_dp * pi * rs(i)**3)                       ! n = 3/(4 pi rs^3)
    ex   = -0.75_dp * (3.0_dp/pi)**(1.0_dp/3.0_dp) * dens**(1.0_dp/3.0_dp)
    ec   = pw92(rs(i))
    tTF  = 0.3_dp * (3.0_dp*pi**2)**(2.0_dp/3.0_dp) * dens**(2.0_dp/3.0_dp)
    print '(F5.1,ES12.3,F11.5,F12.5,F13.5,F14.5)', rs(i), dens, ex, -0.458165_dp/rs(i), ec, tTF
  end do
contains
  function pw92(rs_) result(e)                    ! Perdew-Wang 1992 korelasyon (paramanyetik)
    real(dp), intent(in) :: rs_
    real(dp) :: e, A, a1, b1, b2, b3, b4
    A = 0.0310907_dp; a1 = 0.21370_dp
    b1 = 7.5957_dp; b2 = 3.5876_dp; b3 = 1.6382_dp; b4 = 0.49294_dp
    e = -2.0_dp*A*(1.0_dp + a1*rs_) * log(1.0_dp + 1.0_dp / (2.0_dp*A*(b1*sqrt(rs_) + b2*rs_ + &
        b3*rs_**1.5_dp + b4*rs_**2)))
  end function pw92
end program lda_gaz
