! Örnek 10.3: Top-k ve top-p filtreleri
! Derleme: gfortran -O2  ornek_10_03.f90 -o ornek
program topk_topp
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 7
  real(dp) :: z(n), p(n), pk(n), pp(n), cum
  integer :: idx(n), i, j, tmp, k, nkeep
  z = [3.0_dp, 2.5_dp, 1.0_dp, 0.5_dp, 0.0_dp, -1.0_dp, -2.0_dp]
  p = exp(z - maxval(z)); p = p / sum(p)
  idx = [(i, i = 1, n)]
  do i = 1, n - 1                                   ! idx'i olasiliga gore azalan sirala
    do j = i + 1, n
      if (p(idx(j)) > p(idx(i))) then
        tmp = idx(i); idx(i) = idx(j); idx(j) = tmp
      end if
    end do
  end do
  k = 3
  pk = 0.0_dp
  pk(idx(1:k)) = p(idx(1:k))
  pk = pk / sum(pk)                                 ! top-k
  cum = 0.0_dp; nkeep = 0
  do i = 1, n                                       ! top-p
    cum = cum + p(idx(i)); nkeep = i
    if (cum >= 0.95_dp) exit
  end do
  pp = 0.0_dp
  pp(idx(1:nkeep)) = p(idx(1:nkeep))
  pp = pp / sum(pp)
  print '(A,7F7.3)', 'olasiliklar : ', p
  print '(A,7F7.3)', 'top-k (k=3) : ', pk
  print '(A,I0,A,7F7.3)', 'top-p (0.95, ', nkeep, ' token): ', pp
end program topk_topp
