! Örnek 10.7: Batch boyutu, gecikme ve throughput modeli
! Derleme: gfortran -O2  ornek_10_07.f90 -o ornek
program throughput
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp), parameter :: wbytes = 14.0e9_dp, bw = 2.0e12_dp, peak = 312.0e12_dp
  real(dp), parameter :: flop_tok = 14.0e9_dp        ! 2 * N, N = 7e9
  integer :: bs(6), i
  real(dp) :: t_mem, t_cmp, t
  bs = [1, 8, 32, 128, 256, 512]
  t_mem = wbytes / bw
  print '(A,F6.2,A)', 'agirlik okuma suresi = ', t_mem * 1.0e3_dp, ' ms/adim'
  print '(A)', '   B   adim(ms)   tok/s (toplam)   sinir'
  do i = 1, 6
    t_cmp = bs(i) * flop_tok / peak
    t = max(t_mem, t_cmp)
    print '(I5,F10.2,F16.0,3X,A)', bs(i), t * 1.0e3_dp, bs(i) / t, &
          merge('bellek ', 'islem  ', t_mem >= t_cmp)
  end do
  print '(A,F7.1)', 'gecis noktasi B* = ', t_mem * peak / flop_tok
end program throughput
