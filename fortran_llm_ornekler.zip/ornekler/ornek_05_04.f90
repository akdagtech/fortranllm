! Örnek 5.4: OpenMP ile paralel matris çarpımı
! Derleme: gfortran -O2 -fopenmp ornek_05_04.f90 -o ornek
program omp_matmul
  use omp_lib
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 700
  real(dp), allocatable :: A(:,:), B(:,:), C(:,:), Cref(:,:)
  real(dp) :: t0, t1
  integer :: i, j, k, nt, nts(3)
  allocate(A(n,n), B(n,n), C(n,n), Cref(n,n))
  call random_number(A); call random_number(B)
  Cref = matmul(A, B)
  nts = [1, 2, 4]
  print '(A,I0)', 'kullanilabilir isleme birimi sayisi: ', omp_get_num_procs()
  do nt = 1, 3
    call omp_set_num_threads(nts(nt))
    C = 0.0_dp
    t0 = omp_get_wtime()
    !$omp parallel do private(i, k) schedule(static)
    do j = 1, n
      do k = 1, n
        do i = 1, n
          C(i,j) = C(i,j) + A(i,k) * B(k,j)
        end do
      end do
    end do
    !$omp end parallel do
    t1 = omp_get_wtime()
    print '(A,I2,A,F8.3,A,ES9.2)', 'is parcacigi=', nts(nt), ' sure=', t1-t0, &
          ' s fark=', maxval(abs(C-Cref))
  end do
end program omp_matmul
