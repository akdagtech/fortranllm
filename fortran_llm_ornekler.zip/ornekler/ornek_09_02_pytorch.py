# Örnek 9.2: Bellek hesaplayıcısı: 1.5B, 7B, 13B, 70B (PyTorch karşılığı)
import torch, torch.nn as nn
# gercek olcum: Adam ile tek adim sonrasi agirlik + gradyan + optimizer durumu (FP32)
m = nn.Linear(1000, 1000, bias=False)
opt = torch.optim.Adam(m.parameters())
m(torch.randn(8, 1000)).sum().backward(); opt.step()
n = m.weight.numel()
w = m.weight.numel() * m.weight.element_size(); g = m.weight.grad.numel() * 4
st = sum(v.numel() * v.element_size() for v in opt.state[m.weight].values() if v.dim() > 0)
print(f"parametre = {n}   agirlik {w/n:.0f} B/param + gradyan {g/n:.0f} + Adam durumu {st/n:.0f} = {(w+g+st)/n:.0f} bayt/param")
print("  model     FP32-agirlik  egitim(16B)  FP16-infer  INT8   INT4   min GPU(80GB)")
for N in [1.5e9, 7e9, 13e9, 70e9]:
    print(f"{N/1e9:6.1f}B {4*N/1e9:11.1f} GB {16*N/1e9:10.1f} GB {2*N/1e9:8.1f} GB {N/1e9:6.1f}{0.5*N/1e9:7.1f}{-(-16*N/1e9//80):9.0f}")

