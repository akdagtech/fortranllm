# Örnek 2.5: Softmax + çapraz entropi gradyanı ve sayısal kararlılık (PyTorch karşılığı)
import torch
import torch.nn.functional as F
z = torch.tensor([2.0, 1.0, 0.1], dtype=torch.float64, requires_grad=True)
k = 1                                       # dogru sinif (0 tabanli)
loss = F.cross_entropy(z[None, :], torch.tensor([k]))   # softmax + CE tek fonksiyonda
loss.backward()
p = torch.softmax(z.detach(), 0)
print("p            =", [round(v, 6) for v in p.tolist()])
print("kayip        =", round(loss.item(), 6))
print("autograd grad=", [round(v, 6) for v in z.grad.tolist()])
print("p - onehot   =", [round(v, 6) for v in (p - F.one_hot(torch.tensor(k), 3)).tolist()])
big = torch.tensor([1000., 1001., 1002.], dtype=torch.float64)
print("saf softmax  =", (big.exp() / big.exp().sum()).tolist())   # inf/inf = nan
print("torch.softmax=", [round(v, 6) for v in torch.softmax(big, 0).tolist()])

