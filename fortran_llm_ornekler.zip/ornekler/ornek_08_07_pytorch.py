# Örnek 8.7: Eğitim bütçesi hesaplayıcısı (PyTorch karşılığı)
tok_adim = 32 * 1024 * 4
params = 124e6
tok_gerek = 20 * params
print(f"token / adim                    = {tok_adim:,.0f}")
print(f"gereken token (20 x param)      = {tok_gerek / 1e9:.3f} milyar")
print(f"optimizer adim sayisi           = {tok_gerek / tok_adim:,.0f}")
print(f"epoch (10 milyar tokenlik veri) = {tok_gerek / 10e9:.3f}")
print(f"10 milyar token icin adim       = {10e9 / tok_adim:,.0f}")

