# Örnek 4.5: Multi-head attention modülü (PyTorch karşılığı)
import torch, torch.nn as nn
torch.manual_seed(8)
T_, d, nh = 5, 8, 2
mha = nn.MultiheadAttention(d, nh, batch_first=True)
causal = torch.triu(torch.ones(T_, T_, dtype=torch.bool), diagonal=1)
def run(X):
    return mha(X[None], X[None], X[None], attn_mask=causal, need_weights=False)[0][0]
X = torch.randn(T_, d)
X2 = X.clone(); X2[-1] = 0.0
Y1, Y2 = run(X), run(X2)
print("cikti boyutu:", tuple(Y1.shape))
print("parametre sayisi (agirlik) 4*d^2 =", 4 * d * d, "  | toplam (bias dahil) =", sum(p.numel() for p in mha.parameters()))
print("onceki satirlarin degisimi =", (Y1[:-1] - Y2[:-1]).abs().max().item())

