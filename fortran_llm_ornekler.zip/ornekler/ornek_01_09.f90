! Örnek 1.9: Entropi ve çapraz entropi
! Derleme: gfortran -O2  ornek_01_09.f90 -o ornek
program entropi
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: p1(2), p2(2), p3(4), gercek(3), q1(3), q2(3)
  p1 = [0.5_dp, 0.5_dp]
  p2 = [0.9_dp, 0.1_dp]
  p3 = [0.25_dp, 0.25_dp, 0.25_dp, 0.25_dp]
  print '(A,F8.4)', 'H(0.5,0.5)         = ', -sum(p1*log(p1))
  print '(A,F8.4)', 'H(0.9,0.1)         = ', -sum(p2*log(p2))
  print '(A,F8.4)', 'H(4 esit olasilik) = ', -sum(p3*log(p3))
  gercek = [1.0_dp, 0.0_dp, 0.0_dp]
  q1 = [0.7_dp, 0.2_dp, 0.1_dp]
  q2 = [0.1_dp, 0.6_dp, 0.3_dp]
  print '(A,F8.4)', 'CE(iyi model)  = ', -log(q1(1))
  print '(A,F8.4)', 'CE(kotu model) = ', -log(q2(1))
  print '(A,F8.4)', 'ln(3) (rastgele tahmin) = ', log(3.0_dp)
end program entropi
