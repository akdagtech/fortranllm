# Örnek 15.2: Mesaj geçirmeyi sıfırdan yaz: permütasyon değişmezliği ve WL sınırı
import torch, torch.nn as nn
from rdkit import Chem

def mol_graph(smi):
    m = Chem.MolFromSmiles(smi)
    x = torch.tensor([[float(a.GetAtomicNum() == z) for z in (6, 7, 8)] for a in m.GetAtoms()])   # one-hot (C,N,O)
    ei = torch.tensor([[b.GetBeginAtomIdx(), b.GetEndAtomIdx()] for b in m.GetBonds()]
                      + [[b.GetEndAtomIdx(), b.GetBeginAtomIdx()] for b in m.GetBonds()]).T
    return x, ei

class MPLayer(nn.Module):
    """h_i' = ReLU( W_self h_i + W_msg * toplam_{j komsu i} h_j )"""
    def __init__(s, d):
        super().__init__(); s.ws = nn.Linear(d, d); s.wm = nn.Linear(d, d)
    def forward(s, h, ei):
        src, dst = ei
        agg = torch.zeros_like(h).index_add_(0, dst, h[src])          # mesaj toplama (permutasyondan bagimsiz)
        return torch.relu(s.ws(h) + s.wm(agg))

class GNN(nn.Module):
    def __init__(s, d=16, L=3):
        super().__init__(); s.emb = nn.Linear(3, d); s.layers = nn.ModuleList(MPLayer(d) for _ in range(L))
    def forward(s, x, ei):
        h = s.emb(x)
        for l in s.layers: h = l(h, ei)
        return h.sum(0)                                                # toplam havuzlama: grafin vektor temsili

torch.manual_seed(0)
net = GNN()
x, ei = mol_graph("CC(=O)O")
g1 = net(x, ei)
perm = torch.randperm(len(x)); inv = torch.argsort(perm)              # atomlari yeniden numarala
g2 = net(x[perm], inv[ei])
print("permutasyon degismezligi: ||g(G) - g(permute(G))|| =", (g1 - g2).norm().item())
a, b = mol_graph("C1CCCCC1"), mol_graph("C1CC1.C1CC1")                # siklohekzan vs 2 x siklopropan
print("siklohekzan vs 2 x siklopropan: ||g1 - g2|| =", (net(*a) - net(*b)).norm().item())
print("  (iki graf farkli, ama toplamali GNN ikisini AYIRT EDEMIYOR: 1-WL siniri)")
c = mol_graph("CCO"); d = mol_graph("COC")
print("etanol vs dimetil eter: ||g1 - g2|| =", (net(*c) - net(*d)).norm().item(), " (ayirt edilir)")
