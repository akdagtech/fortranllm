# Örnek 1.1: Ortalama ve standart sapma (PyTorch karşılığı)
import torch
x = torch.tensor([2., 4., 4., 4., 6.], dtype=torch.float64)
print(f"ortalama   = {x.mean():8.4f}")
print(f"std sapma  = {torch.std(x, correction=0):8.4f}")   # Fortran'daki gibi N'e bolunur
print(f"en buyuk   = {x.max():8.4f}")

