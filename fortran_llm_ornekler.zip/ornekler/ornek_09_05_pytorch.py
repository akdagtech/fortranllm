# Örnek 9.5: MLP'yi iki "GPU"ya böl: sütun + satır paralelliği (PyTorch karşılığı)
import torch, torch.nn.functional as F
torch.manual_seed(12)
T_, d, h = 4, 6, 8
X = torch.randn(T_, d, dtype=torch.float64)
W1 = 0.5 * torch.randn(d, h, dtype=torch.float64); W2 = 0.5 * torch.randn(h, d, dtype=torch.float64)
gelu = lambda z: F.gelu(z, approximate='tanh')
Y = gelu(X @ W1) @ W2                                     # tek parca
Ha = gelu(X @ W1[:, :h // 2]); Hb = gelu(X @ W1[:, h // 2:])   # sutun paralelligi: iletisim yok
Ya = Ha @ W2[:h // 2]; Yb = Hb @ W2[h // 2:]                    # satir paralelligi: kismi toplamlar
print("max |Y - (Ya + Yb)| =", (Y - (Ya + Yb)).abs().max().item())    # tek all-reduce
print("cihaz basina W1 sutunu:", h // 2, "/", h)

