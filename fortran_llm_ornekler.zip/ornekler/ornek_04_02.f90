! Örnek 4.2: Tek bir query için attention (elle hesap)
! Derleme: gfortran -O2  ornek_04_02.f90 -o ornek
program attn_tek
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: q(2), K(3,2), V(3,2), s(3), w(3), o(2)
  integer :: j
  q = [1.0_dp, 0.0_dp]
  K = reshape([1,0, 0,1, 1,1] * 1.0_dp, [3,2], order=[2,1])
  V = K
  do j = 1, 3
    s(j) = dot_product(q, K(j,:)) / sqrt(2.0_dp)      ! olcekli skor
  end do
  w = exp(s - maxval(s)); w = w / sum(w)               ! softmax
  o = matmul(w, V)                                     ! agirlikli ortalama
  print '(A,3F9.4)', 'skorlar   = ', s
  print '(A,3F9.4)', 'agirliklar= ', w
  print '(A,2F9.4)', 'cikti     = ', o
end program attn_tek
