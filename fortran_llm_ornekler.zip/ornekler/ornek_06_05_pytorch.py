# Örnek 6.5: Embedding tablosu, özel tokenlar ve padding (PyTorch karşılığı)
import torch, torch.nn as nn
from torch.nn.utils.rnn import pad_sequence
torch.manual_seed(3)
vocab = ["<PAD>", "<BOS>", "<EOS>", "ev", "ler", "de", "kitap", "oku", "du", "m"]
seqs = [torch.tensor(s) for s in ([1, 3, 4, 5, 2], [1, 6, 2], [1, 7, 8, 9, 2])]
ids = pad_sequence(seqs, batch_first=True, padding_value=0)     # PAD ile esitle
mask = ids != 0
E = nn.Embedding(len(vocab), 4, padding_idx=0)                  # PAD satiri sifir ve egitilmez
for b in range(3): print(f"dizi {b+1}:", " ".join(vocab[i] for i in seqs[b]))
print("ids (0 = PAD):"); print(ids)
print("maske:"); print(mask)
X = E(ids)                                                       # (B, T, d)
pooled = (X * mask.unsqueeze(-1)).sum(1) / mask.sum(1, keepdim=True)
for b in range(3):
    print(f"dizi {b+1} ({mask[b].sum().item()} token) ort:", [round(v, 3) for v in pooled[b].tolist()])

