# Örnek 10.8: Fortran çekirdeği + Python istemcisi (paylaşılan kütüphane) (PyTorch karşılığı)
import torch
torch.manual_seed(42)
V = 6
vocab = ["bir", "varmis", "yokmus", "evvel", "zaman", "."]
P = torch.softmax(1.5 * torch.randn(V, V), dim=-1)       # sabit gecis tablosu (satir = onceki token)

def generate(start, n, temp, seed):                      # Fortran'daki lm_generate'in karsiligi
    g = torch.Generator().manual_seed(seed)
    cur, out = start, []
    for _ in range(n):
        pr = P[cur] ** (1.0 / temp); pr = pr / pr.sum()
        cur = torch.multinomial(pr, 1, generator=g).item(); out.append(cur)
    return [vocab[i] for i in out]
print("T=1.0 seed=1 :", " ".join(generate(0, 12, 1.0, 1)))
print("T=0.3 seed=1 :", " ".join(generate(0, 12, 0.3, 1)))
print("T=1.0 seed=1 :", " ".join(generate(0, 12, 1.0, 1)), " (ayni tohum, ayni cikti)")
print("T=1.0 seed=2 :", " ".join(generate(0, 12, 1.0, 2)))
# Bunu bir HTTP servisine cevirmek icin (FastAPI): 
#   @app.post("/generate")  def gen(req): return {"tokens": generate(req.start, req.n, req.temperature, req.seed)}

