! Örnek 4.3: Causal self-attention matrisi
! Derleme: gfortran -O2  ornek_04_03.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module attn_mod
  use prec_mod
  implicit none
contains
  subroutine softmax_rows(S)               ! her satiri ayri softmax'la
    real(dp), intent(inout) :: S(:,:)
    integer :: i
    do i = 1, size(S,1)
      S(i,:) = exp(S(i,:) - maxval(S(i,:)))
      S(i,:) = S(i,:) / sum(S(i,:))
    end do
  end subroutine softmax_rows

  subroutine causal_attention(Q, K, V, A, O)
    real(dp), intent(in)  :: Q(:,:), K(:,:), V(:,:)    ! (T,dk), (T,dk), (T,dv)
    real(dp), intent(out) :: A(:,:), O(:,:)            ! (T,T), (T,dv)
    integer :: T, i, j
    T = size(Q,1)
    A = matmul(Q, transpose(K)) / sqrt(real(size(Q,2), dp))
    do i = 1, T
      do j = i+1, T
        A(i,j) = -1.0e30_dp                             ! gelecegi maskele
      end do
    end do
    call softmax_rows(A)
    O = matmul(A, V)
  end subroutine causal_attention
end module attn_mod

program causal
  use attn_mod
  implicit none
  integer, parameter :: T = 4, d = 2
  real(dp) :: X(T,d), A(T,T), O(T,d)
  integer :: i
  X = reshape([1.0_dp, 0.0_dp,  0.0_dp, 1.0_dp,  1.0_dp, 1.0_dp,  0.5_dp, -0.5_dp], &
              [T,d], order=[2,1])
  call causal_attention(X, X, X, A, O)
  print '(A)', 'Attention agirliklari A (satir = sorgu token, sutun = bakilan token):'
  do i = 1, T
    print '(4F9.4,A,F8.4)', A(i,:), '   satir toplami =', sum(A(i,:))
  end do
  print '(A)', 'Cikti O = A V :'
  do i = 1, T
    print '(2F10.4)', O(i,:)
  end do
end program causal
