! Örnek 10.1: Greedy decoding ve tekrar döngüsü
! Derleme: gfortran -O2  ornek_10_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program greedy
  use rng_mod
  implicit none
  integer, parameter :: V = 6, n = 14
  character(len=7) :: kelime(V)
  real(dp) :: P(V,V), z(V)
  integer :: cur, nxt, i, seq(n)
  kelime = [character(len=7) :: 'bir', 'varmis', 'yokmus', 'evvel', 'zaman', '.']
  call rng_seed(42)
  do i = 1, V
    call randn1(z, 1.5_dp)
    P(i,:) = exp(z - maxval(z)); P(i,:) = P(i,:) / sum(P(i,:))
  end do
  cur = 1
  seq(1) = cur
  do i = 2, n
    nxt = maxloc(P(cur,:), dim=1)                  ! greedy: en olasi token
    seq(i) = nxt
    cur = nxt
  end do
  print '(A)', 'uretilen kimlikler: '
  print '(14I3)', seq
  do i = 1, n
    write(*,'(A,A)', advance='no') trim(kelime(seq(i))), ' '
  end do
  print *
end program greedy
