! Örnek 11.1: Model 1: Nöral bigram dil modeli
! Derleme: gfortran -O2  ornek_11_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module lmdata
  use rng_mod
  implicit none
  character(len=*), parameter :: corpus = &
    'bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken ' // &
    'pireler berber iken ben annemin besigini tangir tungur sallar iken. ' // &
    'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. ' // &
    'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. ' // &
    'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. ' // &
    'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. ' // &
    'yolcular gelir su icer dinlenir sonra yoluna devam edermis. '
  integer, parameter :: NCH = len(corpus), V = 23     ! V: sozluk boyutu (asagida dogrulanir)
  integer :: ids(NCH), ntrain = 0
  character(len=1) :: chars(64)
contains
  subroutine build_vocab()                         ! karakter -> kimlik (1..V)
    integer :: i, c, nv, map(0:127)
    logical :: seen(0:127)
    seen = .false.
    do i = 1, NCH
      seen(ichar(corpus(i:i))) = .true.
    end do
    nv = 0; map = -1
    do c = 0, 127
      if (seen(c)) then
        nv = nv + 1; map(c) = nv; chars(nv) = char(c)
      end if
    end do
    if (nv /= V) error stop 'V yanlis: sozluk boyutunu guncelle'
    do i = 1, NCH
      ids(i) = map(ichar(corpus(i:i)))
    end do
    ntrain = int(0.85_dp * NCH)                      ! ilk %85 egitim, kalan dogrulama
  end subroutine build_vocab

  function decode(a) result(s)                     ! kimlikler -> metin
    integer, intent(in) :: a(:)
    character(len=size(a)) :: s
    integer :: i
    do i = 1, size(a)
      s(i:i) = chars(a(i))
    end do
  end function decode

  subroutine softmax_vec(z, p)
    real(dp), intent(in)  :: z(:)
    real(dp), intent(out) :: p(:)
    p = exp(z - maxval(z)); p = p / sum(p)
  end subroutine softmax_vec

  subroutine adam_step(p, g, m, s, t, lr)          ! tek vektor uzerinde Adam
    real(dp), intent(inout) :: p(:), m(:), s(:)
    real(dp), intent(in)    :: g(:), lr
    integer, intent(in)     :: t
    real(dp), parameter :: b1 = 0.9_dp, b2 = 0.999_dp, eps = 1.0e-8_dp
    m = b1 * m + (1.0_dp - b1) * g
    s = b2 * s + (1.0_dp - b2) * g * g
    p = p - lr * (m / (1.0_dp - b1**t)) / (sqrt(s / (1.0_dp - b2**t)) + eps)
  end subroutine adam_step
end module lmdata

program bigram_lm
  use lmdata
  implicit none
  real(dp), allocatable, target :: th(:), gr(:), m1(:), s1(:)
  real(dp), pointer :: W(:,:), gW(:,:)
  real(dp), allocatable :: p(:), cnt(:,:)
  real(dp) :: loss, opt
  integer :: step, t, a, b, i, cur, k
  integer :: gen(100)
  call build_vocab()
  allocate(th(V*V), gr(V*V), m1(V*V), s1(V*V), p(V), cnt(V,V))
  W(1:V,1:V) => th; gW(1:V,1:V) => gr
  th = 0.0_dp; m1 = 0.0_dp; s1 = 0.0_dp
  print '(A,I0,A,I0,A,I0)', 'karakter=', NCH, '  sozluk V=', V, '  egitim=', ntrain
  print '(A,F7.4)', 'ln V = ', log(real(V, dp))
  do step = 1, 300
    gr = 0.0_dp; loss = 0.0_dp
    do t = 1, ntrain - 1
      a = ids(t); b = ids(t+1)
      call softmax_vec(W(a,:), p)
      loss = loss - log(p(b))
      p(b) = p(b) - 1.0_dp                           ! dL/dlogits = p - onehot
      gW(a,:) = gW(a,:) + p
    end do
    gr = gr / (ntrain - 1); loss = loss / (ntrain - 1)
    call adam_step(th, gr, m1, s1, step, 0.05_dp)
    if (step == 1 .or. mod(step, 100) == 0) then
      print '(A,I4,A,F8.4,A,F8.4)', 'adim ', step, '  egitim=', loss, '  dogrulama=', val_loss()
    end if
  end do
  ! sayim tabanli en iyi bigram (egitim verisi uzerinde analitik cozum)
  cnt = 0.0_dp
  do t = 1, ntrain - 1
    cnt(ids(t), ids(t+1)) = cnt(ids(t), ids(t+1)) + 1.0_dp
  end do
  opt = 0.0_dp
  do a = 1, V
    do b = 1, V
      if (cnt(a,b) > 0.0_dp) opt = opt - cnt(a,b) * log(cnt(a,b) / sum(cnt(a,:)))
    end do
  end do
  print '(A,F8.4)', 'sayim tabanli en iyi egitim kaybi = ', opt / (ntrain - 1)
  ! metin uret
  call rng_seed(5)
  cur = ids(1); gen(1) = cur
  do i = 2, 100
    call softmax_vec(W(cur,:), p)
    call sample(p, k)
    gen(i) = k; cur = k
  end do
  print '(A)', 'uretilen metin:'
  print '(A)', decode(gen)
contains
  function val_loss() result(l)
    real(dp) :: l, q(V)
    integer :: tt
    l = 0.0_dp
    do tt = ntrain + 1, NCH - 1
      call softmax_vec(W(ids(tt),:), q)
      l = l - log(q(ids(tt+1)))
    end do
    l = l / (NCH - ntrain - 1)
  end function val_loss

  subroutine sample(pr, k)
    real(dp), intent(in) :: pr(:)
    integer, intent(out) :: k
    real(dp) :: u, c
    u = uniform(); c = 0.0_dp
    do k = 1, size(pr)
      c = c + pr(k)
      if (u <= c) return
    end do
    k = size(pr)
  end subroutine sample
end program bigram_lm
