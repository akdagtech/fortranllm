# Örnek 4.9: Minik GPT: ileri geçiş, kayıp ve ln V kontrolü (PyTorch karşılığı)
import torch, torch.nn as nn
import torch.nn.functional as F

class Block(nn.Module):                     # pre-norm, RMSNorm'lu Transformer blogu
    def __init__(self, d, nh):
        super().__init__()
        self.nh = nh
        self.n1, self.n2 = nn.RMSNorm(d, eps=1e-5), nn.RMSNorm(d, eps=1e-5)
        self.qkv = nn.Linear(d, 3 * d, bias=False)
        self.proj = nn.Linear(d, d, bias=False)
        self.ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(approximate='tanh'), nn.Linear(4 * d, d))
    def forward(self, x):                   # x: (B, T, d)
        B, T, d = x.shape
        q, k, v = self.qkv(self.n1(x)).chunk(3, dim=-1)
        q, k, v = (t.view(B, T, self.nh, d // self.nh).transpose(1, 2) for t in (q, k, v))
        a = F.scaled_dot_product_attention(q, k, v, is_causal=True)   # causal multi-head attention
        x = x + self.proj(a.transpose(1, 2).reshape(B, T, d))         # residual 1
        return x + self.ffn(self.n2(x))                               # residual 2

class GPT(nn.Module):
    def __init__(self, V, d, nh, nl, T):
        super().__init__()
        self.E = nn.Embedding(V, d); self.P = nn.Embedding(T, d)
        self.blocks = nn.ModuleList(Block(d, nh) for _ in range(nl))
        self.nf = nn.RMSNorm(d, eps=1e-5)
        for p in self.parameters():
            if p.dim() > 1: nn.init.normal_(p, std=0.02)
    def forward(self, ids):
        x = self.E(ids) + self.P(torch.arange(ids.shape[1]))
        for b in self.blocks: x = b(x)
        return F.linear(self.nf(x), self.E.weight)      # agirlik baglama (weight tying)

torch.manual_seed(100)
V, d, nh, nl, T = 10, 16, 2, 2, 8
model = GPT(V, d, nh, nl, T)
ids = torch.tensor([[3, 1, 4, 1, 5, 9, 2, 6]]); tgt = torch.tensor([[1, 4, 1, 5, 9, 2, 6, 5]])
logits = model(ids)
loss = F.cross_entropy(logits.view(-1, V), tgt.view(-1))
npar = sum(p.numel() for p in model.parameters())
print(f"baslangic kaybi        = {loss.item():.4f}")
print(f"ln(V) (tekduze tahmin) = {torch.log(torch.tensor(float(V))).item():.4f}")
print("toplam parametre sayisi =", npar, " (FFN biaslari dahil; attention biassiz)")

