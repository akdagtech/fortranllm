! Örnek 4.10: Softmax/attention geri yayılımı: sayısal doğrulama
! Derleme: gfortran -O2  ornek_04_10.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program attn_geri
  use rng_mod
  implicit none
  integer, parameter :: n = 4, dv = 3
  real(dp) :: s(n), V(n,dv), g(dv), p(n), dp_(n), ds(n), dsn(n), h
  real(dp), parameter :: eps = 1.0e-6_dp
  integer :: j
  call rng_seed(9)
  call randn1(s, 1.0_dp); call randn2(V, 1.0_dp); call randn1(g, 1.0_dp)
  p = soft(s)
  dp_ = matmul(V, g)                           ! dp_j = v_j . g
  ds = p * (dp_ - sum(p * dp_))                ! softmax geri yayilimi
  do j = 1, n
    h = eps
    dsn(j) = (loss(bump(s, j, h)) - loss(bump(s, j, -h))) / (2*h)
  end do
  print '(A,4F10.6)', 'formul   dL/ds = ', ds
  print '(A,4F10.6)', 'sayisal  dL/ds = ', dsn
contains
  function soft(a) result(q)
    real(dp), intent(in) :: a(:)
    real(dp) :: q(size(a))
    q = exp(a - maxval(a)); q = q / sum(q)
  end function soft
  function bump(a, j, h) result(b)
    real(dp), intent(in) :: a(:), h
    integer, intent(in) :: j
    real(dp) :: b(size(a))
    b = a; b(j) = b(j) + h
  end function bump
  function loss(a) result(l)
    real(dp), intent(in) :: a(:)
    real(dp) :: l
    l = dot_product(matmul(soft(a), V), g)     ! L = g . (sum_j p_j v_j)
  end function loss
end program attn_geri
