! Örnek 2.6: XOR için 2-4-1 MLP: geri yayılım + gradyan kontrolü + eğitim
! Derleme: gfortran -O2  ornek_02_06.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module mlp
  use rng_mod
  implicit none
  integer, parameter :: nh = 4, nth = 4*nh + 1
  real(dp), target, save :: th(nth), g(nth)
  real(dp), pointer :: W1(:,:), b1(:), W2(:), b2
  real(dp), pointer :: gW1(:,:), gb1(:), gW2(:), gb2
  real(dp), save :: X(4,2), t(4)
contains
  subroutine baglan()                  ! duz vektore matris "gorunumleri" ver
    W1(1:2,1:nh) => th(1:2*nh)
    b1 => th(2*nh+1:3*nh)
    W2 => th(3*nh+1:4*nh)
    b2 => th(4*nh+1)
    gW1(1:2,1:nh) => g(1:2*nh)
    gb1 => g(2*nh+1:3*nh)
    gW2 => g(3*nh+1:4*nh)
    gb2 => g(4*nh+1)
  end subroutine baglan

  subroutine fwd(x1, h, yhat)          ! ileri gecis (tek ornek)
    real(dp), intent(in)  :: x1(2)
    real(dp), intent(out) :: h(nh), yhat
    h = tanh(matmul(x1, W1) + b1)
    yhat = 1.0_dp / (1.0_dp + exp(-(dot_product(h, W2) + b2)))
  end subroutine fwd

  function loss() result(l)            ! ortalama BCE
    real(dp) :: l, h(nh), yh
    integer :: i
    l = 0.0_dp
    do i = 1, 4
      call fwd(X(i,:), h, yh)
      l = l - t(i)*log(yh) - (1.0_dp - t(i))*log(1.0_dp - yh)
    end do
    l = l / 4
  end function loss

  subroutine backward()                ! geri gecis: g vektorunu doldurur
    real(dp) :: h(nh), yh, dz2, dh(nh), dz1(nh)
    integer :: i
    g = 0.0_dp
    do i = 1, 4
      call fwd(X(i,:), h, yh)
      dz2 = yh - t(i)                  ! sigmoid + BCE -> p - hedef
      gW2 = gW2 + dz2 * h
      gb2 = gb2 + dz2
      dh  = dz2 * W2
      dz1 = dh * (1.0_dp - h**2)       ! tanh turevi
      gW1 = gW1 + spread(X(i,:), 2, nh) * spread(dz1, 1, 2)
      gb1 = gb1 + dz1
    end do
    g = g / 4
  end subroutine backward
end module mlp

program xor_egitim
  use mlp
  implicit none
  integer :: i, ep
  real(dp) :: eps, old, lp, lm, num, maxrel, h(nh), yh
  call baglan()
  X = reshape([0,0,1,1, 0,1,0,1] * 1.0_dp, [4,2])
  t = [0.0_dp, 1.0_dp, 1.0_dp, 0.0_dp]
  call rng_seed(7)
  call randn1(th, 0.8_dp)
  ! --- gradyan kontrolu ---
  call backward()
  eps = 1.0e-6_dp; maxrel = 0.0_dp
  do i = 1, nth
    old = th(i)
    th(i) = old + eps; lp = loss()
    th(i) = old - eps; lm = loss()
    th(i) = old
    num = (lp - lm) / (2*eps)
    maxrel = max(maxrel, abs(num - g(i)) / max(1.0e-8_dp, abs(num) + abs(g(i))))
  end do
  print '(A,ES10.2)', 'gradyan kontrolu, en buyuk bagil hata = ', maxrel
  ! --- egitim ---
  do ep = 0, 6000
    if (mod(ep, 1000) == 0) print '(A,I5,A,F10.6)', 'adim ', ep, '  kayip = ', loss()
    call backward()
    th = th - 0.5_dp * g
  end do
  do i = 1, 4
    call fwd(X(i,:), h, yh)
    print '(A,2F4.0,A,F8.4)', 'girdi', X(i,:), '  tahmin = ', yh
  end do
end program xor_egitim
