! Örnek 3.4: Adam'ın ilk adımları: bias düzeltmesi neden gerekli?
! Derleme: gfortran -O2  ornek_03_04.f90 -o ornek
program adam_elle
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: m, s, mh, sh, g, lr, b1, b2, eps, step, theta
  integer :: t
  g = 0.5_dp; lr = 0.1_dp; b1 = 0.9_dp; b2 = 0.999_dp; eps = 1.0e-8_dp
  m = 0.0_dp; s = 0.0_dp; theta = 1.0_dp
  print '(A)', ' t        m          s          mhat       shat       adim    theta'
  do t = 1, 4
    m = b1*m + (1.0_dp - b1)*g
    s = b2*s + (1.0_dp - b2)*g**2
    mh = m / (1.0_dp - b1**t)
    sh = s / (1.0_dp - b2**t)
    step = lr * mh / (sqrt(sh) + eps)
    theta = theta - step
    print '(I2,6F11.6)', t, m, s, mh, sh, step, theta
  end do
end program adam_elle
