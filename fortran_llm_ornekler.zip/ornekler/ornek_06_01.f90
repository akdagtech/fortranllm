! Örnek 6.1: Bir metnin baytları ve karakter sayısı
! Derleme: gfortran -O2  ornek_06_01.f90 -o ornek
program utf8_baytlar
  implicit none
  character(len=*), parameter :: s = 'Türkçe şiir'
  integer :: i, nb, nc, b
  nb = len(s)
  nc = 0
  print '(A,A)', 'metin : ', s
  do i = 1, nb
    b = ichar(s(i:i))
    if (iand(b, 192) /= 128) nc = nc + 1          ! devam bayti (10xxxxxx) sayma
    write(*,'(A,I2,A,Z2.2,A,I3)') 'bayt ', i, '   hex=', b, '   dec=', b
  end do
  print '(A,I0)', 'bayt sayisi     = ', nb
  print '(A,I0)', 'karakter sayisi = ', nc
end program utf8_baytlar
