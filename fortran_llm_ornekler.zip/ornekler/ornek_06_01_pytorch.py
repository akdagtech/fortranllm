# Örnek 6.1: Bir metnin baytları ve karakter sayısı (PyTorch karşılığı)
s = "Türkçe şiir"
b = s.encode("utf-8")                       # metin -> bayt dizisi
print("metin :", s)
for i, v in enumerate(b, 1):
    print(f"bayt {i:2d}   hex={v:02X}   dec={v:3d}")
print("bayt sayisi     =", len(b))
print("karakter sayisi =", len(s))
print("devam bayti olmayanlar =", sum(1 for v in b if (v & 0xC0) != 0x80))

