! Örnek 7.7: E-posta adreslerini maskele (PII temizliği)
! Derleme: gfortran -O2  ornek_07_07.f90 -o ornek
program pii_maske
  implicit none
  character(len=:), allocatable :: s, out, w
  integer :: i, j, n
  character(len=1) :: last
  s = 'Bana ali.veli@ornek.com adresinden yaz, ya da mehmet@site.org kullan.'
  n = len(s)
  out = ''
  i = 1
  do while (i <= n)
    j = index(s(i:), ' ')                         ! sonraki bosluk
    if (j == 0) then
      w = s(i:); i = n + 1
    else
      w = s(i:i+j-2); i = i + j
    end if
    if (is_email(w)) then
      last = w(len(w):len(w))
      if (last == ',' .or. last == '.') then
        w = '<EMAIL>' // last                     ! sondaki noktalamayi koru
      else
        w = '<EMAIL>'
      end if
    end if
    out = out // w // ' '
  end do
  print '(A,A)', 'once  : ', s
  print '(A,A)', 'sonra : ', trim(out)
contains
  function is_email(x) result(ok)
    character(len=*), intent(in) :: x
    logical :: ok
    integer :: a
    a = index(x, '@')
    ok = .false.
    if (a > 1) ok = index(x(a:), '.') > 0          ! @'dan sonra bir nokta
  end function is_email
end program pii_maske
