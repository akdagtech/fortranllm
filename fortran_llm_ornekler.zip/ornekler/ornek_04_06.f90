! Örnek 4.6: LayerNorm ve RMSNorm modülü
! Derleme: gfortran -O2  ornek_04_06.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module norm_mod
  use prec_mod
  implicit none
contains
  subroutine layernorm_rows(X, gamma, beta, Y)
    real(dp), intent(in)  :: X(:,:), gamma(:), beta(:)
    real(dp), intent(out) :: Y(:,:)
    real(dp) :: mu, v
    integer :: i
    do i = 1, size(X,1)
      mu = sum(X(i,:)) / size(X,2)
      v  = sum((X(i,:) - mu)**2) / size(X,2)
      Y(i,:) = gamma * (X(i,:) - mu) / sqrt(v + 1.0e-5_dp) + beta
    end do
  end subroutine layernorm_rows

  subroutine rmsnorm_rows(X, gamma, Y)
    real(dp), intent(in)  :: X(:,:), gamma(:)
    real(dp), intent(out) :: Y(:,:)
    integer :: i
    do i = 1, size(X,1)
      Y(i,:) = gamma * X(i,:) / sqrt(sum(X(i,:)**2) / size(X,2) + 1.0e-5_dp)
    end do
  end subroutine rmsnorm_rows
end module norm_mod

program norm_test
  use norm_mod
  implicit none
  real(dp) :: X(1,4), Y(1,4), g(4), b(4)
  X(1,:) = [1.0_dp, 2.0_dp, 3.0_dp, 4.0_dp]
  g = 1.0_dp; b = 0.0_dp
  call layernorm_rows(X, g, b, Y);        print '(A,4F9.4)', 'LayerNorm(x)    = ', Y(1,:)
  call rmsnorm_rows(X, g, Y);             print '(A,4F9.4)', 'RMSNorm(x)      = ', Y(1,:)
  call layernorm_rows(10*X, g, b, Y);     print '(A,4F9.4)', 'LayerNorm(10x)  = ', Y(1,:)
  call rmsnorm_rows(10*X, g, Y);          print '(A,4F9.4)', 'RMSNorm(10x)    = ', Y(1,:)
  call layernorm_rows(X + 100, g, b, Y);  print '(A,4F9.4)', 'LayerNorm(x+100)= ', Y(1,:)
end program norm_test
