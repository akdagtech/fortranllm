! Örnek 1.3: Matris çarpımı: elle ve matmul ile
! Derleme: gfortran -O2  ornek_01_03.f90 -o ornek
program matris
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: A(2,3), B(3,2), C(2,2), D(2,2)
  integer :: i, j, k
  ! order=[2,1] : degerleri satir satir yaz
  A = reshape([1,2,3, 4,5,6] * 1.0_dp, [2,3], order=[2,1])
  B = reshape([7,8, 9,10, 11,12] * 1.0_dp, [3,2], order=[2,1])
  C = 0.0_dp
  do i = 1, 2
    do j = 1, 2
      do k = 1, 3
        C(i,j) = C(i,j) + A(i,k) * B(k,j)
      end do
    end do
  end do
  D = matmul(A, B)
  do i = 1, 2
    print '(A,2F8.1)', 'C satiri: ', C(i,:)
  end do
  print '(A,ES10.2)', 'max |C - D| = ', maxval(abs(C - D))
end program matris
