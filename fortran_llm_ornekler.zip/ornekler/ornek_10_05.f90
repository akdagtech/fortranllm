! Örnek 10.5: KV cache ile ve cache'siz attention: aynı sonuç, daha az iş
! Derleme: gfortran -O2  ornek_10_05.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program kv_cache
  use rng_mod
  implicit none
  integer, parameter :: T = 6, d = 8
  real(dp) :: X(T,d), Wq(d,d), Wk(d,d), Wv(d,d)
  real(dp) :: o1(T,d), o2(T,d), K(T,d), V(T,d), Kc(T,d), Vc(T,d), q(d)
  integer :: t1, j, n_no, n_ca
  call rng_seed(14)
  call randn2(X, 1.0_dp)
  call randn2(Wq, 0.4_dp); call randn2(Wk, 0.4_dp); call randn2(Wv, 0.4_dp)
  n_no = 0; n_ca = 0
  ! (a) cache yok: her adimda tum gecmisin K,V'si yeniden hesaplanir
  do t1 = 1, T
    do j = 1, t1
      K(j,:) = matmul(X(j,:), Wk); V(j,:) = matmul(X(j,:), Wv); n_no = n_no + 1
    end do
    q = matmul(X(t1,:), Wq)
    o1(t1,:) = attend(q, K, V, t1)
  end do
  ! (b) KV cache: her adimda yalniz yeni tokenin k,v'si hesaplanir
  do t1 = 1, T
    Kc(t1,:) = matmul(X(t1,:), Wk); Vc(t1,:) = matmul(X(t1,:), Wv); n_ca = n_ca + 1
    q = matmul(X(t1,:), Wq)
    o2(t1,:) = attend(q, Kc, Vc, t1)
  end do
  print '(A,ES10.2)', 'max |cikti(cache yok) - cikti(cache)| = ', maxval(abs(o1 - o2))
  print '(A,I0)', 'K,V projeksiyon sayisi, cache yok : ', n_no
  print '(A,I0)', 'K,V projeksiyon sayisi, cache var : ', n_ca
contains
  function attend(q, K, V, n) result(o)               ! ilk n anahtar uzerinde attention
    real(dp), intent(in) :: q(d), K(:,:), V(:,:)
    integer, intent(in) :: n
    real(dp) :: o(d), s(n)
    integer :: j
    do j = 1, n
      s(j) = dot_product(q, K(j,:)) / sqrt(real(d, dp))
    end do
    s = exp(s - maxval(s)); s = s / sum(s)
    o = matmul(s, V(1:n,:))
  end function attend
end program kv_cache
