# Örnek 10.3: Top-k ve top-p filtreleri (PyTorch karşılığı)
import torch
z = torch.tensor([3.0, 2.5, 1.0, 0.5, 0.0, -1.0, -2.0], dtype=torch.float64)
p = torch.softmax(z, 0)
vals, idx = p.sort(descending=True)
pk = torch.zeros_like(p); top = torch.topk(p, 3); pk[top.indices] = top.values; pk /= pk.sum()      # top-k
cum = vals.cumsum(0)
nkeep = int((cum < 0.95).sum().item()) + 1                                                           # top-p
pp = torch.zeros_like(p); pp[idx[:nkeep]] = vals[:nkeep]; pp /= pp.sum()
f = lambda t: " ".join(f"{v:6.3f}" for v in t.tolist())
print("olasiliklar :", f(p)); print("top-k (k=3) :", f(pk)); print(f"top-p (0.95, {nkeep} token):", f(pp))

