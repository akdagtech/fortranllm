# Örnek 16.2: Lipinski, QED ve Tanimoto ile sanal tarama
import itertools, random
from rdkit import Chem, RDLogger
RDLogger.DisableLog('rdApp.*')

SUBS = ['F', 'Cl', 'Br', 'O', 'N', 'C', 'CC', 'C(=O)O', 'OC', 'C#N', 'N(C)C', 'S', 'C(F)(F)F', 'C(=O)N', 'OC(C)=O']
def make_dataset(seed=0, n_max=900):
    """Kucuk ama cesitli bir molekul veri kumesi: zincirler, halkalar, fonksiyonel gruplar."""
    random.seed(seed); smis = set()
    for L in range(1, 7):                                    # alifatik zincirler + fonksiyonel grup
        chain = 'C' * L
        for g in SUBS:
            for pos in range(L):
                smis.add(chain[:pos + 1] + '(' + g + ')' + chain[pos + 1:] if pos < L - 1 else chain + g)
    rings = ['c1ccccc1', 'c1ccncc1', 'c1ccoc1', 'c1ccsc1', 'C1CCCCC1', 'C1CCNCC1', 'C1CCOC1']
    for ring in rings:                                       # halkalar + tek sustituent
        for g in SUBS:
            smis.add(ring.replace('c1', 'c1(' + g + ')', 1) if ring.startswith('c1')
                     else ring.replace('C1', 'C1(' + g + ')', 1))
    for g1, g2 in itertools.product(SUBS, SUBS):             # iki sustituentli benzen / sikloheksan
        smis.add('c1(' + g1 + ')ccc(' + g2 + ')cc1'); smis.add('c1(' + g1 + ')cccc(' + g2 + ')c1')
        smis.add('C1(' + g1 + ')CCC(' + g2 + ')CC1')
    out = []
    for s in sorted(smis):
        m = Chem.MolFromSmiles(s)
        if m is not None and m.GetNumHeavyAtoms() <= 22: out.append(Chem.MolToSmiles(m))
    out = sorted(set(out)); random.shuffle(out)
    return out[:n_max]
import numpy as np
from rdkit import Chem, DataStructs
from rdkit.Chem import Descriptors, Crippen, Lipinski, QED, AllChem

drugs = {
    "aspirin":      "CC(=O)Oc1ccccc1C(=O)O",
    "parasetamol":  "CC(=O)Nc1ccc(O)cc1",
    "ibuprofen":    "CC(C)Cc1ccc(cc1)C(C)C(=O)O",
    "kafein":       "Cn1cnc2c1c(=O)n(C)c(=O)n2C",
    "metformin":    "CN(C)C(=N)N=C(N)N",
    "diazepam":     "CN1C(=O)CN=C(c2ccccc2)c2cc(Cl)ccc12",
    "atorvastatin": "CC(C)c1c(C(=O)Nc2ccccc2)c(-c2ccccc2)c(-c2ccc(F)cc2)n1CCC(O)CC(O)CC(=O)O",
}
print(f"{'ilac':13s}{'MW':>8s}{'logP':>7s}{'HBD':>5s}{'HBA':>5s}{'TPSA':>7s}{'RotB':>6s}{'Lipinski ihlal':>16s}{'QED':>7s}")
for ad, smi in drugs.items():
    m = Chem.MolFromSmiles(smi)
    mw, lp, hbd, hba = Descriptors.MolWt(m), Crippen.MolLogP(m), Lipinski.NumHDonors(m), Lipinski.NumHAcceptors(m)
    viol = int(mw > 500) + int(lp > 5) + int(hbd > 5) + int(hba > 10)             # Lipinski "5 kurali"
    print(f"{ad:13s}{mw:8.1f}{lp:7.2f}{hbd:5d}{hba:5d}{Descriptors.TPSA(m):7.1f}{Descriptors.NumRotatableBonds(m):6d}{viol:16d}{QED.qed(m):7.2f}")

# --- benzerlik tabanli sanal tarama: aspirine en cok benzeyen moleküller (Tanimoto, Morgan r=2)
fp = lambda m: AllChem.GetMorganFingerprintAsBitVect(m, 2, 2048)
query = fp(Chem.MolFromSmiles(drugs["aspirin"]))
lib = make_dataset(); mols = [Chem.MolFromSmiles(s) for s in lib]
sim = DataStructs.BulkTanimotoSimilarity(query, [fp(m) for m in mols])
order = np.argsort(sim)[::-1][:6]
print("\naspirine en benzer 6 molekul (kutuphane: %d molekul):" % len(lib))
for i in order: print(f"  Tanimoto = {sim[i]:.3f}   {lib[i]:28s} QED = {QED.qed(mols[i]):.2f}")
a, b = fp(Chem.MolFromSmiles(drugs["aspirin"])), fp(Chem.MolFromSmiles(drugs["parasetamol"]))
print(f"\nTanimoto(aspirin, parasetamol) = {DataStructs.TanimotoSimilarity(a, b):.3f}")
