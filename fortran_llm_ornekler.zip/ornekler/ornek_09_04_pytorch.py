# Örnek 9.4: Veri paralelliğini simüle et: all-reduce = tam batch gradyanı (PyTorch karşılığı)
import torch
torch.manual_seed(3)
N, W = 32, 4
x = torch.randn(N, dtype=torch.float64); y = 3 * x - 1 + 0.2 * torch.randn(N, dtype=torch.float64)
w = torch.tensor([0.5, 0.0], dtype=torch.float64, requires_grad=True)
def grad(xs, ys):
    w.grad = None
    ((w[0] * xs + w[1] - ys) ** 2).mean().backward()
    return w.grad.clone()
g_full = grad(x, y)
g_loc = torch.stack([grad(x[k*8:(k+1)*8], y[k*8:(k+1)*8]) for k in range(W)])   # her "isci"
for k in range(W): print(f"isci {k+1} yerel gradyan :", [round(v, 5) for v in g_loc[k].tolist()])
g_avg = g_loc.mean(0)                           # all-reduce (ortalama)
print("all-reduce ortalama  :", [round(v, 5) for v in g_avg.tolist()])
print("tek isci tam batch   :", [round(v, 5) for v in g_full.tolist()])
print("fark =", (g_avg - g_full).abs().max().item())
# gercek dagitik egitimde: dist.all_reduce(p.grad); p.grad /= world_size   (DistributedDataParallel bunu otomatik yapar)

