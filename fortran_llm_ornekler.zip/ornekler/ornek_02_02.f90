! Örnek 2.2: Aktivasyon fonksiyonları tablosu ve türev kontrolü
! Derleme: gfortran -O2  ornek_02_02.f90 -o ornek
module act
  implicit none
  integer, parameter :: dp = kind(1.0d0)
contains
  elemental function sigmoid(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = 1.0_dp / (1.0_dp + exp(-x))
  end function sigmoid
  elemental function relu(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = max(0.0_dp, x)
  end function relu
  elemental function gelu(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = 0.5_dp * x * (1.0_dp + tanh(0.7978845608028654_dp * (x + 0.044715_dp * x**3)))
  end function gelu
end module act

program aktivasyon
  use act
  implicit none
  integer :: i
  real(dp) :: x0, h, ds, dt, ds_n, dt_n, xi
  print '(A)', '     x   sigmoid     tanh     relu     gelu'
  do i = -3, 3
    xi = real(i, dp)
    print '(F6.1,4F9.4)', xi, sigmoid(xi), tanh(xi), relu(xi), gelu(xi)
  end do
  x0 = 0.7_dp; h = 1.0e-6_dp
  ds = sigmoid(x0) * (1.0_dp - sigmoid(x0))
  dt = 1.0_dp - tanh(x0)**2
  ds_n = (sigmoid(x0+h) - sigmoid(x0-h)) / (2*h)
  dt_n = (tanh(x0+h) - tanh(x0-h)) / (2*h)
  print '(A,2F12.8)', 'sigmoid turev (formul, sayisal): ', ds, ds_n
  print '(A,2F12.8)', 'tanh    turev (formul, sayisal): ', dt, dt_n
end program aktivasyon
