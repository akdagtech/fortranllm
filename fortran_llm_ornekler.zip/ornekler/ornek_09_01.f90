! Örnek 9.1: GPT-2 ailesinin parametre sayısı
! Derleme: gfortran -O2  ornek_09_01.f90 -o ornek
program param_say
  implicit none
  call say('GPT-2 small ', 50257_8, 1024_8,  768_8, 12_8)
  call say('GPT-2 medium', 50257_8, 1024_8, 1024_8, 24_8)
  call say('GPT-2 large ', 50257_8, 1024_8, 1280_8, 36_8)
  call say('GPT-2 XL    ', 50257_8, 1024_8, 1600_8, 48_8)
contains
  subroutine say(name, V, T, d, L)
    character(len=*), intent(in) :: name
    integer(8), intent(in) :: V, T, d, L
    integer(8) :: per_layer, emb, total
    per_layer = 12*d*d + 13*d
    emb   = V*d + T*d
    total = emb + L*per_layer + 2*d
    print '(A,A,I12,A,F7.2,A,F6.1,A)', name, ' : ', total, ' parametre (', real(total)/1.0e6, &
          ' M)   embedding payi %', 100.0*real(emb)/real(total), ''
  end subroutine say
end program param_say
