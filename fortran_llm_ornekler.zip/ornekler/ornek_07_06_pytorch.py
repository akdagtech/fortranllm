# Örnek 7.6: Token akışını paketle, ikili dosyaya yaz, rastgele erişimle oku (PyTorch karşılığı)
import numpy as np
EOS = 1
d1, d2, d3 = [5, 6, 7], [8, 9], [10, 11, 12, 13, 14]
stream = np.array(d1 + [EOS] + d2 + [EOS] + d3 + [EOS], dtype=np.int32)
stream.tofile("veri.bin")                     # ikili dosya (her token 4 bayt)
mm = np.memmap("veri.bin", dtype=np.int32, mode="r")   # dosyayi bellege yuklemeden eris
T_ = 4
print(f"akis uzunlugu = {len(stream)} token, dosya = {mm.nbytes} bayt")
for k in range((len(mm) - 1) // T_):
    i = k * T_
    x, y = mm[i:i + T_], mm[i + 1:i + T_ + 1]            # y: bir kaydirilmis hedef
    print("x =", " ".join(f"{v:3d}" for v in x), "   y =", " ".join(f"{v:3d}" for v in y))

