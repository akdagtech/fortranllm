! Örnek 10.6: KV cache belleği ve kayan pencere (sliding window)
! Derleme: gfortran -O2  ornek_10_06.f90 -o ornek
program kv_bellek
  implicit none
  integer, parameter :: W = 8
  integer(8) :: b
  integer :: toks(12), t, n, i
  b = kvbytes(12_8, 1024_8, 768_8, 2_8)
  print '(A,F9.1,A)', 'GPT-2 small (L=12,  d=768,  T=1024): ', real(b)/1.0e6, ' MB'
  b = kvbytes(32_8, 4096_8, 4096_8, 2_8)
  print '(A,F9.2,A)', '7B tipi     (L=32,  d=4096, T=4096): ', real(b)/1.0e9, ' GB'
  b = kvbytes(80_8, 4096_8, 8192_8, 2_8)
  print '(A,F9.2,A)', '70B tipi    (L=80,  d=8192, T=4096): ', real(b)/1.0e9, ' GB'
  toks = [(i, i = 100, 111)]                         ! uretilen token kimlikleri; ilki BOS
  print '(A)', 'pencere = 8 token, BOS (ilk token) her zaman korunur:'
  do t = 8, 12
    n = min(t, W)
    if (t <= W) then
      print '(A,I2,A,12I4)', 'adim ', t, ' : ', toks(1:t)
    else
      print '(A,I2,A,12I4)', 'adim ', t, ' : ', toks(1), toks(t-W+2:t)   ! BOS + son W-1
    end if
  end do
contains
  function kvbytes(L, T, d, bytes) result(r)
    integer(8), intent(in) :: L, T, d, bytes
    integer(8) :: r
    r = 2_8 * L * T * d * bytes
  end function kvbytes
end program kv_bellek
