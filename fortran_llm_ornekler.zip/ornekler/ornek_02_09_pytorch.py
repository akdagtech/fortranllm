# Örnek 2.9: BatchNorm ile LayerNorm: eksen farkı (PyTorch karşılığı)
import torch, torch.nn as nn
X = torch.tensor([[1., 2], [3, 6], [5, 10]])
bn = nn.BatchNorm1d(2, affine=False, eps=1e-5)    # batch ekseni (sutun bazli)
ln = nn.LayerNorm(2, elementwise_affine=False, eps=1e-5)   # ozellik ekseni (satir bazli)
bn.train()
print("BatchNorm:"); print(bn(X))
print("LayerNorm:"); print(ln(X))

