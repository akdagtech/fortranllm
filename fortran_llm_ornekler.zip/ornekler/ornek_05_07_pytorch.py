# Örnek 5.7: Gradient accumulation = büyük batch (PyTorch karşılığı)
import torch
x = torch.tensor([0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0], dtype=torch.float64)
y = torch.tensor([1.2, 1.9, 3.1, 3.8, 5.2, 5.9, 7.1, 7.8], dtype=torch.float64)
w = torch.tensor(0.3, dtype=torch.float64, requires_grad=True)
loss = ((w * x - y) ** 2).mean(); loss.backward()
g_full = w.grad.item(); w.grad = None
for mb in range(4):                              # 4 mikro-batch, gradyanlar .grad icinde birikir
    xs, ys = x[2*mb:2*mb+2], y[2*mb:2*mb+2]
    (((w * xs - ys) ** 2).mean() / 4).backward() # mikro-batch sayisina bol
g_acc = w.grad.item(); w.grad = None
for mb in range(4):
    xs, ys = x[2*mb:2*mb+2], y[2*mb:2*mb+2]
    ((w * xs - ys) ** 2).mean().backward()       # bolmeyi unutursak
g_wrong = w.grad.item()
print(f"tam batch gradyani        : {g_full:12.6f}")
print(f"birikmis gradyan (dogru)  : {g_acc:12.6f}")
print(f"birikmis gradyan (yanlis) : {g_wrong:12.6f}")

