! Örnek 1.6: Kısmi türevler ve gradyanın yönü
! Derleme: gfortran -O2  ornek_01_06.f90 -o ornek
program gradyan
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x, y, h, gx, gy, nx, ny, u(2), gn, d1, d2
  x = 1.0_dp; y = 2.0_dp; h = 1.0e-6_dp
  print '(A,2F9.4)', 'formul   grad = ', 2*x+3*y, 3*x+2*y
  nx = (f(x+h,y) - f(x-h,y)) / (2*h)
  ny = (f(x,y+h) - f(x,y-h)) / (2*h)
  print '(A,2F9.4)', 'sayisal  grad = ', nx, ny
  gx = 2*x+3*y; gy = 3*x+2*y
  gn = sqrt(gx**2 + gy**2)
  u = [gx, gy] / gn                        ! gradyan yonunde birim vektor
  d1 = (f(x+h*u(1), y+h*u(2)) - f(x,y)) / h
  print '(A,F9.4)', '|grad|                    = ', gn
  print '(A,F9.4)', 'gradyan yonundeki egim   = ', d1
  u = [1.0_dp, 0.0_dp]                     ! x ekseni yonu
  d2 = (f(x+h*u(1), y+h*u(2)) - f(x,y)) / h
  print '(A,F9.4)', 'x ekseni yonundeki egim = ', d2
contains
  function f(a, b) result(r)
    real(dp), intent(in) :: a, b
    real(dp) :: r
    r = a**2 + 3*a*b + b**2
  end function f
end program gradyan
