! Örnek 10.2: Temperature dağılımı nasıl değiştirir?
! Derleme: gfortran -O2  ornek_10_02.f90 -o ornek
program sicaklik
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: z(5), p(5), ts(5), ent
  integer :: k
  z = [2.0_dp, 1.0_dp, 0.5_dp, 0.0_dp, -1.0_dp]
  ts = [0.2_dp, 0.5_dp, 1.0_dp, 2.0_dp, 5.0_dp]
  print '(A)', '    T     p1      p2      p3      p4      p5    entropi'
  do k = 1, 5
    p = exp((z - maxval(z)) / ts(k))
    p = p / sum(p)
    ent = -sum(p * log(p))
    print '(F6.1,5F8.4,F9.4)', ts(k), p, ent
  end do
  print '(A,F8.4)', 'azami entropi ln 5 = ', log(5.0_dp)
end program sicaklik
