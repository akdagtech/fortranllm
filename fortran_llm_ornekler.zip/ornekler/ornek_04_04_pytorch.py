# Örnek 4.4: Projeksiyonlu attention ve nedensellik (causality) testi (PyTorch karşılığı)
import torch, math
import torch.nn as nn
import torch.nn.functional as F
torch.manual_seed(21)
T_, d = 6, 8
Wq, Wk, Wv = (nn.Linear(d, d, bias=False) for _ in range(3))
def attn(X):
    return F.scaled_dot_product_attention(Wq(X), Wk(X), Wv(X), is_causal=True)
X = torch.randn(T_, d)
X2 = X.clone(); X2[-1] += 5.0              # SON token'i degistir
O1, O2 = attn(X), attn(X2)
print("ilk 5 satirin degisimi (max) =", (O1[:-1] - O2[:-1]).abs().max().item())
print("son satirin degisimi (max)   =", (O1[-1] - O2[-1]).abs().max().item())

