! Örnek 3.3: Kötü koşullanmış yüzeyde GD, Momentum ve Adam
! Derleme: gfortran -O2  ornek_03_03.f90 -o ornek
program karsilastir
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer, parameter :: show(6) = [1, 10, 20, 50, 100, 200]
  real(dp) :: p(2), g(2), v(2), m(2), s(2), lr, beta, b1, b2, eps
  real(dp) :: fgd(6), fmo(6), fad(6), mh(2), sh(2)
  integer :: k, j
  ! ---- duz gradyan inisi
  p = [5.0_dp, 5.0_dp]; lr = 0.0099_dp
  do k = 1, 200
    g = [2.0_dp*p(1), 200.0_dp*p(2)]
    p = p - lr * g
    do j = 1, 6
      if (k == show(j)) fgd(j) = p(1)**2 + 100.0_dp*p(2)**2
    end do
  end do
  ! ---- momentum
  p = [5.0_dp, 5.0_dp]; v = 0.0_dp; lr = 0.01_dp; beta = 0.9_dp
  do k = 1, 200
    g = [2.0_dp*p(1), 200.0_dp*p(2)]
    v = beta * v + g
    p = p - lr * v
    do j = 1, 6
      if (k == show(j)) fmo(j) = p(1)**2 + 100.0_dp*p(2)**2
    end do
  end do
  ! ---- Adam
  p = [5.0_dp, 5.0_dp]; m = 0.0_dp; s = 0.0_dp
  lr = 0.3_dp; b1 = 0.9_dp; b2 = 0.999_dp; eps = 1.0e-8_dp
  do k = 1, 200
    g = [2.0_dp*p(1), 200.0_dp*p(2)]
    m = b1*m + (1.0_dp - b1)*g
    s = b2*s + (1.0_dp - b2)*g**2
    mh = m / (1.0_dp - b1**k)
    sh = s / (1.0_dp - b2**k)
    p = p - lr * mh / (sqrt(sh) + eps)
    do j = 1, 6
      if (k == show(j)) fad(j) = p(1)**2 + 100.0_dp*p(2)**2
    end do
  end do
  print '(A)', '  adim          GD      Momentum          Adam'
  do j = 1, 6
    print '(I6,3ES14.3)', show(j), fgd(j), fmo(j), fad(j)
  end do
end program karsilastir
