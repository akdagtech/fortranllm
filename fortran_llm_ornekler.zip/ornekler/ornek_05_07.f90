! Örnek 5.7: Gradient accumulation = büyük batch
! Derleme: gfortran -O2  ornek_05_07.f90 -o ornek
program grad_accum
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x(8), y(8), w, g_full, g_acc, g_wrong, gm
  integer :: mb, i
  x = [0.5_dp, 1.0_dp, 1.5_dp, 2.0_dp, 2.5_dp, 3.0_dp, 3.5_dp, 4.0_dp]
  y = [1.2_dp, 1.9_dp, 3.1_dp, 3.8_dp, 5.2_dp, 5.9_dp, 7.1_dp, 7.8_dp]
  w = 0.3_dp
  ! tam batch: L = ortalama (w x - y)^2   ->  dL/dw = ortalama 2 (w x - y) x
  g_full = sum(2.0_dp * (w*x - y) * x) / 8
  g_acc = 0.0_dp; g_wrong = 0.0_dp
  do mb = 1, 4                                       ! her biri 2 orneklik 4 mikro-batch
    i = 2*(mb-1) + 1
    gm = sum(2.0_dp * (w*x(i:i+1) - y(i:i+1)) * x(i:i+1)) / 2   ! mikro-batch ortalamasi
    g_acc   = g_acc   + gm / 4                       ! dogru: mikro-batch sayisina bol
    g_wrong = g_wrong + gm                           ! yanlis: bolmedik
  end do
  print '(A,F12.6)', 'tam batch gradyani        : ', g_full
  print '(A,F12.6)', 'birikmis gradyan (dogru)  : ', g_acc
  print '(A,F12.6)', 'birikmis gradyan (yanlis) : ', g_wrong
end program grad_accum
