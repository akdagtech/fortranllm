! Örnek 8.4: Global norm ile gradyan kırpma
! Derleme: gfortran -O2  ornek_08_04.f90 -o ornek
program kirpma
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: g1(2), g2(2), gnorm, c, scale, h1(2), h2(2)
  g1 = [3.0_dp, 4.0_dp]
  g2 = [0.0_dp, 12.0_dp]
  c = 1.0_dp
  gnorm = sqrt(sum(g1**2) + sum(g2**2))                 ! butun tensorlerin ortak normu
  print '(A,F8.4)', 'global norm (once) = ', gnorm
  scale = min(1.0_dp, c / gnorm)                        ! esigi asmiyorsa 1
  g1 = g1 * scale; g2 = g2 * scale
  print '(A,F8.4)', 'carpan             = ', scale
  print '(A,2F9.5,A,2F9.5)', 'g1, g2 (sonra)     = ', g1, '  ', g2
  print '(A,F8.4)', 'global norm (sonra)= ', sqrt(sum(g1**2) + sum(g2**2))
  h1 = [0.3_dp, 0.4_dp]; h2 = [0.0_dp, 0.2_dp]          ! kucuk gradyan
  gnorm = sqrt(sum(h1**2) + sum(h2**2))
  scale = min(1.0_dp, c / gnorm)
  print '(A,F8.4,A,F6.3)', 'kucuk gradyan: norm = ', gnorm, '   carpan = ', scale
end program kirpma
