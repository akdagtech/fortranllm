# Örnek 1.4: Sayısal türev ve adım boyutu h (PyTorch karşılığı)
import torch
x = torch.tensor(2.0, dtype=torch.float64, requires_grad=True)
y = x ** 3
y.backward()                               # otomatik turev (autograd)
print("autograd turevi  :", x.grad.item(), "  (gercek 3x^2 = 12)")
for k in range(1, 13):                     # Fortran'daki sayisal turev
    h = 10.0 ** (-k)
    num = ((2 + h) ** 3 - (2 - h) ** 3) / (2 * h)
    print(f"h={h:8.1e}  turev={num:16.10f}  hata={abs(num - 12):9.2e}")

