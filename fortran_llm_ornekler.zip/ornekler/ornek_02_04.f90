! Örnek 2.4: Dört kayıp fonksiyonunu hesapla
! Derleme: gfortran -O2  ornek_02_04.f90 -o ornek
program kayiplar
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: y(4), yh(4)
  y  = [1.0_dp, 0.0_dp, 1.0_dp, 1.0_dp]
  yh = [0.9_dp, 0.2_dp, 0.6_dp, 0.99_dp]
  print '(A,F8.5)', 'MSE = ', sum((yh - y)**2) / 4
  print '(A,F8.5)', 'MAE = ', sum(abs(yh - y)) / 4
  print '(A,F8.5)', 'BCE = ', -sum(y*log(yh) + (1-y)*log(1-yh)) / 4
  print '(A)', 'Gercek sinif 1 iken tahmin olasiligi p icin -log(p):'
  print '(A,F8.4)', '  p=0.99 : ', -log(0.99_dp)
  print '(A,F8.4)', '  p=0.50 : ', -log(0.50_dp)
  print '(A,F8.4)', '  p=0.01 : ', -log(0.01_dp)
end program kayiplar
