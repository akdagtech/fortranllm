# Örnek 7.4: Yaklaşık tekrarlar: Jaccard benzerliği (PyTorch karşılığı)
docs = ["turkce dil modeli egitmek icin temiz ve cesitli veri gerekir",
        "turkce dil modeli egitmek icin temiz ve guvenilir veri gerekir",
        "bugun aksam sahilde yuruyus yapip cay icmeyi planliyoruz"]
sh = lambda s: {s[i:i + 3] for i in range(len(s) - 2)}       # karakter 3-gramlari
S = [sh(d) for d in docs]
print("Jaccard benzerlik matrisi:")
for a in S:
    print("".join(f"{len(a & b) / len(a | b):8.3f}" for b in S))
print("belge 1 icin 3-gram sayisi:", len(S[0]))

