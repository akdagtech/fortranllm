! Örnek 2.7: Yoğun katmanın toplu geri geçişi
! Derleme: gfortran -O2  ornek_02_07.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program dense
  use rng_mod
  implicit none
  integer, parameter :: B = 3, nin = 4, nout = 2
  real(dp) :: X(B,nin), W(nin,nout), bias(nout), Y(B,nout), dY(B,nout)
  real(dp) :: dW(nin,nout), db(nout), dX(B,nin), eps, old, num
  call rng_seed(1)
  call randn2(X, 1.0_dp); call randn2(W, 0.5_dp)
  bias = [0.1_dp, -0.2_dp]; eps = 1.0e-6_dp
  Y  = matmul(X, W) + spread(bias, 1, B)
  dY = Y                                   ! L = 0.5*sum(Y^2) icin dL/dY = Y
  dW = matmul(transpose(X), dY)
  db = sum(dY, dim=1)
  dX = matmul(dY, transpose(W))
  old = W(2,1)
  W(2,1) = old + eps; num = L()
  W(2,1) = old - eps; num = (num - L()) / (2*eps)
  W(2,1) = old
  print '(A,2F12.7)', 'dW(2,1): geri yayilim, sayisal = ', dW(2,1), num
  old = bias(2)
  bias(2) = old + eps; num = L()
  bias(2) = old - eps; num = (num - L()) / (2*eps)
  bias(2) = old
  print '(A,2F12.7)', 'db(2)  : geri yayilim, sayisal = ', db(2), num
  old = X(3,4)
  X(3,4) = old + eps; num = L()
  X(3,4) = old - eps; num = (num - L()) / (2*eps)
  X(3,4) = old
  print '(A,2F12.7)', 'dX(3,4): geri yayilim, sayisal = ', dX(3,4), num
contains
  function L() result(r)
    real(dp) :: r
    r = 0.5_dp * sum((matmul(X, W) + spread(bias, 1, B))**2)
  end function L
end program dense
