# Örnek 1.5: Zincir kuralını sayısal olarak doğrula (PyTorch karşılığı)
import torch
x = torch.tensor(1.5, dtype=torch.float64, requires_grad=True)
h = torch.sin(x ** 2)
h.backward()
g = x ** 2
zincir = torch.cos(g) * 2 * x              # dh/dg * dg/dx
print(f"autograd      : {x.grad.item():12.8f}")
print(f"zincir kurali : {zincir.item():12.8f}")
eps = 1e-6
num = (torch.sin((x + eps) ** 2) - torch.sin((x - eps) ** 2)) / (2 * eps)
print(f"sayisal turev : {num.item():12.8f}")

