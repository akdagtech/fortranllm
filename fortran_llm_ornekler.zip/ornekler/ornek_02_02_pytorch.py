# Örnek 2.2: Aktivasyon fonksiyonları tablosu ve türev kontrolü (PyTorch karşılığı)
import torch
import torch.nn.functional as F
x = torch.arange(-3., 4., dtype=torch.float64)
print("     x   sigmoid     tanh     relu     gelu")
for v in x:
    print(f"{v:6.1f}{torch.sigmoid(v):9.4f}{torch.tanh(v):9.4f}{F.relu(v):9.4f}{F.gelu(v, approximate='tanh'):9.4f}")
x0 = torch.tensor(0.7, dtype=torch.float64, requires_grad=True)
ds, = torch.autograd.grad(torch.sigmoid(x0), x0)     # autograd turevi
dt, = torch.autograd.grad(torch.tanh(x0), x0)
s = torch.sigmoid(x0.detach())
print("sigmoid turev (formul, autograd):", f"{(s*(1-s)).item():.8f} {ds.item():.8f}")
print("tanh    turev (formul, autograd):", f"{(1-torch.tanh(x0.detach())**2).item():.8f} {dt.item():.8f}")

