# Örnek 3.5: L2 düzenlemesi ile AdamW sönümü (PyTorch karşılığı)
import torch
w1 = torch.tensor(1.0, dtype=torch.float64, requires_grad=True)   # Adam + L2 (weight_decay gradyana eklenir)
w2 = torch.tensor(1.0, dtype=torch.float64, requires_grad=True)   # AdamW (ayrik sonum)
o1 = torch.optim.Adam([w1], lr=0.1, weight_decay=0.1)
o2 = torch.optim.AdamW([w2], lr=0.1, weight_decay=0.1)
print(" adim   Adam+L2(w)   AdamW(w)")
for t in range(1, 11):
    w1.grad = torch.zeros((), dtype=torch.float64)    # kayip gradyani 0: yalniz sonum etkili
    w2.grad = torch.zeros((), dtype=torch.float64)
    o1.step(); o2.step()
    print(f"{t:5d}{w1.item():13.6f}{w2.item():13.6f}")

