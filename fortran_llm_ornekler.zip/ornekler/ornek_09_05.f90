! Örnek 9.5: MLP'yi iki "GPU"ya böl: sütun + satır paralelliği
! Derleme: gfortran -O2  ornek_09_05.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program tensor_paralel
  use rng_mod
  implicit none
  integer, parameter :: T = 4, d = 6, h = 8, hh = h / 2
  real(dp) :: X(T,d), W1(d,h), W2(h,d), Y(T,d), Ya(T,d), Yb(T,d), Ha(T,hh), Hb(T,hh)
  call rng_seed(12)
  call randn2(X, 1.0_dp); call randn2(W1, 0.5_dp); call randn2(W2, 0.5_dp)
  ! tek parca
  Y = matmul(gelu(matmul(X, W1)), W2)
  ! cihaz A: W1'in ilk 4 sutunu, W2'nin ilk 4 satiri; cihaz B: kalanlar
  Ha = gelu(matmul(X, W1(:, 1:hh)))                 ! iletisim yok
  Hb = gelu(matmul(X, W1(:, hh+1:h)))
  Ya = matmul(Ha, W2(1:hh, :))                      ! kismi toplamlar
  Yb = matmul(Hb, W2(hh+1:h, :))
  print '(A,ES10.2)', 'max |Y - (Ya + Yb)| = ', maxval(abs(Y - (Ya + Yb)))   ! tek all-reduce
  print '(A,I0,A,I0)', 'cihaz basina W1 sutunu: ', hh, ' / ', h
contains
  elemental function gelu(z) result(r)
    real(dp), intent(in) :: z
    real(dp) :: r
    r = 0.5_dp * z * (1.0_dp + tanh(0.7978845608028654_dp * (z + 0.044715_dp * z**3)))
  end function gelu
end program tensor_paralel
