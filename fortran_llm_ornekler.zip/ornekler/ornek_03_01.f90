! Örnek 3.1: Mini-batch SGD ile doğru uydurma
! Derleme: gfortran -O2  ornek_03_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program sgd_dogru
  use rng_mod
  implicit none
  integer, parameter :: n = 100, bs = 10
  real(dp) :: x(n), y(n), w, b, lr, gw, gb, r, xm, ym, wols, bols, loss
  integer :: i, ep, s
  call rng_seed(11)
  do i = 1, n
    x(i) = 2.0_dp * uniform() - 1.0_dp
    y(i) = 2.0_dp * x(i) + 1.0_dp + 0.1_dp * gauss()
  end do
  w = 0.0_dp; b = 0.0_dp; lr = 0.1_dp
  do ep = 0, 50
    if (mod(ep, 10) == 0) then
      loss = sum((w*x + b - y)**2) / n
      print '(A,I3,A,F8.4,A,F8.4,A,F9.5)', 'epoch ', ep, '  w=', w, '  b=', b, '  kayip=', loss
    end if
    do s = 1, n, bs                       ! her epoch'ta 10 mini-batch
      r  = 0.0_dp
      gw = 0.0_dp; gb = 0.0_dp
      do i = s, s + bs - 1
        r  = w*x(i) + b - y(i)            ! hata
        gw = gw + 2.0_dp * r * x(i)
        gb = gb + 2.0_dp * r
      end do
      w = w - lr * gw / bs
      b = b - lr * gb / bs
    end do
  end do
  xm = sum(x)/n; ym = sum(y)/n           ! analitik cozum
  wols = sum((x-xm)*(y-ym)) / sum((x-xm)**2)
  bols = ym - wols*xm
  print '(A,F8.4,A,F8.4)', 'en kucuk kareler: w=', wols, '  b=', bols
end program sgd_dogru
