# Örnek 16.4: Autograd ile fonksiyonel türev ve öğrenilmiş korelasyon fonksiyoneli
import torch, torch.nn as nn, numpy as np, math
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
torch.manual_seed(0); torch.set_default_dtype(torch.float64)
pi = math.pi
def pw92(rs):                                            # Fortran Ornek 14.1'deki ayni formul
    A, a1, b1, b2, b3, b4 = 0.0310907, 0.21370, 7.5957, 3.5876, 1.6382, 0.49294
    return -2 * A * (1 + a1 * rs) * torch.log(1 + 1 / (2 * A * (b1 * rs.sqrt() + b2 * rs + b3 * rs ** 1.5 + b4 * rs ** 2)))
# (1) degisim: E_x[n] = integral n eps_x(n) d^3r  ->  v_x = dE_x/dn, AUTOGRAD ile
h = 0.01; r = torch.arange(1, 800) * h
n = (torch.exp(-2 * r) / pi).requires_grad_(True)       # H atomu 1s yogunlugu
eps_x = -0.75 * (3 / pi) ** (1 / 3) * n ** (1 / 3)
Ex = (4 * pi * r ** 2 * n * eps_x).sum() * h
Ex.backward()
vx_autograd = n.grad / (4 * pi * r ** 2 * h)             # fonksiyonel turev = gradyan / hacim elemani
vx_formula = (4 / 3) * eps_x.detach()
idx = [10, 50, 100, 200]
print("E_x[n] =", round(Ex.item(), 5), "Eh   (H atomu 1s icin LDA degisimi; tam: -0.3125)")
print("   r        v_x (autograd)    (4/3) eps_x")
for i in idx: print(f"{r[i].item():6.2f}{vx_autograd[i].item():18.6f}{vx_formula[i].item():16.6f}")
# (2) korelasyon: PW92'yi bir sinir agina OGRET, sonra v_c = eps_c - (rs/3) d eps_c/d rs'yi autograd ile bul
rs_tr = torch.exp(torch.linspace(math.log(0.3), math.log(12), 400))
net = nn.Sequential(nn.Linear(1, 32), nn.Tanh(), nn.Linear(32, 32), nn.Tanh(), nn.Linear(32, 1))
f = lambda rs: net(torch.log(rs)[..., None]).squeeze(-1)
opt = torch.optim.Adam(net.parameters(), lr=5e-3)
for ep in range(1, 4001):
    loss = ((f(rs_tr) - pw92(rs_tr)) ** 2).mean()
    opt.zero_grad(); loss.backward(); opt.step()
    if ep in (1, 1000, 4000): print(f"epoch {ep:5d}  MSE = {loss.item():.2e}")
rs = torch.tensor([0.5, 1.0, 2.0, 4.0, 8.0], requires_grad=True)
def vc(fun, rs):
    e = fun(rs); d, = torch.autograd.grad(e.sum(), rs, create_graph=True)
    return e - rs / 3 * d
print("  rs     eps_c(NN)   eps_c(PW92)     v_c(NN, autograd)   v_c(PW92)")
for a, b, c, d_ in zip(rs, f(rs), pw92(rs), zip(vc(f, rs), vc(pw92, rs))):
    print(f"{a.item():5.1f}{b.item():12.5f}{c.item():13.5f}{d_[0].item():20.5f}{d_[1].item():13.5f}")
x = torch.linspace(0.3, 12, 300, requires_grad=True)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
ax[0].plot(x.detach(), pw92(x).detach(), c="#1d3557", label="PW92 (analitik)"); ax[0].plot(x.detach(), f(x).detach(), "--", c="#e76f51", label="sinir agi")
ax[0].set_xlabel("r_s"); ax[0].set_ylabel("eps_c (Eh)"); ax[0].legend(); ax[0].set_title("Korelasyon enerjisini ogrenmek")
ax[1].plot(x.detach(), vc(pw92, x).detach(), c="#1d3557", label="v_c PW92"); ax[1].plot(x.detach(), vc(f, x).detach(), "--", c="#e76f51", label="v_c (NN, autograd)")
ax[1].set_xlabel("r_s"); ax[1].set_ylabel("v_c (Eh)"); ax[1].legend(); ax[1].set_title("Potansiyel = fonksiyonel turev")
plt.tight_layout(); plt.savefig("f_nn_xc.png", dpi=170)
