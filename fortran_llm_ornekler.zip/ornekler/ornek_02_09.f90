! Örnek 2.9: BatchNorm ile LayerNorm: eksen farkı
! Derleme: gfortran -O2  ornek_02_09.f90 -o ornek
program normalizasyon
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: X(3,2), Xb(3,2), Xl(3,2), mu, v, eps
  integer :: i, j
  X = reshape([1,3,5, 2,6,10] * 1.0_dp, [3,2])      ! sutunlar = ozellikler
  eps = 1.0e-5_dp
  do j = 1, 2                                       ! BatchNorm: sutun bazli
    mu = sum(X(:,j)) / 3
    v  = sum((X(:,j) - mu)**2) / 3
    Xb(:,j) = (X(:,j) - mu) / sqrt(v + eps)
  end do
  do i = 1, 3                                       ! LayerNorm: satir bazli
    mu = sum(X(i,:)) / 2
    v  = sum((X(i,:) - mu)**2) / 2
    Xl(i,:) = (X(i,:) - mu) / sqrt(v + eps)
  end do
  print '(A)', 'BatchNorm (her sutun ortalama 0, varyans 1):'
  do i = 1, 3
    print '(2F10.4)', Xb(i,:)
  end do
  print '(A)', 'LayerNorm (her satir ortalama 0, varyans 1):'
  do i = 1, 3
    print '(2F10.4)', Xl(i,:)
  end do
end program normalizasyon
