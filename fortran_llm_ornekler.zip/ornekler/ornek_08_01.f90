! Örnek 8.1: Sonraki token kaybı ve perplexity (elle)
! Derleme: gfortran -O2  ornek_08_01.f90 -o ornek
program sonraki_token
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: p(4), ltot, lmean, ppl
  integer :: t
  p = [0.5_dp, 0.25_dp, 0.1_dp, 0.8_dp]
  do t = 1, 4
    print '(A,I1,A,F5.2,A,F8.4)', 'adim ', t, '  P(dogru token)=', p(t), '  -log P = ', -log(p(t))
  end do
  ltot  = -sum(log(p))
  lmean = ltot / 4
  ppl   = exp(lmean)
  print '(A,F8.4)', 'toplam kayip      = ', ltot
  print '(A,F8.4)', 'ortalama kayip    = ', lmean
  print '(A,F8.4)', 'perplexity        = ', ppl
  print '(A,F8.4,A,F9.1)', 'V=50000 rastgele: kayip=', log(50000.0_dp), '  PPL=', 50000.0_dp
end program sonraki_token
