# Örnek 2.6: XOR için 2-4-1 MLP: geri yayılım + gradyan kontrolü + eğitim (PyTorch karşılığı)
import torch
import torch.nn.functional as F
torch.set_default_dtype(torch.float64)
torch.manual_seed(7)
X = torch.tensor([[0., 0], [0, 1], [1, 0], [1, 1]]); t = torch.tensor([0., 1, 1, 0])
nh = 4
W1 = (torch.randn(2, nh) * 0.8).requires_grad_(); b1 = torch.zeros(nh, requires_grad=True)
W2 = (torch.randn(nh) * 0.8).requires_grad_();    b2 = torch.zeros((), requires_grad=True)
def forward(W1, b1, W2, b2):
    return torch.tanh(X @ W1 + b1) @ W2 + b2
def loss_fn(W1, b1, W2, b2):
    return F.binary_cross_entropy_with_logits(forward(W1, b1, W2, b2), t)
ok = torch.autograd.gradcheck(loss_fn, (W1, b1, W2, b2), eps=1e-6, atol=1e-6)
print("gradcheck (autograd vs sayisal turev):", ok)
opt = torch.optim.SGD([W1, b1, W2, b2], lr=0.5)
for ep in range(6001):
    loss = loss_fn(W1, b1, W2, b2)
    if ep % 1000 == 0: print(f"adim {ep:5d}  kayip = {loss.item():10.6f}")
    opt.zero_grad(); loss.backward(); opt.step()
for i in range(4):
    print("girdi", X[i].tolist(), " tahmin =", round(torch.sigmoid(forward(W1, b1, W2, b2))[i].item(), 4))

