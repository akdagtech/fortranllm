! Örnek 5.1: Döngü sırası: i-dış mı, j-dış mı?
! Derleme: gfortran -O2  ornek_05_01.f90 -o ornek
program siralama
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 3000
  real(dp), allocatable :: a(:,:)
  real(dp) :: t0, t1, t2
  integer :: i, j
  allocate(a(n,n)); a = 1.0_dp
  t0 = now()
  do i = 1, n                         ! YANLIS: en icte j (bellekte n adim atlar)
    do j = 1, n
      a(i,j) = a(i,j) * 1.0001_dp + 1.0_dp
    end do
  end do
  t1 = now()
  do j = 1, n                         ! DOGRU: en icte i (bellekte ardisik)
    do i = 1, n
      a(i,j) = a(i,j) * 1.0001_dp + 1.0_dp
    end do
  end do
  t2 = now()
  print '(A,F8.3,A)', 'satir satir  (yanlis) : ', t1 - t0, ' s'
  print '(A,F8.3,A)', 'sutun sutun  (dogru)  : ', t2 - t1, ' s'
  print '(A,F8.1,A)', 'hiz farki             : ', (t1 - t0) / (t2 - t1), ' kat'
contains
  function now() result(t)
    integer(8) :: c, r
    real(dp) :: t
    call system_clock(c, r)
    t = real(c, dp) / real(r, dp)
  end function now
end program siralama
