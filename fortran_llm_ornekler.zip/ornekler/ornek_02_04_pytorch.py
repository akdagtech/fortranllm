# Örnek 2.4: Dört kayıp fonksiyonunu hesapla (PyTorch karşılığı)
import torch
import torch.nn.functional as F
y = torch.tensor([1., 0., 1., 1.]); yh = torch.tensor([0.9, 0.2, 0.6, 0.99])
print(f"MSE = {F.mse_loss(yh, y):.5f}")
print(f"MAE = {F.l1_loss(yh, y):.5f}")
print(f"BCE = {F.binary_cross_entropy(yh, y):.5f}")
print("Gercek sinif 1 iken -log(p):")
for p in [0.99, 0.5, 0.01]:
    print(f"  p={p:.2f} : {-torch.log(torch.tensor(p)):.4f}")

