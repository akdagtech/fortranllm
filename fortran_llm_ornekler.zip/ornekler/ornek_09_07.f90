! Örnek 9.7: Online softmax: blok blok attention, aynı sonuç
! Derleme: gfortran -O2  ornek_09_07.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program flash_mantik
  use rng_mod
  implicit none
  integer, parameter :: n = 10, dv = 3, bs = 3
  real(dp) :: s(n), V(n,dv), p(n), o_ref(dv), o(dv), acc(dv)
  real(dp) :: m, mnew, l, scale, ex(bs)
  integer :: i0, i1, nb
  call rng_seed(31)
  call randn1(s, 2.0_dp); call randn2(V, 1.0_dp)
  ! (1) standart: tum skorlar bellekte
  p = exp(s - maxval(s)); p = p / sum(p)
  o_ref = matmul(p, V)
  ! (2) online: skorlari bloklar halinde isle
  m = -huge(1.0_dp); l = 0.0_dp; acc = 0.0_dp
  do i0 = 1, n, bs
    i1 = min(i0 + bs - 1, n); nb = i1 - i0 + 1
    mnew  = max(m, maxval(s(i0:i1)))
    scale = exp(m - mnew)                           ! eski birikimi duzelt
    ex(1:nb) = exp(s(i0:i1) - mnew)
    l   = l * scale + sum(ex(1:nb))
    acc = acc * scale + matmul(ex(1:nb), V(i0:i1, :))
    m = mnew
    print '(A,I2,A,I2,A,F8.4,A,F8.4)', 'blok ', i0, '-', i1, '  kosan max=', m, &
          '  kosan toplam=', l
  end do
  o = acc / l
  print '(A,3F10.6)', 'standart  : ', o_ref
  print '(A,3F10.6)', 'online    : ', o
  print '(A,ES10.2)', 'fark = ', maxval(abs(o - o_ref))
end program flash_mantik
