# Örnek 7.1: HTML etiketlerini ve varlıklarını temizle (PyTorch karşılığı)
import re, html
s = ("<html><head><title>Baslik</title></head><body>"
     "<h1>Merhaba &amp; hos geldin</h1>"
     "<p>LLM   egitimi&nbsp;icin<br>veri temizle &lt;3.</p>"
     "<script>var x = 1;</script></body></html>")
t = re.sub(r"<head.*?</head>", "", s, flags=re.S)
t = re.sub(r"<script.*?</script>", "", t, flags=re.S)
t = re.sub(r"<[^>]+>", " ", t)               # kalan etiketler -> bosluk
t = html.unescape(t).replace("\xa0", " ")    # &amp; &lt; &nbsp; ... cozulur
t = re.sub(r"\s+", " ", t).strip()
print("ham   :", s)
print("temiz :", t)

