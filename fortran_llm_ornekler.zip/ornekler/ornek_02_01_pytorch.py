# Örnek 2.1: Perceptron ile AND kapısını öğren (PyTorch karşılığı)
import torch
X = torch.tensor([[0., 0], [0, 1], [1, 0], [1, 1]])
t = torch.tensor([0., 0, 0, 1])
w = torch.zeros(2); b = torch.tensor(0.0); lr = 0.5
for ep in range(1, 21):
    hata = 0
    for i in range(4):
        y = float((X[i] @ w + b) > 0)
        hata += int(y != t[i])
        w += lr * (t[i] - y) * X[i]
        b += lr * (t[i] - y)
    print(f"epoch {ep:2d}  hata={hata:2d}  w={w.tolist()}  b={b.item():.2f}")
    if hata == 0: break
for i in range(4):
    print("girdi", X[i].tolist(), "->", float((X[i] @ w + b) > 0))

