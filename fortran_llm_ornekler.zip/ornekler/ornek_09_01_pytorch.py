# Örnek 9.1: GPT-2 ailesinin parametre sayısı (PyTorch karşılığı)
import torch, torch.nn as nn
class Blk(nn.Module):
    def __init__(s, d):
        super().__init__()
        s.ln1, s.ln2 = nn.LayerNorm(d), nn.LayerNorm(d)
        s.qkv, s.proj = nn.Linear(d, 3 * d), nn.Linear(d, d)
        s.fc, s.out = nn.Linear(d, 4 * d), nn.Linear(4 * d, d)
class GPT2(nn.Module):
    def __init__(s, V, T, d, L):
        super().__init__()
        s.wte, s.wpe = nn.Embedding(V, d), nn.Embedding(T, d)
        s.h = nn.ModuleList(Blk(d) for _ in range(L)); s.ln_f = nn.LayerNorm(d)
        # cikis matrisi wte ile paylasildigi icin ayri parametre eklenmez (weight tying)
for ad, L, d in [("GPT-2 small ", 12, 768), ("GPT-2 medium", 24, 1024), ("GPT-2 large ", 36, 1280), ("GPT-2 XL    ", 48, 1600)]:
    with torch.device("meta"):                      # bellek ayirmadan modeli kur (sadece sekiller)
        m = GPT2(50257, 1024, d, L)
    n = sum(p.numel() for p in m.parameters())
    emb = m.wte.weight.numel() + m.wpe.weight.numel()
    print(f"{ad} : {n:12d} parametre ({n/1e6:7.2f} M)   embedding payi %{100*emb/n:5.1f}")

