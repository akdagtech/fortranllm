# Örnek 15.4: Simetri testleri: EGNN eşdeğerliği ve SchNet ile kuvvet öğrenme
import torch, torch.nn as nn, numpy as np, math
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem
RDLogger.DisableLog('rdApp.*')
torch.manual_seed(0); rng = np.random.default_rng(0)

class EGNNLayer(nn.Module):
    """E(n)-esdeger katman: ozellikler degismez (h), koordinatlar esdeger (x)."""
    def __init__(s, d):
        super().__init__()
        s.phi_e = nn.Sequential(nn.Linear(2 * d + 1, d), nn.SiLU(), nn.Linear(d, d), nn.SiLU())
        s.phi_x = nn.Sequential(nn.Linear(d, d), nn.SiLU(), nn.Linear(d, 1))
        s.phi_h = nn.Sequential(nn.Linear(2 * d, d), nn.SiLU(), nn.Linear(d, d))
    def forward(s, h, x):
        n = len(h); off = (1 - torch.eye(n))[..., None]
        diff = x[:, None] - x[None]                                          # x_i - x_j  (esdeger vektor)
        d2 = (diff ** 2).sum(-1, keepdim=True)                               # |x_i - x_j|^2  (DEGISMEZ skaler)
        m = s.phi_e(torch.cat([h[:, None].expand(n, n, -1), h[None].expand(n, n, -1), d2], -1)) * off
        x_new = x + (diff * s.phi_x(m) * off).sum(1) / (n - 1)               # x' = x + sum (x_i-x_j) phi(m_ij)
        h_new = h + s.phi_h(torch.cat([h, m.sum(1)], -1))
        return h_new, x_new

m = Chem.AddHs(Chem.MolFromSmiles("CC(=O)O")); AllChem.EmbedMolecule(m, randomSeed=1); AllChem.MMFFOptimizeMolecule(m)
x = torch.tensor(m.GetConformer().GetPositions(), dtype=torch.float64)       # 3B koordinatlar (Angstrom)
Z = torch.tensor([a.GetAtomicNum() for a in m.GetAtoms()])
torch.set_default_dtype(torch.float64)
h = torch.nn.functional.one_hot(Z, 10).double()[:, :10] @ torch.randn(10, 16, dtype=torch.float64)
layer = EGNNLayer(16).double()
Q, _ = torch.linalg.qr(torch.randn(3, 3, dtype=torch.float64))
if torch.det(Q) < 0: Q[:, 0] = -Q[:, 0]                                      # gercek donme: det = +1
t = torch.randn(3, dtype=torch.float64)
h1, x1 = layer(h, x); h2, x2 = layer(h, x @ Q.T + t)
print("molekul: asetik asit,", len(x), "atom (H dahil)")
print(f"mesafe matrisi degismezligi : {((torch.cdist(x, x) - torch.cdist(x @ Q.T + t, x @ Q.T + t)).abs().max()):.2e}")
print(f"EGNN ozellik degismezligi   : max |h(Rx+t) - h(x)|         = {(h2 - h1).abs().max():.2e}")
print(f"EGNN koordinat esdegerligi  : max |x'(Rx+t) - (Rx'(x)+t)|  = {(x2 - (x1 @ Q.T + t)).abs().max():.2e}")
torch.set_default_dtype(torch.float32)

# ---- SchNet tipi mesafe-tabanli model: Lennard-Jones kumesinin enerjisini ogren, kuvveti AUTOGRAD ile al
def lj(x):                                               # E = sum_{i<j} 4 (r^-12 - r^-6); F = -dE/dx (analitik)
    d = x[:, None] - x[None]; r2 = (d ** 2).sum(-1) + np.eye(len(x)); i6 = r2 ** -3
    e = 4 * (i6 ** 2 - i6); np.fill_diagonal(e, 0)
    c = 4 * (-12 * i6 ** 2 + 6 * i6) / r2; np.fill_diagonal(c, 0)
    return e.sum() / 2, -(c[:, :, None] * d).sum(1)
base = np.array([[1, 0, 0], [-1, 0, 0], [0, 1, 0], [0, -1, 0], [0, 0, 1], [0, 0, -1]], float) * 0.8
def sample(n):
    out = []
    for _ in range(n):
        xx = base + rng.normal(0, 0.07, base.shape); e, f = lj(xx); out.append((xx, e, f))
    return out
tr, te = sample(1500), sample(300)
T = lambda a: torch.tensor(np.array(a), dtype=torch.float32)
X, E = T([s[0] for s in tr]), T([s[1] for s in tr]); Xt, Et, Ft = T([s[0] for s in te]), T([s[1] for s in te]), T([s[2] for s in te])
class SchNet(nn.Module):
    def __init__(s, d=32, nrbf=32, L=2, cutoff=4.0):
        super().__init__(); s.h0 = nn.Parameter(torch.randn(d) * 0.1); s.mu = torch.linspace(0.7, cutoff, nrbf)
        s.filt = nn.ModuleList(nn.Sequential(nn.Linear(nrbf, d), nn.Tanh(), nn.Linear(d, d)) for _ in range(L))
        s.upd = nn.ModuleList(nn.Sequential(nn.Linear(d, d), nn.Tanh(), nn.Linear(d, d)) for _ in range(L))
        s.out = nn.Sequential(nn.Linear(d, d), nn.Tanh(), nn.Linear(d, 1))
    def forward(s, X):
        B, n, _ = X.shape
        D = torch.sqrt(((X[:, :, None] - X[:, None]) ** 2).sum(-1) + 1e-9)    # yalnizca MESAFELER -> degisme garantili
        rbf = torch.exp(-6.0 * (D[..., None] - s.mu) ** 2); off = (1 - torch.eye(n))[None, :, :, None]
        h = s.h0.expand(B, n, -1)
        for f, u in zip(s.filt, s.upd): h = h + u((f(rbf) * off * h[:, None]).sum(2))   # surekli filtreli konvolusyon
        return s.out(h).squeeze(-1).sum(1)                                    # E = toplam atomik katkilar
net = SchNet(); opt = torch.optim.Adam(net.parameters(), lr=2e-3); sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, 400)
Em, Es = E.mean(), E.std()
for ep in range(1, 401):
    p = torch.randperm(len(X))
    for k in range(0, len(X), 100):
        i = p[k:k + 100]; loss = nn.functional.mse_loss(net(X[i]), (E[i] - Em) / Es)
        opt.zero_grad(); loss.backward(); opt.step()
    sched.step()
    if ep in (1, 100, 200, 400):
        with torch.no_grad(): pe = net(Xt) * Es + Em
        print(f"epoch {ep:3d}  test enerji MAE = {(pe - Et).abs().mean().item():.3f}   (E std = {Et.std().item():.2f})")
Xg = Xt.clone().requires_grad_(True); (net(Xg) * Es).sum().backward(); Fp = -Xg.grad     # F = -dE/dx (autograd)
r2f = 1 - ((Fp - Ft) ** 2).sum() / ((Ft - Ft.mean()) ** 2).sum()
print(f"kuvvetler (yalnizca enerjiyle egitildi): R2 = {r2f.item():.3f}")
q, _ = torch.linalg.qr(torch.randn(3, 3))
with torch.no_grad(): print(f"SchNet donme/oteleme degismezligi: {(net(Xt[:20]) - net(Xt[:20] @ q.T + torch.randn(3))).abs().max().item():.1e}")
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
ax[0].scatter(Et, pe, s=6, c="#1d3557"); ax[0].plot([Et.min(), Et.max()], [Et.min(), Et.max()], "r--"); ax[0].set_xlabel("LJ enerjisi (gercek)"); ax[0].set_ylabel("SchNet"); ax[0].set_title("Enerji")
ax[1].scatter(Ft.flatten(), Fp.detach().flatten(), s=3, c="#e76f51"); ax[1].plot([-150, 150], [-150, 150], "r--"); ax[1].set_xlabel("kuvvet (gercek)"); ax[1].set_ylabel("-dE/dx (autograd)"); ax[1].set_title("Kuvvetler")
plt.tight_layout(); plt.savefig("f_schnet_lj.png", dpi=170)
