# Örnek 16.1: SMILES Transformer'ı ile yeni molekül üretimi
import itertools, random
from rdkit import Chem, RDLogger
RDLogger.DisableLog('rdApp.*')

SUBS = ['F', 'Cl', 'Br', 'O', 'N', 'C', 'CC', 'C(=O)O', 'OC', 'C#N', 'N(C)C', 'S', 'C(F)(F)F', 'C(=O)N', 'OC(C)=O']
def make_dataset(seed=0, n_max=900):
    """Kucuk ama cesitli bir molekul veri kumesi: zincirler, halkalar, fonksiyonel gruplar."""
    random.seed(seed); smis = set()
    for L in range(1, 7):                                    # alifatik zincirler + fonksiyonel grup
        chain = 'C' * L
        for g in SUBS:
            for pos in range(L):
                smis.add(chain[:pos + 1] + '(' + g + ')' + chain[pos + 1:] if pos < L - 1 else chain + g)
    rings = ['c1ccccc1', 'c1ccncc1', 'c1ccoc1', 'c1ccsc1', 'C1CCCCC1', 'C1CCNCC1', 'C1CCOC1']
    for ring in rings:                                       # halkalar + tek sustituent
        for g in SUBS:
            smis.add(ring.replace('c1', 'c1(' + g + ')', 1) if ring.startswith('c1')
                     else ring.replace('C1', 'C1(' + g + ')', 1))
    for g1, g2 in itertools.product(SUBS, SUBS):             # iki sustituentli benzen / sikloheksan
        smis.add('c1(' + g1 + ')ccc(' + g2 + ')cc1'); smis.add('c1(' + g1 + ')cccc(' + g2 + ')c1')
        smis.add('C1(' + g1 + ')CCC(' + g2 + ')CC1')
    out = []
    for s in sorted(smis):
        m = Chem.MolFromSmiles(s)
        if m is not None and m.GetNumHeavyAtoms() <= 22: out.append(Chem.MolToSmiles(m))
    out = sorted(set(out)); random.shuffle(out)
    return out[:n_max]
import torch, torch.nn as nn, torch.nn.functional as F, numpy as np, random
from rdkit import Chem, RDLogger
from rdkit.Chem import Draw
RDLogger.DisableLog('rdApp.*')
torch.manual_seed(0); random.seed(0); np.random.seed(0)
smiles = make_dataset(); random.shuffle(smiles)
train_s, test_s = smiles[:550], smiles[550:]
aug = lambda s: Chem.MolToSmiles(Chem.MolFromSmiles(s), doRandom=True)      # ayni molekulun rastgele SMILES yazimi
chars = sorted(set("".join(smiles + [aug(s) for s in smiles for _ in range(3)])))
stoi = {c: i + 2 for i, c in enumerate(chars)}; itos = {i: c for c, i in stoi.items()}
BOS, EOS, V, TT = 0, 1, len(chars) + 2, 48
enc = lambda s: [BOS] + [stoi[c] for c in s] + [EOS]

class Block(nn.Module):
    def __init__(s, d, nh):
        super().__init__(); s.nh = nh
        s.n1, s.n2 = nn.LayerNorm(d), nn.LayerNorm(d); s.qkv = nn.Linear(d, 3 * d); s.proj = nn.Linear(d, d)
        s.ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))
    def forward(s, x):
        B, T, d = x.shape
        q, k, v = (t.view(B, T, s.nh, d // s.nh).transpose(1, 2) for t in s.qkv(s.n1(x)).chunk(3, -1))
        a = F.scaled_dot_product_attention(q, k, v, is_causal=True).transpose(1, 2).reshape(B, T, d)
        x = x + s.proj(a); return x + s.ffn(s.n2(x))
class SmilesGPT(nn.Module):                                   # Bolum 4/11'deki Transformer'in SMILES versiyonu
    def __init__(s, d=96, nh=4, nl=3):
        super().__init__(); s.E = nn.Embedding(V, d); s.P = nn.Embedding(TT, d)
        s.blocks = nn.ModuleList(Block(d, nh) for _ in range(nl)); s.nf = nn.LayerNorm(d)
        for p in s.parameters():
            if p.dim() > 1: nn.init.normal_(p, std=0.02)
    def forward(s, x):
        h = s.E(x) + s.P(torch.arange(x.shape[1]))
        for b in s.blocks: h = b(h)
        return F.linear(s.nf(h), s.E.weight)                    # weight tying
m = SmilesGPT(); opt = torch.optim.AdamW(m.parameters(), lr=2e-3, weight_decay=0.01)
print("parametre sayisi:", sum(p.numel() for p in m.parameters()), "  sozluk:", V, "  ln V =", round(float(np.log(V)), 3))
def batch(n):
    x = torch.zeros(n, TT, dtype=torch.long) + EOS; msk = torch.zeros(n, TT, dtype=torch.bool)
    for i in range(n):
        q = enc(aug(random.choice(train_s)))[:TT]; x[i, :len(q)] = torch.tensor(q); msk[i, :len(q) - 1] = True
    return x, msk
for step in range(1, 1601):
    x, msk = batch(64)
    loss = F.cross_entropy(m(x[:, :-1])[msk[:, :-1]], x[:, 1:][msk[:, :-1]])    # sonraki karakter tahmini
    opt.zero_grad(); loss.backward(); opt.step()
    if step in (1, 400, 800, 1600): print(f"adim {step:5d}  kayip = {loss.item():.3f}")
@torch.no_grad()
def sample(n, temp=0.8):
    x = torch.zeros(n, 1, dtype=torch.long); done = torch.zeros(n, dtype=torch.bool)
    for _ in range(TT - 1):
        nx = torch.multinomial(torch.softmax(m(x)[:, -1] / temp, -1), 1)
        nx[done] = EOS; x = torch.cat([x, nx], 1); done |= nx.squeeze(1) == EOS
        if done.all(): break
    out = []
    for row in x[:, 1:].tolist():
        s = ""
        for t in row:
            if t == EOS: break
            s += itos[t]
        out.append(s)
    return out
gen = sample(500)
valid = [s for s in gen if s and Chem.MolFromSmiles(s) is not None]
can = [Chem.MolToSmiles(Chem.MolFromSmiles(s)) for s in valid]; uniq = sorted(set(can)); known = set(smiles)
novel = [c for c in uniq if c not in known]
print(f"uretilen: {len(gen)}   gecerli (RDKit): {len(valid)/len(gen):.1%}   benzersiz: {len(uniq)/len(valid):.1%}   yeni (egitimde yok): {len(novel)/len(uniq):.1%}")
print("ornek yeni moleküller:", novel[:8])
show = novel[:12]
Draw.MolsToGridImage([Chem.MolFromSmiles(s) for s in show], molsPerRow=4, subImgSize=(230, 170)).save("f_gen_mols.png")
