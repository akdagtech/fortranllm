! Örnek 6.4: Kendi BPE tokenizer'ım: eğitim, kodlama, çözme
! Derleme: gfortran -O2  ornek_06_04.f90 -o ornek
program bpe_egitim
  implicit none
  integer, parameter :: maxv = 400, maxn = 2000, nmerge = 24
  character(len=*), parameter :: corpus = &
    'araba arabalar arabalarda kalem kalemler kalemlerden evde evden evlerden ' // &
    'gelmek gelecek gelenler gelenlerden kitap kitaplar kitaplarda kitaplardan '
  integer :: ids(maxn), n, n0, cnt(0:maxv-1, 0:maxv-1), mA(nmerge), mB(nmerge)
  integer :: nid, nm, m, i, j, ba, bb, best, tl(0:maxv-1), o(200), no, q
  character(len=24) :: tok(0:maxv-1)
  character(len=:), allocatable :: line, back
  do i = 0, 255
    tok(i) = char(i); tl(i) = 1
  end do
  n = len(corpus); n0 = n
  do i = 1, n
    ids(i) = ichar(corpus(i:i))
  end do
  nid = 256; nm = 0
  do m = 1, nmerge
    cnt = 0
    do i = 1, n - 1
      cnt(ids(i), ids(i+1)) = cnt(ids(i), ids(i+1)) + 1
    end do
    best = 0; ba = 0; bb = 0
    do i = 0, nid - 1
      do j = 0, nid - 1
        if (cnt(i,j) > best) then
          best = cnt(i,j); ba = i; bb = j
        end if
      end do
    end do
    if (best < 2) exit
    tok(nid) = tok(ba)(1:tl(ba)) // tok(bb)(1:tl(bb))
    tl(nid) = tl(ba) + tl(bb)
    j = 0; i = 1
    do while (i <= n)                                  ! cifti yeni tokenla degistir
      if (i < n) then
        if (ids(i) == ba .and. ids(i+1) == bb) then
          j = j + 1; ids(j) = nid; i = i + 2
          cycle
        end if
      end if
      j = j + 1; ids(j) = ids(i); i = i + 1
    end do
    n = j
    nm = nm + 1; mA(nm) = ba; mB(nm) = bb; nid = nid + 1
    line = '[' // show(ba) // '] + [' // show(bb) // '] -> [' // show(nid-1) // ']'
    write(*,'(I3,2X,A,T34,A,I2,A,I4,A,F5.2)') m, line, 'sayi=', best, '  dizi=', n, &
          '  bayt/token=', real(n0)/real(n)
  end do
  print '(A)', '--- yeni kelimeleri kodla ---'
  call pieces('kalemlerde')
  call pieces('arabalardan')
  call pieces('kitaplarda')
  call pieces('evlerde')
  call pieces('gelenlerde')
contains
  function show(id) result(r)
    integer, intent(in) :: id
    character(len=:), allocatable :: r
    integer :: p
    r = tok(id)(1:tl(id))
    do p = 1, len(r)
      if (r(p:p) == ' ') r(p:p) = '_'
    end do
  end function show

  subroutine encode(text, out, nout)
    character(len=*), intent(in) :: text
    integer, intent(out) :: out(:), nout
    integer :: p, mm, i2, j2
    nout = len(text)
    do p = 1, nout
      out(p) = ichar(text(p:p))
    end do
    do mm = 1, nm                                      ! birlestirmeleri sirayla uygula
      j2 = 0; i2 = 1
      do while (i2 <= nout)
        if (i2 < nout) then
          if (out(i2) == mA(mm) .and. out(i2+1) == mB(mm)) then
            j2 = j2 + 1; out(j2) = 255 + mm; i2 = i2 + 2
            cycle
          end if
        end if
        j2 = j2 + 1; out(j2) = out(i2); i2 = i2 + 1
      end do
      nout = j2
    end do
  end subroutine encode

  subroutine pieces(text)
    character(len=*), intent(in) :: text
    character(len=:), allocatable :: lin
    call encode(text, o, no)
    lin = ''; back = ''
    do q = 1, no
      lin = lin // show(o(q))
      if (q < no) lin = lin // '|'
      back = back // tok(o(q))(1:tl(o(q)))             ! cozme: baytlari birlestir
    end do
    write(*,'(A,A,A,A,I2,A,L1)') text, ' -> ', lin, '   token=', no, '   geri-cozme dogru=', &
          back == text
  end subroutine pieces
end program bpe_egitim
