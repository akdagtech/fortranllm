# Örnek 2.3: Tek nöronda ileri ve geri geçiş (elle) (PyTorch karşılığı)
import torch
x = torch.tensor(1.5, dtype=torch.float64)
t = torch.tensor(1.0, dtype=torch.float64)
w = torch.tensor(0.8, dtype=torch.float64, requires_grad=True)
b = torch.tensor(-0.3, dtype=torch.float64, requires_grad=True)
z = w * x + b
y = torch.sigmoid(z)
L = 0.5 * (y - t) ** 2
print(f"z={z.item():.6f}  y={y.item():.6f}  L={L.item():.6f}")
L.backward()                               # geri gecis
dLdz = (y - t) * y * (1 - y)               # Fortran'daki elle formul
print("dL/dw (autograd, elle):", f"{w.grad.item():.9f} {(dLdz * x).item():.9f}")
print("dL/db (autograd, elle):", f"{b.grad.item():.9f} {dLdz.item():.9f}")

