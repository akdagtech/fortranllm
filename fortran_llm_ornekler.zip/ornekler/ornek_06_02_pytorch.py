# Örnek 6.2: UTF-8 çözücü: baytlardan kod noktalarına (PyTorch karşılığı)
s = "İstanbul ığ " + chr(0x1F600)
b = s.encode("utf-8"); i = 0
while i < len(b):
    v = b[i]
    n = 1 if v < 128 else 2 if v < 224 else 3 if v < 240 else 4
    cp = v if n == 1 else v & (0x1F if n == 2 else 0x0F if n == 3 else 0x07)
    for k in range(1, n):
        cp = cp * 64 + (b[i + k] & 63)
    print(f"U+{cp:06X}  ({n} bayt)")
    i += n
print("ord() ile karsilastir:", [f"U+{ord(c):06X}" for c in s][:4], "...")

