! Örnek 7.4: Yaklaşık tekrarlar: Jaccard benzerliği
! Derleme: gfortran -O2  ornek_07_04.f90 -o ornek
program yakin_tekrar
  implicit none
  integer, parameter :: nd = 3, hs = 65521
  character(len=70) :: docs(nd)
  logical :: sh(hs, nd)
  integer :: i, j, inter, uni
  docs(1) = 'turkce dil modeli egitmek icin temiz ve cesitli veri gerekir'
  docs(2) = 'turkce dil modeli egitmek icin temiz ve guvenilir veri gerekir'
  docs(3) = 'bugun aksam sahilde yuruyus yapip cay icmeyi planliyoruz'
  do i = 1, nd
    call shingles(docs(i), sh(:,i))
  end do
  print '(A)', 'Jaccard benzerlik matrisi:'
  do i = 1, nd
    do j = 1, nd
      inter = count(sh(:,i) .and. sh(:,j))
      uni   = count(sh(:,i) .or.  sh(:,j))
      write(*,'(F8.3)', advance='no') real(inter) / real(uni)
    end do
    print *
  end do
  print '(A,I0)', 'belge 1 icin 3-gram sayisi: ', count(sh(:,1))
contains
  subroutine shingles(x, set)                      ! karakter 3-gramlarini hash'leyip isaretle
    character(len=*), intent(in) :: x
    logical, intent(out) :: set(:)
    integer :: i, idx
    set = .false.
    do i = 1, len_trim(x) - 2
      idx = mod(ichar(x(i:i))*961 + ichar(x(i+1:i+1))*31 + ichar(x(i+2:i+2)), hs) + 1
      set(idx) = .true.
    end do
  end subroutine shingles
end program yakin_tekrar
