# Örnek 8.5: Karakter bigram modeli: eğitim ve doğrulama perplexity'si (PyTorch karşılığı)
import torch
train = ("bir varmis bir yokmus evvel zaman icinde kalbur saman icinde "
         "develer tellal iken pireler berber iken ")
val = "ben annemin besigini tangir tungur sallar iken cok gezdim cok gordum"
chars = sorted(set(train) | set(val)); ix = {c: i for i, c in enumerate(chars)}; V = len(chars)
enc = lambda s: torch.tensor([ix[c] for c in s])
tr, va = enc(train), enc(val)
cnt = torch.zeros(V, V, dtype=torch.float64)
cnt.index_put_((tr[:-1], tr[1:]), torch.ones(len(tr) - 1, dtype=torch.float64), accumulate=True)
tot = cnt.sum(1)
def ppl(t, k):
    p = (cnt[t[:-1], t[1:]] + k) / (tot[t[:-1]] + k * V)
    return torch.exp(-torch.log(p).mean()).item() if (p > 0).all() else float("inf")
print("sozluk boyutu V =", V)
print("     k     egitim PPL     dogrulama PPL")
for k in [0.0, 0.01, 0.1, 1.0]:
    print(f"{k:6.2f}   {ppl(tr, k):12.3f}   {ppl(va, k):12.3f}")

