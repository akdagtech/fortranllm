# Örnek 5.5: Bellek bant genişliğini ölç (vector triad) (PyTorch karşılığı)
import torch, time
torch.set_num_threads(1)
n, nrep = 10_000_000, 10
b = torch.ones(n, dtype=torch.float64); c = torch.full((n,), 2.0, dtype=torch.float64)
a = torch.zeros(n, dtype=torch.float64); s = 3.0
t0 = time.perf_counter()
for _ in range(nrep):
    torch.add(b, c, alpha=s, out=a)              # a = b + s*c (yeni bellek ayirmadan)
t = time.perf_counter() - t0
bytes_ = nrep * 3 * 8 * n                        # 2 okuma + 1 yazma
ai = 2 / 24
print(f"bant genisligi      : {bytes_ / t / 1e9:8.2f} GB/s")
print(f"aritmetik yogunluk  : {ai:8.4f}")
print(f"ulasilan performans : {ai * bytes_ / t / 1e9:8.2f} GFLOP/s")

