# Örnek 1.8: Öğrenme oranı çok küçükse, çok büyükse? (PyTorch karşılığı)
import torch
for lr in [0.01, 0.1, 0.5, 0.9, 1.0, 1.1]:
    x = torch.tensor(0.0, dtype=torch.float64, requires_grad=True)
    opt = torch.optim.SGD([x], lr=lr)
    for _ in range(20):
        opt.zero_grad(); ((x - 3) ** 2 + 1).backward(); opt.step()
    print(f"lr={lr:5.2f}  x(20)={x.item():13.5e}  carpan={1 - 2*lr:8.4f}")

