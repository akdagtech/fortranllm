# Örnek 15.3: GNN ile logP tahmini ve Morgan + Ridge karşılaştırması
import itertools, random
from rdkit import Chem, RDLogger
RDLogger.DisableLog('rdApp.*')

SUBS = ['F', 'Cl', 'Br', 'O', 'N', 'C', 'CC', 'C(=O)O', 'OC', 'C#N', 'N(C)C', 'S', 'C(F)(F)F', 'C(=O)N', 'OC(C)=O']
def make_dataset(seed=0, n_max=900):
    """Kucuk ama cesitli bir molekul veri kumesi: zincirler, halkalar, fonksiyonel gruplar."""
    random.seed(seed); smis = set()
    for L in range(1, 7):                                    # alifatik zincirler + fonksiyonel grup
        chain = 'C' * L
        for g in SUBS:
            for pos in range(L):
                smis.add(chain[:pos + 1] + '(' + g + ')' + chain[pos + 1:] if pos < L - 1 else chain + g)
    rings = ['c1ccccc1', 'c1ccncc1', 'c1ccoc1', 'c1ccsc1', 'C1CCCCC1', 'C1CCNCC1', 'C1CCOC1']
    for ring in rings:                                       # halkalar + tek sustituent
        for g in SUBS:
            smis.add(ring.replace('c1', 'c1(' + g + ')', 1) if ring.startswith('c1')
                     else ring.replace('C1', 'C1(' + g + ')', 1))
    for g1, g2 in itertools.product(SUBS, SUBS):             # iki sustituentli benzen / sikloheksan
        smis.add('c1(' + g1 + ')ccc(' + g2 + ')cc1'); smis.add('c1(' + g1 + ')cccc(' + g2 + ')c1')
        smis.add('C1(' + g1 + ')CCC(' + g2 + ')CC1')
    out = []
    for s in sorted(smis):
        m = Chem.MolFromSmiles(s)
        if m is not None and m.GetNumHeavyAtoms() <= 22: out.append(Chem.MolToSmiles(m))
    out = sorted(set(out)); random.shuffle(out)
    return out[:n_max]
import torch, torch.nn as nn, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import Crippen, AllChem
from sklearn.linear_model import Ridge
torch.manual_seed(0); np.random.seed(0)
smiles = make_dataset()                                   # ~640 molekul
ATOMS = [6, 7, 8, 9, 16, 17, 35]
def featurize(m):
    x = []
    for a in m.GetAtoms():
        f = [float(a.GetAtomicNum() == z) for z in ATOMS]                       # atom turu (one-hot)
        f += [float(a.GetIsAromatic()), a.GetDegree() / 4, a.GetTotalNumHs() / 3, float(a.IsInRing())]
        f += [float(a.GetHybridization() == h) for h in (Chem.HybridizationType.SP, Chem.HybridizationType.SP2,
                                                         Chem.HybridizationType.SP3)]
        x.append(f)
    ei = [[], []]
    for b in m.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx(); ei[0] += [i, j]; ei[1] += [j, i]
    return torch.tensor(x), torch.tensor(ei, dtype=torch.long)
data = []
for s in smiles:
    m = Chem.MolFromSmiles(s); x, ei = featurize(m); data.append((x, ei, Crippen.MolLogP(m)))   # hedef: logP
def collate(items):                                       # molekulleri tek buyuk (ayrik) grafta birlestir
    xs, eis, ys, bs = [], [], [], []; off = 0
    for k, (x, ei, y) in enumerate(items):
        xs.append(x); eis.append(ei + off); ys.append(y); bs.append(torch.full((len(x),), k)); off += len(x)
    return torch.cat(xs), torch.cat(eis, 1), torch.tensor(ys, dtype=torch.float32), torch.cat(bs)
class GNN(nn.Module):
    def __init__(s, din, d=64, L=3):
        super().__init__(); s.emb = nn.Linear(din, d)
        s.ws = nn.ModuleList(nn.Linear(d, d) for _ in range(L)); s.wm = nn.ModuleList(nn.Linear(d, d) for _ in range(L))
        s.head = nn.Sequential(nn.Linear(d, d), nn.ReLU(), nn.Linear(d, 1))
    def forward(s, x, ei, batch, nb):
        h = torch.relu(s.emb(x)); src, dst = ei
        for ws, wm in zip(s.ws, s.wm):
            h = torch.relu(ws(h) + torch.zeros_like(h).index_add_(0, dst, wm(h[src])))   # mesaj gecirme
        g = torch.zeros(nb, h.shape[1]).index_add_(0, batch, h)                          # toplam havuzlama
        return s.head(g).squeeze(-1)
idx = np.random.permutation(len(data)); ntr = int(0.8 * len(data))
tr, te = [data[i] for i in idx[:ntr]], [data[i] for i in idx[ntr:]]
model = GNN(data[0][0].shape[1]); opt = torch.optim.Adam(model.parameters(), lr=3e-3)
Xt, Et, Yt, Bt = collate(te)
print(f"molekul sayisi: egitim={len(tr)}  test={len(te)}   parametre={sum(p.numel() for p in model.parameters())}")
for ep in range(1, 301):
    perm = np.random.permutation(len(tr))
    for k in range(0, len(tr), 64):
        x, ei, y, b = collate([tr[i] for i in perm[k:k + 64]])
        loss = nn.functional.mse_loss(model(x, ei, b, len(y)), y)
        opt.zero_grad(); loss.backward(); opt.step()
    if ep in (1, 50, 100, 200, 300):
        with torch.no_grad(): p = model(Xt, Et, Bt, len(Yt))
        print(f"epoch {ep:3d}  egitim MSE={loss.item():.5f}  test MAE={(p - Yt).abs().mean().item():.4f}")
with torch.no_grad(): p = model(Xt, Et, Bt, len(Yt))
r2 = 1 - ((p - Yt) ** 2).sum() / ((Yt - Yt.mean()) ** 2).sum()
print(f"GNN         : test MAE = {(p - Yt).abs().mean():.4f}   R2 = {r2:.4f}   (logP std = {Yt.std():.3f})")
fp = lambda s: np.array(AllChem.GetMorganFingerprintAsBitVect(Chem.MolFromSmiles(s), 2, 1024))   # ECFP4
Xa = np.array([fp(smiles[i]) for i in idx]); ya = np.array([data[i][2] for i in idx])
pr = Ridge(alpha=1.0).fit(Xa[:ntr], ya[:ntr]).predict(Xa[ntr:])
print(f"Morgan+Ridge: test MAE = {np.abs(pr - ya[ntr:]).mean():.4f}   R2 = {1 - ((pr - ya[ntr:])**2).sum() / ((ya[ntr:] - ya[ntr:].mean())**2).sum():.4f}")
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
ax[0].scatter(Yt, p, s=8, c="#1d3557"); ax[0].plot([-3, 5], [-3, 5], "r--", lw=1)
ax[0].set_xlabel("gercek logP (RDKit Crippen)"); ax[0].set_ylabel("GNN tahmini"); ax[0].set_title("GNN: test seti")
ax[1].scatter(ya[ntr:], pr, s=8, c="#e76f51"); ax[1].plot([-3, 5], [-3, 5], "r--", lw=1)
ax[1].set_xlabel("gercek logP"); ax[1].set_ylabel("Ridge tahmini"); ax[1].set_title("Morgan parmak izi + Ridge")
plt.tight_layout(); plt.savefig("f_gnn_parity.png", dpi=170)
