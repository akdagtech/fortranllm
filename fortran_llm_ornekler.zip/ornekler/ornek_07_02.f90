! Örnek 7.2: Satır satır ve parça parça okuma
! Derleme: gfortran -O2  ornek_07_02.f90 -o ornek
program akis_okuma
  implicit none
  integer, parameter :: chunk = 4096
  integer :: u, ios, i, nl, nw, nl2, nchunk, m
  integer(8) :: fsize, pos, rem
  character(len=200) :: line
  character(len=chunk) :: buf
  ! once ornek bir dosya yaz
  open(newunit=u, file='orn.txt', status='replace', action='write')
  do i = 1, 5000
    write(u, '(A,I0,A)') 'satir ', i, ' ornek metin kelime kelime'
  end do
  close(u)
  ! (1) satir satir oku: ayni anda bellekte yalniz 1 satir
  open(newunit=u, file='orn.txt', status='old', action='read')
  nl = 0; nw = 0
  do
    read(u, '(A)', iostat=ios) line
    if (ios /= 0) exit
    nl = nl + 1
    nw = nw + nkelime(line)
  end do
  close(u)
  ! (2) bayt akisi: sabit 4096 baytlik parcalar
  open(newunit=u, file='orn.txt', access='stream', form='unformatted', status='old')
  inquire(unit=u, size=fsize)
  pos = 1; nl2 = 0; nchunk = 0
  do while (pos <= fsize)
    rem = min(int(chunk, 8), fsize - pos + 1)
    m = int(rem)
    read(u, pos=pos) buf(1:m)
    do i = 1, m
      if (buf(i:i) == char(10)) nl2 = nl2 + 1
    end do
    pos = pos + rem; nchunk = nchunk + 1
  end do
  close(u)
  print '(A,I0,A)', 'dosya boyutu          : ', fsize, ' bayt'
  print '(A,I0,A,I0)', 'satir modu            : satir=', nl, '  kelime=', nw
  print '(A,I0,A,I0)', 'parca modu            : satir=', nl2, '  parca sayisi=', nchunk
contains
  function nkelime(x) result(c)
    character(len=*), intent(in) :: x
    integer :: c, i
    logical :: ic
    c = 0; ic = .false.
    do i = 1, len_trim(x)
      if (x(i:i) /= ' ') then
        if (.not. ic) c = c + 1
        ic = .true.
      else
        ic = .false.
      end if
    end do
  end function nkelime
end program akis_okuma
