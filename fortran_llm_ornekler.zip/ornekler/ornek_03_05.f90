! Örnek 3.5: L2 düzenlemesi ile AdamW sönümü
! Derleme: gfortran -O2  ornek_03_05.f90 -o ornek
program adamw
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: w1, w2, m, s, mh, sh, g, lr, wd, b1, b2, eps
  integer :: t
  lr = 0.1_dp; wd = 0.1_dp; b1 = 0.9_dp; b2 = 0.999_dp; eps = 1.0e-8_dp
  w1 = 1.0_dp; w2 = 1.0_dp
  m = 0.0_dp; s = 0.0_dp
  print '(A)', ' adim   Adam+L2(w)   AdamW(w)'
  do t = 1, 10
    ! Adam + L2: sonum gradyanin icine giriyor, sonra normalize ediliyor
    g = wd * w1
    m = b1*m + (1.0_dp - b1)*g
    s = b2*s + (1.0_dp - b2)*g**2
    mh = m / (1.0_dp - b1**t); sh = s / (1.0_dp - b2**t)
    w1 = w1 - lr * mh / (sqrt(sh) + eps)
    ! AdamW: kayip gradyani 0 oldugundan adim 0; sonum dogrudan agirliga
    w2 = w2 - lr * wd * w2
    print '(I5,2F13.6)', t, w1, w2
  end do
end program adamw
