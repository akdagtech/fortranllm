# Örnek 1.7: Gradyan inişi: tek boyutta (PyTorch karşılığı)
import torch
x = torch.tensor(0.0, dtype=torch.float64, requires_grad=True)
opt = torch.optim.SGD([x], lr=0.1)         # theta <- theta - lr * grad
for k in range(11):
    loss = (x - 3) ** 2 + 1
    print(f"adim {k:2d}  x = {x.item():9.5f}  f(x) = {loss.item():9.5f}")
    opt.zero_grad(); loss.backward(); opt.step()

