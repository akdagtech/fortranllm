# Örnek 10.2: Temperature dağılımı nasıl değiştirir? (PyTorch karşılığı)
import torch
z = torch.tensor([2.0, 1.0, 0.5, 0.0, -1.0], dtype=torch.float64)
print("    T     p1      p2      p3      p4      p5    entropi")
for T in [0.2, 0.5, 1.0, 2.0, 5.0]:
    p = torch.softmax(z / T, 0)
    ent = -(p * p.log()).sum()
    print(f"{T:5.1f}" + "".join(f"{v:8.4f}" for v in p.tolist()) + f"{ent:9.4f}")
print(f"azami entropi ln 5 = {torch.log(torch.tensor(5.0)):.4f}")

