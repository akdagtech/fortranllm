! Örnek 8.5: Karakter bigram modeli: eğitim ve doğrulama perplexity'si
! Derleme: gfortran -O2  ornek_08_05.f90 -o ornek
program bigram_ppl
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  character(len=*), parameter :: train = &
    'bir varmis bir yokmus evvel zaman icinde kalbur saman icinde ' // &
    'develer tellal iken pireler berber iken '
  character(len=*), parameter :: val = &
    'ben annemin besigini tangir tungur sallar iken cok gezdim cok gordum'
  integer :: cnt(0:127, 0:127), tot(0:127), V, i, c, a, b
  logical :: seen(0:127)
  real(dp) :: ks(4)
  ks = [0.0_dp, 0.01_dp, 0.1_dp, 1.0_dp]
  cnt = 0; seen = .false.
  do i = 1, len(train) - 1                          ! yalniz egitim metninden say
    a = ichar(train(i:i)); b = ichar(train(i+1:i+1))
    cnt(a, b) = cnt(a, b) + 1
  end do
  do i = 1, len(train)
    seen(ichar(train(i:i))) = .true.
  end do
  do i = 1, len(val)
    seen(ichar(val(i:i))) = .true.                  ! sozluk: iki metindeki tum karakterler
  end do
  V = count(seen)
  do c = 0, 127
    tot(c) = sum(cnt(c,:))
  end do
  print '(A,I0)', 'sozluk boyutu V = ', V
  print '(A)', '     k     egitim PPL     dogrulama PPL'
  do i = 1, 4
    write(*,'(F7.2,A)', advance='no') ks(i), '   '
    call yaz(ppl(train, ks(i)))
    call yaz(ppl(val, ks(i)))
    print *
  end do
contains
  function ppl(text, k) result(r)
    character(len=*), intent(in) :: text
    real(dp), intent(in) :: k
    real(dp) :: r, p, ll
    integer :: j, a, b
    ll = 0.0_dp
    do j = 1, len(text) - 1
      a = ichar(text(j:j)); b = ichar(text(j+1:j+1))
      p = (cnt(a,b) + k) / (tot(a) + k * V)
      if (p <= 0.0_dp) then
        r = huge(1.0_dp); return                    ! sifir olasilik -> sonsuz
      end if
      ll = ll - log(p)
    end do
    r = exp(ll / (len(text) - 1))
  end function ppl

  subroutine yaz(v)
    real(dp), intent(in) :: v
    if (v > 1.0e100_dp) then
      write(*,'(A)', advance='no') '        sonsuz   '
    else
      write(*,'(F14.3,A)', advance='no') v, '   '
    end if
  end subroutine yaz
end program bigram_ppl
