! Örnek 12.2: Harmonik osilatör: eşit aralıklı enerji merdiveni
! Derleme: gfortran -O2  ornek_12_02.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module eig_mod
  use prec_mod
  implicit none
contains
  subroutine jacobi_eig(A0, w, Vv)               ! simetrik matris: A = V diag(w) V^T, ozdegerler artan sirada
    real(dp), intent(in)  :: A0(:,:)
    real(dp), intent(out) :: w(:), Vv(:,:)
    real(dp), allocatable :: A(:,:)
    integer :: n, i, j, k, sweep
    real(dp) :: off, c, s, t, aij, tau, tmp
    n = size(A0,1)
    allocate(A(n,n)); A = A0
    Vv = 0.0_dp
    do i = 1, n
      Vv(i,i) = 1.0_dp
    end do
    do sweep = 1, 60
      off = 0.0_dp
      do j = 2, n
        do i = 1, j-1
          off = off + A(i,j)**2
        end do
      end do
      if (off < 1.0e-22_dp) exit
      do j = 2, n
        do i = 1, j-1
          aij = A(i,j)
          if (abs(aij) < 1.0e-300_dp) cycle
          tau = (A(j,j) - A(i,i)) / (2.0_dp*aij)
          t = sign(1.0_dp, tau) / (abs(tau) + sqrt(1.0_dp + tau*tau))
          c = 1.0_dp / sqrt(1.0_dp + t*t); s = t*c
          do k = 1, n                              ! A <- A J
            tmp = A(k,i); A(k,i) = c*tmp - s*A(k,j); A(k,j) = s*tmp + c*A(k,j)
          end do
          do k = 1, n                              ! A <- J^T A
            tmp = A(i,k); A(i,k) = c*tmp - s*A(j,k); A(j,k) = s*tmp + c*A(j,k)
          end do
          do k = 1, n                              ! ozvektorleri biriktir
            tmp = Vv(k,i); Vv(k,i) = c*tmp - s*Vv(k,j); Vv(k,j) = s*tmp + c*Vv(k,j)
          end do
        end do
      end do
    end do
    do i = 1, n
      w(i) = A(i,i)
    end do
    do i = 1, n-1                                  ! artan sirala
      k = minloc(w(i:n), dim=1) + i - 1
      if (k /= i) then
        tmp = w(i); w(i) = w(k); w(k) = tmp
        do j = 1, n
          tmp = Vv(j,i); Vv(j,i) = Vv(j,k); Vv(j,k) = tmp
        end do
      end if
    end do
  end subroutine jacobi_eig
end module eig_mod

program harmonik
  use eig_mod
  implicit none
  integer, parameter :: n = 300
  real(dp), parameter :: xmax = 8.0_dp
  real(dp) :: H(n,n), w(n), Vv(n,n), h_, x(n), vpot(n), ev, et, x2
  integer :: i, k
  h_ = 2.0_dp * xmax / (n + 1)
  do i = 1, n
    x(i) = -xmax + i * h_
  end do
  vpot = 0.5_dp * x**2                              ! V(x) = x^2 / 2
  H = 0.0_dp
  do i = 1, n
    H(i,i) = 1.0_dp / h_**2 + vpot(i)
    if (i < n) then
      H(i,i+1) = -0.5_dp / h_**2; H(i+1,i) = -0.5_dp / h_**2
    end if
  end do
  call jacobi_eig(H, w, Vv)
  print '(A)', ' n   E(sayisal)   E(analitik n+1/2)'
  do k = 1, 6
    print '(I3,2F14.6)', k-1, w(k), k - 0.5_dp
  end do
  ev = sum(Vv(:,1)**2 * vpot)                       ! <V> temel durumda
  et = w(1) - ev                                    ! <T> = E - <V>
  x2 = sum(Vv(:,1)**2 * x**2)
  print '(A,F9.5)', '<x^2>     = ', x2
  print '(A,F9.5,A,F9.5)', '<T>, <V>  = ', et, ',', ev
end program harmonik
