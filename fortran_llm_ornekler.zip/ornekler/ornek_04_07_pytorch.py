# Örnek 4.7: FFN ve residual bağlantı (PyTorch karşılığı)
import torch, torch.nn as nn
torch.manual_seed(2)
T_, d = 3, 4
ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(approximate='tanh'), nn.Linear(4 * d, d))
for p in ffn.parameters(): nn.init.normal_(p, std=0.02)
for p in [ffn[0].bias, ffn[2].bias]: nn.init.zeros_(p)
X = torch.randn(T_, d)
Y = ffn(X)
print("|FFN(x)| en buyuk eleman       =", f"{Y.abs().max().item():.2e}")
print("|x + FFN(x) - x| en buyuk fark =", f"{((X + Y) - X).abs().max().item():.2e}")
print("parametre sayisi:", sum(p.numel() for p in ffn.parameters()), " | 8d^2+5d =", 8 * d * d + 5 * d)

