! Örnek 7.5: İçeriğe dayalı bölme: sızıntıyı önle
! Derleme: gfortran -O2  ornek_07_05.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program bolme
  use rng_mod
  implicit none
  integer, parameter :: nu = 1000, nd = 100, n = nu + nd
  integer :: sp_r(n), sp_h(n), i, k, j, leak_r, leak_h, cr(3), ch(3)
  character(len=40) :: doc
  call rng_seed(5)
  do i = 1, n
    k = i
    if (i > nu) k = i - nu                         ! 1001..1100: 1..100'un kopyasi
    write(doc, '(A,I0,A)') 'dokuman ', k, ' metni'
    sp_h(i) = kume(mod(hash(doc), 100_8))          ! icerige gore
    sp_r(i) = kume(int(uniform() * 100.0_dp, 8))   ! rastgele
  end do
  leak_r = 0; leak_h = 0
  do j = 1, nd
    if (sp_r(j) /= sp_r(nu+j)) leak_r = leak_r + 1
    if (sp_h(j) /= sp_h(nu+j)) leak_h = leak_h + 1
  end do
  do i = 1, 3
    cr(i) = count(sp_r == i); ch(i) = count(sp_h == i)
  end do
  print '(A,3I6)', 'rastgele bolme  egitim/dogrulama/test : ', cr
  print '(A,3I6)', 'hash tabanli    egitim/dogrulama/test : ', ch
  print '(A,I0,A)', 'rastgele bolmede kopyasi baska kumeye dusen belge : ', leak_r, ' / 100'
  print '(A,I0,A)', 'hash tabanli bolmede ayni sayi                    : ', leak_h, ' / 100'
contains
  function kume(v) result(c)                       ! 0-89 egitim, 90-94 dogrulama, 95-99 test
    integer(8), intent(in) :: v
    integer :: c
    if (v < 90) then
      c = 1
    else if (v < 95) then
      c = 2
    else
      c = 3
    end if
  end function kume

  function hash(x) result(hh)
    character(len=*), intent(in) :: x
    integer(8) :: hh
    integer :: i
    hh = 7_8
    do i = 1, len_trim(x)
      hh = mod(hh * 131_8 + ichar(x(i:i)), 2147483647_8)
    end do
    hh = mod(hh * 1103515245_8 + 12345_8, 2147483648_8)   ! karistir
  end function hash
end program bolme
