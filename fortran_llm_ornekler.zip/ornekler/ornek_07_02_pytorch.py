# Örnek 7.2: Satır satır ve parça parça okuma (PyTorch karşılığı)
import os
with open("orn.txt", "w") as f:
    for i in range(1, 5001):
        f.write(f"satir {i} ornek metin kelime kelime\n")
nl = nw = 0
with open("orn.txt") as f:                    # satir satir: bellekte tek satir
    for line in f:
        nl += 1; nw += len(line.split())
nl2 = chunks = 0
with open("orn.txt", "rb") as f:              # sabit 4096 baytlik parcalar
    while chunk := f.read(4096):
        nl2 += chunk.count(b"\n"); chunks += 1
print("dosya boyutu          :", os.path.getsize("orn.txt"), "bayt")
print("satir modu            : satir=%d  kelime=%d" % (nl, nw))
print("parca modu            : satir=%d  parca sayisi=%d" % (nl2, chunks))

