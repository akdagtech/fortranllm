# Örnek 1.9: Entropi ve çapraz entropi (PyTorch karşılığı)
import torch
import torch.nn.functional as F
ent = lambda p: -(p * p.log()).sum()
print("H(0.5,0.5)         =", round(ent(torch.tensor([.5, .5])).item(), 4))
print("H(0.9,0.1)         =", round(ent(torch.tensor([.9, .1])).item(), 4))
print("H(4 esit olasilik) =", round(ent(torch.tensor([.25]*4)).item(), 4))
q1 = torch.tensor([0.7, 0.2, 0.1]); q2 = torch.tensor([0.1, 0.6, 0.3])
# dogru sinif 0 iken capraz entropi = nll_loss(log q)
ce = lambda q: F.nll_loss(q.log()[None, :], torch.tensor([0]))
print("CE(iyi model)  =", round(ce(q1).item(), 4))
print("CE(kotu model) =", round(ce(q2).item(), 4))
print("ln(3)          =", round(torch.log(torch.tensor(3.0)).item(), 4))

