# Örnek 3.1: Mini-batch SGD ile doğru uydurma (PyTorch karşılığı)
import torch
torch.manual_seed(11)
n, bs = 100, 10
x = torch.rand(n, 1) * 2 - 1
y = 2 * x + 1 + 0.1 * torch.randn(n, 1)
model = torch.nn.Linear(1, 1)
torch.nn.init.zeros_(model.weight); torch.nn.init.zeros_(model.bias)
opt = torch.optim.SGD(model.parameters(), lr=0.1)
for ep in range(51):
    if ep % 10 == 0:
        loss = torch.nn.functional.mse_loss(model(x), y)
        print(f"epoch {ep:3d}  w={model.weight.item():7.4f}  b={model.bias.item():7.4f}  kayip={loss.item():8.5f}")
    for s in range(0, n, bs):                      # mini-batch'ler
        xb, yb = x[s:s+bs], y[s:s+bs]
        loss = torch.nn.functional.mse_loss(model(xb), yb)
        opt.zero_grad(); loss.backward(); opt.step()
A = torch.cat([x, torch.ones(n, 1)], 1)
sol = torch.linalg.lstsq(A, y).solution.flatten()
print(f"en kucuk kareler: w={sol[0]:.4f}  b={sol[1]:.4f}")

