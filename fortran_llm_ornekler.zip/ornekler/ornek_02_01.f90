! Örnek 2.1: Perceptron ile AND kapısını öğren
! Derleme: gfortran -O2  ornek_02_01.f90 -o ornek
program perceptron
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: X(4,2), t(4), w(2), b, lr, y
  integer :: ep, i, hata
  X = reshape([0,0,1,1, 0,1,0,1] * 1.0_dp, [4,2])   ! satirlar: 00 01 10 11
  t = [0,0,0,1] * 1.0_dp
  w = 0.0_dp; b = 0.0_dp; lr = 0.5_dp
  do ep = 1, 20
    hata = 0
    do i = 1, 4
      if (dot_product(w, X(i,:)) + b > 0.0_dp) then
        y = 1.0_dp
      else
        y = 0.0_dp
      end if
      if (y /= t(i)) hata = hata + 1
      w = w + lr * (t(i) - y) * X(i,:)
      b = b + lr * (t(i) - y)
    end do
    print '(A,I2,A,I2,A,2F6.2,A,F6.2)', 'epoch ', ep, '  hata=', hata, '  w=', w, '  b=', b
    if (hata == 0) exit
  end do
  do i = 1, 4
    y = merge(1.0_dp, 0.0_dp, dot_product(w, X(i,:)) + b > 0.0_dp)
    print '(A,2F4.0,A,F4.0)', 'girdi', X(i,:), '  -> ', y
  end do
end program perceptron
