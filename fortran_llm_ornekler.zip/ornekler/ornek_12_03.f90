! Örnek 12.3: Hidrojen atomu: radyal Schrödinger denklemi
! Derleme: gfortran -O2  ornek_12_03.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module eig_mod
  use prec_mod
  implicit none
contains
  subroutine jacobi_eig(A0, w, Vv)               ! simetrik matris: A = V diag(w) V^T, ozdegerler artan sirada
    real(dp), intent(in)  :: A0(:,:)
    real(dp), intent(out) :: w(:), Vv(:,:)
    real(dp), allocatable :: A(:,:)
    integer :: n, i, j, k, sweep
    real(dp) :: off, c, s, t, aij, tau, tmp
    n = size(A0,1)
    allocate(A(n,n)); A = A0
    Vv = 0.0_dp
    do i = 1, n
      Vv(i,i) = 1.0_dp
    end do
    do sweep = 1, 60
      off = 0.0_dp
      do j = 2, n
        do i = 1, j-1
          off = off + A(i,j)**2
        end do
      end do
      if (off < 1.0e-22_dp) exit
      do j = 2, n
        do i = 1, j-1
          aij = A(i,j)
          if (abs(aij) < 1.0e-300_dp) cycle
          tau = (A(j,j) - A(i,i)) / (2.0_dp*aij)
          t = sign(1.0_dp, tau) / (abs(tau) + sqrt(1.0_dp + tau*tau))
          c = 1.0_dp / sqrt(1.0_dp + t*t); s = t*c
          do k = 1, n                              ! A <- A J
            tmp = A(k,i); A(k,i) = c*tmp - s*A(k,j); A(k,j) = s*tmp + c*A(k,j)
          end do
          do k = 1, n                              ! A <- J^T A
            tmp = A(i,k); A(i,k) = c*tmp - s*A(j,k); A(j,k) = s*tmp + c*A(j,k)
          end do
          do k = 1, n                              ! ozvektorleri biriktir
            tmp = Vv(k,i); Vv(k,i) = c*tmp - s*Vv(k,j); Vv(k,j) = s*tmp + c*Vv(k,j)
          end do
        end do
      end do
    end do
    do i = 1, n
      w(i) = A(i,i)
    end do
    do i = 1, n-1                                  ! artan sirala
      k = minloc(w(i:n), dim=1) + i - 1
      if (k /= i) then
        tmp = w(i); w(i) = w(k); w(k) = tmp
        do j = 1, n
          tmp = Vv(j,i); Vv(j,i) = Vv(j,k); Vv(j,k) = tmp
        end do
      end if
    end do
  end subroutine jacobi_eig
end module eig_mod

program hidrojen
  use eig_mod
  implicit none
  integer, parameter :: n = 400
  real(dp), parameter :: Rmax = 40.0_dp
  real(dp) :: H(n,n), w(n), Vv(n,n), h_, r(n), rm
  integer :: i, l
  h_ = Rmax / (n + 1)
  do i = 1, n
    r(i) = i * h_
  end do
  do l = 0, 1
    H = 0.0_dp
    do i = 1, n
      H(i,i) = 1.0_dp/h_**2 + 0.5_dp*l*(l+1)/r(i)**2 - 1.0_dp/r(i)
      if (i < n) then
        H(i,i+1) = -0.5_dp/h_**2; H(i+1,i) = -0.5_dp/h_**2
      end if
    end do
    call jacobi_eig(H, w, Vv)
    print '(A,I1,A,3F12.6)', 'l=', l, '  E(sayisal)  : ', w(1:3)
    if (l == 0) print '(A,3F12.6)', '       E(analitik) : ', -0.5_dp, -0.125_dp, -1.0_dp/18.0_dp
    if (l == 1) print '(A,3F12.6)', '       E(analitik) : ', -0.125_dp, -1.0_dp/18.0_dp, -1.0_dp/32.0_dp
    rm = sum(Vv(:,1)**2 * r) / sum(Vv(:,1)**2)
    print '(A,F9.4)', '       <r> (ilk durum): ', rm
    if (l == 0) then
      rm = sum(Vv(:,2)**2 * r) / sum(Vv(:,2)**2)
      print '(A,F9.4)', '       <r> (2s)       : ', rm
    end if
  end do
  print '(A)', 'analitik <r>: 1s=1.5  2s=6.0  2p=5.0'
end program hidrojen
