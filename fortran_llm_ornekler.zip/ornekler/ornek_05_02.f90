! Örnek 5.2: Üç matris çarpımı: ijk, jki ve matmul
! Derleme: gfortran -O2  ornek_05_02.f90 -o ornek
program matmul_karsilastir
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 512
  real(dp), allocatable :: A(:,:), B(:,:), C1(:,:), C2(:,:), C3(:,:)
  real(dp) :: t0, t1, t2, t3, fl
  integer :: i, j, k
  allocate(A(n,n), B(n,n), C1(n,n), C2(n,n), C3(n,n))
  call random_number(A); call random_number(B)
  fl = 2.0_dp * real(n, dp)**3
  C1 = 0.0_dp; t0 = now()
  do i = 1, n                          ! ijk: A(i,k) satir boyunca atlar
    do j = 1, n
      do k = 1, n
        C1(i,j) = C1(i,j) + A(i,k) * B(k,j)
      end do
    end do
  end do
  t1 = now()
  C2 = 0.0_dp
  do j = 1, n                          ! jki: en icte i, hepsi ardisik
    do k = 1, n
      do i = 1, n
        C2(i,j) = C2(i,j) + A(i,k) * B(k,j)
      end do
    end do
  end do
  t2 = now()
  C3 = matmul(A, B)
  t3 = now()
  print '(A,F8.3,A,F7.2,A)', 'ijk    : ', t1-t0, ' s   ', fl/(t1-t0)/1.0e9_dp, ' GFLOP/s'
  print '(A,F8.3,A,F7.2,A)', 'jki    : ', t2-t1, ' s   ', fl/(t2-t1)/1.0e9_dp, ' GFLOP/s'
  print '(A,F8.3,A,F7.2,A)', 'matmul : ', t3-t2, ' s   ', fl/(t3-t2)/1.0e9_dp, ' GFLOP/s'
  print '(A,ES10.2)', 'max |ijk - matmul| = ', maxval(abs(C1 - C3))
  print '(A,ES10.2)', 'max |jki - matmul| = ', maxval(abs(C2 - C3))
contains
  function now() result(t)
    integer(8) :: c, r
    real(dp) :: t
    call system_clock(c, r)
    t = real(c, dp) / real(r, dp)
  end function now
end program matmul_karsilastir
