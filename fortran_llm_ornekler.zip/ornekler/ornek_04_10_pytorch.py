# Örnek 4.10: Softmax/attention geri yayılımı: sayısal doğrulama (PyTorch karşılığı)
import torch
torch.manual_seed(9)
s = torch.randn(4, dtype=torch.float64, requires_grad=True)
V = torch.randn(4, 3, dtype=torch.float64); g = torch.randn(3, dtype=torch.float64)
p = torch.softmax(s, 0)
L = (p @ V) @ g                             # L = g . (sum_j p_j v_j)
L.backward()
pd = p.detach(); dp = V @ g
ds = pd * (dp - (pd * dp).sum())            # elle softmax geri yayilimi
print("formul     dL/ds =", [round(v, 6) for v in ds.tolist()])
print("autograd   dL/ds =", [round(v, 6) for v in s.grad.tolist()])

