! Örnek 11.2: Model 2: MLP dil modeli (elle geri yayılım + gradyan kontrolü)
! Derleme: gfortran -O2  ornek_11_02.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module lmdata
  use rng_mod
  implicit none
  character(len=*), parameter :: corpus = &
    'bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken ' // &
    'pireler berber iken ben annemin besigini tangir tungur sallar iken. ' // &
    'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. ' // &
    'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. ' // &
    'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. ' // &
    'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. ' // &
    'yolcular gelir su icer dinlenir sonra yoluna devam edermis. '
  integer, parameter :: NCH = len(corpus), V = 23     ! V: sozluk boyutu (asagida dogrulanir)
  integer :: ids(NCH), ntrain = 0
  character(len=1) :: chars(64)
contains
  subroutine build_vocab()                         ! karakter -> kimlik (1..V)
    integer :: i, c, nv, map(0:127)
    logical :: seen(0:127)
    seen = .false.
    do i = 1, NCH
      seen(ichar(corpus(i:i))) = .true.
    end do
    nv = 0; map = -1
    do c = 0, 127
      if (seen(c)) then
        nv = nv + 1; map(c) = nv; chars(nv) = char(c)
      end if
    end do
    if (nv /= V) error stop 'V yanlis: sozluk boyutunu guncelle'
    do i = 1, NCH
      ids(i) = map(ichar(corpus(i:i)))
    end do
    ntrain = int(0.85_dp * NCH)                      ! ilk %85 egitim, kalan dogrulama
  end subroutine build_vocab

  function decode(a) result(s)                     ! kimlikler -> metin
    integer, intent(in) :: a(:)
    character(len=size(a)) :: s
    integer :: i
    do i = 1, size(a)
      s(i:i) = chars(a(i))
    end do
  end function decode

  subroutine softmax_vec(z, p)
    real(dp), intent(in)  :: z(:)
    real(dp), intent(out) :: p(:)
    p = exp(z - maxval(z)); p = p / sum(p)
  end subroutine softmax_vec

  subroutine adam_step(p, g, m, s, t, lr)          ! tek vektor uzerinde Adam
    real(dp), intent(inout) :: p(:), m(:), s(:)
    real(dp), intent(in)    :: g(:), lr
    integer, intent(in)     :: t
    real(dp), parameter :: b1 = 0.9_dp, b2 = 0.999_dp, eps = 1.0e-8_dp
    m = b1 * m + (1.0_dp - b1) * g
    s = b2 * s + (1.0_dp - b2) * g * g
    p = p - lr * (m / (1.0_dp - b1**t)) / (sqrt(s / (1.0_dp - b2**t)) + eps)
  end subroutine adam_step
end module lmdata

program mlp_lm
  use lmdata
  implicit none
  integer, parameter :: NC = 3, ED = 8, NH = 48, nb = 64
  real(dp), allocatable, target :: th(:), gr(:)
  real(dp), allocatable :: m1(:), s1(:), g0(:)
  real(dp), pointer :: E_(:,:), W1(:,:), b1(:), W2(:,:), b2(:)
  real(dp), pointer :: gE(:,:), gW1(:,:), gb1(:), gW2(:,:), gb2(:)
  integer :: nth, o, step, i, idx(nb), b, tpos, ntr, k, cur(NC), nxt
  real(dp) :: loss, lsum, lp, lm, num, maxrel, old, p(V)
  integer :: gen(150)
  call build_vocab()
  nth = V*ED + NC*ED*NH + NH + NH*V + V
  allocate(th(nth), gr(nth), m1(nth), s1(nth), g0(nth))
  o = 0
  E_(1:V,1:ED)     => th(o+1:o+V*ED);     gE(1:V,1:ED)     => gr(o+1:o+V*ED);     o = o + V*ED
  W1(1:NC*ED,1:NH) => th(o+1:o+NC*ED*NH)
  gW1(1:NC*ED,1:NH) => gr(o+1:o+NC*ED*NH);   o = o + NC*ED*NH
  b1 => th(o+1:o+NH);                    gb1 => gr(o+1:o+NH);                   o = o + NH
  W2(1:NH,1:V)     => th(o+1:o+NH*V);     gW2(1:NH,1:V)    => gr(o+1:o+NH*V);     o = o + NH*V
  b2 => th(o+1:o+V);                    gb2 => gr(o+1:o+V)
  call rng_seed(11)
  call randn1(th, 0.3_dp)
  b1 = 0.0_dp; b2 = 0.0_dp
  m1 = 0.0_dp; s1 = 0.0_dp
  ntr = ntrain - NC - 1                              ! egitim ornek sayisi (tpos = NC .. ntrain-1)
  ! ---- gradyan kontrolu: ilk 20 ornek
  idx(1:20) = [(NC + i - 1, i = 1, 20)]
  loss = batch(idx, 20, .true.)
  g0 = gr
  maxrel = 0.0_dp
  do i = 1, 12
    k = 1 + mod(i * 97, nth)
    old = th(k)
    th(k) = old + 1.0e-6_dp; lp = batch(idx, 20, .false.)
    th(k) = old - 1.0e-6_dp; lm = batch(idx, 20, .false.)
    th(k) = old
    num = (lp - lm) / 2.0e-6_dp
    maxrel = max(maxrel, abs(num - g0(k)) / max(1.0e-8_dp, abs(num) + abs(g0(k))))
  end do
  print '(A,ES10.2)', 'gradyan kontrolu, en buyuk bagil hata = ', maxrel
  print '(A,I0,A,F7.4)', 'parametre sayisi = ', nth, '   baslangic kaybi = ', loss
  ! ---- egitim
  do step = 1, 3000
    do b = 1, nb
      idx(b) = NC + int(uniform() * ntr)             ! rastgele egitim konumu
    end do
    gr = 0.0_dp
    lsum = batch(idx, nb, .true.)
    gr = gr / nb
    call adam_step(th, gr, m1, s1, step, 0.01_dp)
    if (step == 1 .or. mod(step, 500) == 0) then
      print '(A,I5,A,F8.4,A,F8.4)', 'adim ', step, '  egitim=', eval(NC, ntrain-1), &
            '  dogrulama=', eval(ntrain+NC, NCH-1)
    end if
  end do
  ! ---- metin uret (sicaklik 0.8)
  call rng_seed(3)
  gen(1:NC) = ids(1:NC)
  do i = NC + 1, 150
    cur = gen(i-NC:i-1)
    call predict(cur, p)
    p = p ** (1.0_dp / 0.8_dp); p = p / sum(p)
    call sample(p, nxt)
    gen(i) = nxt
  end do
  print '(A)', 'uretilen metin:'
  print '(A)', decode(gen)
contains
  subroutine predict(ctx, pr)                       ! ileri gecis (tek ornek)
    integer, intent(in) :: ctx(NC)
    real(dp), intent(out) :: pr(V)
    real(dp) :: x(NC*ED), h(NH)
    integer :: j
    do j = 1, NC
      x((j-1)*ED+1:j*ED) = E_(ctx(j),:)
    end do
    h = tanh(matmul(x, W1) + b1)
    call softmax_vec(matmul(h, W2) + b2, pr)
  end subroutine predict

  function batch(ix, n, dograd) result(l)           ! ortalama kayip (+ istenirse gradyan)
    integer, intent(in) :: ix(:), n
    logical, intent(in) :: dograd
    real(dp) :: l, x(NC*ED), h(NH), pr(V), dlog(V), dh(NH), dz(NH), dx(NC*ED)
    integer :: s, j, ctx(NC), tgt
    l = 0.0_dp
    if (dograd) gr = 0.0_dp
    do s = 1, n
      ctx = ids(ix(s)-NC+1:ix(s)); tgt = ids(ix(s)+1)
      do j = 1, NC
        x((j-1)*ED+1:j*ED) = E_(ctx(j),:)
      end do
      h = tanh(matmul(x, W1) + b1)
      call softmax_vec(matmul(h, W2) + b2, pr)
      l = l - log(pr(tgt))
      if (dograd) then
        dlog = pr; dlog(tgt) = dlog(tgt) - 1.0_dp
        gW2 = gW2 + spread(h, 2, V) * spread(dlog, 1, NH)
        gb2 = gb2 + dlog
        dh = matmul(W2, dlog)
        dz = dh * (1.0_dp - h**2)
        gW1 = gW1 + spread(x, 2, NH) * spread(dz, 1, NC*ED)
        gb1 = gb1 + dz
        dx = matmul(W1, dz)
        do j = 1, NC
          gE(ctx(j),:) = gE(ctx(j),:) + dx((j-1)*ED+1:j*ED)
        end do
      end if
    end do
    l = l / n
    if (dograd) gr = gr / n
  end function batch

  function eval(lo, hi) result(l)                   ! tpos = lo..hi uzerinde ortalama kayip
    integer, intent(in) :: lo, hi
    real(dp) :: l, pr(V)
    integer :: tp
    l = 0.0_dp
    do tp = lo, hi
      call predict(ids(tp-NC+1:tp), pr)
      l = l - log(pr(ids(tp+1)))
    end do
    l = l / (hi - lo + 1)
  end function eval

  subroutine sample(pr, k)
    real(dp), intent(in) :: pr(:)
    integer, intent(out) :: k
    real(dp) :: u, cs
    u = uniform(); cs = 0.0_dp
    do k = 1, size(pr)
      cs = cs + pr(k)
      if (u <= cs) return
    end do
    k = size(pr)
  end subroutine sample
end program mlp_lm
