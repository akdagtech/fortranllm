! Örnek 14.3: Fonksiyonel türev: v<sub>x</sub> = δE<sub>x</sub>/δn
! Derleme: gfortran -O2  ornek_14_03.f90 -o ornek
program fonksiyonel_turev
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer, parameter :: n = 400
  real(dp), parameter :: pi = 3.141592653589793_dp
  real(dp) :: r(n), dens(n), h, e0, e1, delta, vx_num, vx_ana
  integer :: idx(4), k, i
  h = 10.0_dp / n
  do i = 1, n
    r(i) = i * h
  end do
  dens = exp(-2.0_dp * r) / pi                       ! ornek yogunluk (H atomu 1s)
  idx = [10, 40, 90, 160]
  print '(A)', '   r(Bohr)     v_x (sayisal d(E_x)/d(n))     v_x = (4/3) eps_x     fark'
  do k = 1, 4
    i = idx(k)
    delta = 1.0e-6_dp * dens(i)
    e0 = ex_total(dens)
    dens(i) = dens(i) + delta                         ! tek ızgara noktasinda yogunlugu boz
    e1 = ex_total(dens)
    dens(i) = dens(i) - delta
    vx_num = (e1 - e0) / (delta * 4.0_dp * pi * r(i)**2 * h)   ! fonksiyonel turev = dE / (dn * hacim)
    vx_ana = -(3.0_dp/pi)**(1.0_dp/3.0_dp) * dens(i)**(1.0_dp/3.0_dp)
    print '(F9.3,F26.6,F22.6,ES12.2)', r(i), vx_num, vx_ana, abs(vx_num - vx_ana)
  end do
contains
  function ex_total(d) result(e)                      ! E_x[n] = int n eps_x(n) d^3r
    real(dp), intent(in) :: d(:)
    real(dp) :: e
    e = sum(4.0_dp*pi*r**2 * d * (-0.75_dp*(3.0_dp/pi)**(1.0_dp/3.0_dp) * d**(1.0_dp/3.0_dp))) * h
  end function ex_total
end program fonksiyonel_turev
