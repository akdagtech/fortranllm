! Örnek 1.1: Ortalama ve standart sapma
! Derleme: gfortran -O2  ornek_01_01.f90 -o ornek
program istatistik
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x(5), mu, sd
  x = [2.0_dp, 4.0_dp, 4.0_dp, 4.0_dp, 6.0_dp]
  mu = sum(x) / size(x)
  sd = sqrt(sum((x - mu)**2) / size(x))
  print '(A,F8.4)', 'ortalama   = ', mu
  print '(A,F8.4)', 'std sapma  = ', sd
  print '(A,F8.4)', 'en buyuk   = ', maxval(x)
end program istatistik
