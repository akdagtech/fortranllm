# Örnek 10.7: Batch boyutu, gecikme ve throughput modeli (PyTorch karşılığı)
wbytes, bw, peak, flop_tok = 14e9, 2e12, 312e12, 14e9
t_mem = wbytes / bw
print(f"agirlik okuma suresi = {t_mem*1e3:.2f} ms/adim")
print("   B   adim(ms)   tok/s (toplam)   sinir")
for B in [1, 8, 32, 128, 256, 512]:
    t_cmp = B * flop_tok / peak; t = max(t_mem, t_cmp)
    print(f"{B:5d}{t*1e3:10.2f}{B/t:16.0f}   {'bellek' if t_mem >= t_cmp else 'islem'}")
print(f"gecis noktasi B* = {t_mem * peak / flop_tok:.1f}")

