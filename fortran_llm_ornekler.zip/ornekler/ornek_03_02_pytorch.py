# Örnek 3.2: Momentum'un etkin adımı (PyTorch karşılığı)
import torch
p = torch.tensor(0.0, requires_grad=True)
opt = torch.optim.SGD([p], lr=1.0, momentum=0.9)   # v = 0.9 v + g ; p -= lr*v
for k in range(1, 31):
    p.grad = torch.tensor(1.0)                      # sabit gradyan g = 1
    opt.step()
    v = opt.state[p]['momentum_buffer'].item()
    if k <= 5 or k % 5 == 0: print(f"adim {k:3d}   v = {v:9.5f}")
print("teorik sinir g/(1-beta) =", 1 / (1 - 0.9))

