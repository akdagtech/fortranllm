# Örnek 11.3: Model 3: Tek katmanlı, tek başlı attention dil modeli (PyTorch karşılığı)
import torch, torch.nn as nn, torch.nn.functional as F
corpus = ('bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken '
          'pireler berber iken ben annemin besigini tangir tungur sallar iken. '
          'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. '
          'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. '
          'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. '
          'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. '
          'yolcular gelir su icer dinlenir sonra yoluna devam edermis. ')
chars = sorted(set(corpus)); V = len(chars); ix = {c: i for i, c in enumerate(chars)}
ids = torch.tensor([ix[c] for c in corpus]); NCH = len(ids); ntrain = int(0.85 * NCH)
decode = lambda a: ''.join(chars[i] for i in a)

import math
torch.manual_seed(21)
d, TT = 16, 16
class AttnLM(nn.Module):                                      # token+konum -> causal attention -> residual -> tied logits
    def __init__(s):
        super().__init__()
        s.E = nn.Parameter(0.3 * torch.randn(V, d)); s.P = nn.Parameter(0.1 * torch.randn(TT, d))
        s.q, s.k, s.v, s.o = (nn.Linear(d, d, bias=False) for _ in range(4))
        for l in (s.q, s.k, s.v, s.o): nn.init.normal_(l.weight, std=0.25)
    def forward(s, x):                                        # x: (B, n)
        n = x.shape[1]
        X = s.E[x] + s.P[:n]
        A = F.scaled_dot_product_attention(s.q(X), s.k(X), s.v(X), is_causal=True)   # softmax(QK^T/sqrt(d)) V
        H = X + s.o(A)                                        # residual
        return H @ s.E.T                                      # weight tying
m = AttnLM(); opt = torch.optim.Adam(m.parameters(), lr=0.01)
print("parametre sayisi =", sum(p.numel() for p in m.parameters()))
def win(starts): return torch.stack([ids[s:s + TT] for s in starts]), torch.stack([ids[s + 1:s + TT + 1] for s in starts])
def ev(lo, hi):                                               # [lo,hi) araligindaki pencereler
    st = list(range(lo, hi - TT, 4)); x, y = win(st)
    with torch.no_grad(): return F.cross_entropy(m(x).flatten(0, 1), y.flatten()).item()
x, y = win([0])
print(f"baslangic kaybi = {F.cross_entropy(m(x).flatten(0, 1), y.flatten()).item():.4f}   ln V = {math.log(V):.4f}")
for step in range(1, 4001):
    x, y = win((torch.randint(0, ntrain - TT, (8,))).tolist())
    loss = F.cross_entropy(m(x).flatten(0, 1), y.flatten())
    opt.zero_grad(); loss.backward(); opt.step()
    if step == 1 or step % 1000 == 0:
        print(f"adim {step:5d}  egitim={ev(0, ntrain):8.4f}  dogrulama={ev(ntrain, NCH):8.4f}")
gen = ids[:8].tolist()
for _ in range(152):
    with torch.no_grad(): p = torch.softmax(m(torch.tensor([gen[-TT:]]))[0, -1] / 0.8, 0)
    gen.append(torch.multinomial(p, 1).item())
print("uretilen metin (ilk 8 karakter komut):"); print(decode(gen))

