# Örnek 4.6: LayerNorm ve RMSNorm modülü (PyTorch karşılığı)
import torch, torch.nn as nn
x = torch.tensor([[1., 2., 3., 4.]])
ln = nn.LayerNorm(4, eps=1e-5, elementwise_affine=False)
rms = nn.RMSNorm(4, eps=1e-5, elementwise_affine=False)
f = lambda t: " ".join(f"{v:9.4f}" for v in t.flatten())
print("LayerNorm(x)    =", f(ln(x)))
print("RMSNorm(x)      =", f(rms(x)))
print("LayerNorm(10x)  =", f(ln(10 * x)))
print("RMSNorm(10x)    =", f(rms(10 * x)))
print("LayerNorm(x+100)=", f(ln(x + 100)))

