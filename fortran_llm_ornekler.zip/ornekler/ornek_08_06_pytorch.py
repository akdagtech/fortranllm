# Örnek 8.6: Checkpoint ile devam: tam eşdeğerlik (PyTorch karşılığı)
import torch
x = torch.tensor([0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0], dtype=torch.float64)
y = torch.tensor([1.2, 1.9, 3.1, 3.8, 5.2, 5.9, 7.1, 7.8], dtype=torch.float64)
def make():
    p = torch.nn.Parameter(torch.zeros(2, dtype=torch.float64))
    return p, torch.optim.Adam([p], lr=0.05)
def train(p, opt, k):
    for _ in range(k):
        loss = ((p[0] * x + p[1] - y) ** 2).mean()
        opt.zero_grad(); loss.backward(); opt.step()
pA, oA = make(); train(pA, oA, 100)                              # (A) kesintisiz
pB, oB = make(); train(pB, oB, 50)
torch.save({"model": pB.detach(), "opt": oB.state_dict()}, "ckpt.pt")   # (B) tam durum
pB2, oB2 = make(); ck = torch.load("ckpt.pt")
pB2.data.copy_(ck["model"]); oB2.load_state_dict(ck["opt"]); train(pB2, oB2, 50)
pC, oC = make(); train(pC, oC, 50)                                # (C) yalniz agirliklar
pC2, oC2 = make(); pC2.data.copy_(pC.detach()); train(pC2, oC2, 50)
f = lambda p: " ".join(f"{v:14.10f}" for v in p.tolist())
print("(A) kesintisiz          :", f(pA)); print("(B) tam durumla devam   :", f(pB2)); print("(C) yalniz agirliklar   :", f(pC2))
print("|A - B| =", f"{(pA - pB2).abs().max().item():.2e}"); print("|A - C| =", f"{(pA - pC2).abs().max().item():.2e}")

