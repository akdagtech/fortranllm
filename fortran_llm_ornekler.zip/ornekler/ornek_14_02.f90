! Örnek 14.2: Helyum atomu: Kohn–Sham SCF (Hartree, LDA-x, LDA-xc)
! Derleme: gfortran -O2  ornek_14_02.f90 -o ornek
program ks_helyum
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer, parameter :: n = 2000
  real(dp), parameter :: pi = 3.141592653589793_dp, Rmax = 20.0_dp, Zn = 2.0_dp
  real(dp) :: r(n), u(n), nr(n), nold(n), vh(n), vx(n), vc(n), vext(n), veff(n), ex_(n), ec_(n)
  real(dp) :: h, eps, etot, eh, exc, vxc_int, de, eps_old, rmean
  integer :: i, it, mode
  character(len=24) :: lab(3)
  lab = [character(len=24) :: 'Yalniz Hartree (XC yok)', 'LDA: yalniz degisim', 'LDA: PW92 (x + c)']
  h = Rmax / n
  do i = 1, n
    r(i) = i * h
  end do
  vext = -Zn / r                                      ! cekirdek potansiyeli
  do mode = 1, 3
    eps_old = 0.0_dp
    u = exp(-1.6_dp * r); u = u / sqrt(sum(u**2) * h)  ! baslangic tahmini: 1s benzeri
    nr = 2.0_dp * u**2 / (4.0_dp * pi * r**2)          ! n(r) = 2 |u|^2 / (4 pi r^2)
    do it = 1, 600
      call hartree(nr, vh, eh)
      call xc(nr, vx, vc, ex_, ec_, mode)
      veff = vext + vh + vx + vc                       ! Kohn-Sham etkin potansiyeli
      call lowest(veff, u, eps)                        ! -1/2 u'' + veff u = eps u
      nold = nr
      nr = 0.5_dp * nold + 0.5_dp * (2.0_dp * u**2 / (4.0_dp * pi * r**2))   ! dogrusal karistirma
      de = abs(eps - eps_old); eps_old = eps
      if (it > 5 .and. de < 1.0e-9_dp) exit
    end do
    call hartree(nr, vh, eh)
    call xc(nr, vx, vc, ex_, ec_, mode)
    exc     = sum(4.0_dp*pi*r**2 * nr * (ex_ + ec_)) * h
    vxc_int = sum(4.0_dp*pi*r**2 * nr * (vx + vc)) * h
    etot = 2.0_dp * eps - eh - vxc_int + exc            ! toplam enerji (cift sayim duzeltmeli)
    rmean = sum(4.0_dp*pi*r**3 * nr) * h / 2.0_dp
    print '(A,A,F10.5,A,F9.5,A,I4)', lab(mode), ' E=', etot, '  eps_1s=', eps, '  iter=', it
    if (mode == 3) then
      print '(A,F7.4,A,F7.4)', '   toplam elektron = ', sum(4.0_dp*pi*r**2*nr)*h, '   <r> = ', rmean
      print '(A)', '   r (Bohr)      n(r)        V_H        V_xc'
      do i = 25, 1000, 75
        print '(F10.3,3F12.5)', r(i), nr(i), vh(i), vx(i) + vc(i)
      end do
    end if
  end do
  print '(A)', 'Karsilastirma: Hartree-Fock = -2.86168 Eh,  tam (deneysel) = -2.90372 Eh'
contains
  subroutine hartree(nr, vh, eh)                      ! Poisson denklemi (kuresel simetri)
    real(dp), intent(in) :: nr(:)
    real(dp), intent(out) :: vh(:), eh
    real(dp) :: cum(size(nr)), tail(size(nr))
    integer :: i
    cum(1) = 4.0_dp*pi*r(1)**2*nr(1)*h
    do i = 2, size(nr)
      cum(i) = cum(i-1) + 4.0_dp*pi*r(i)**2*nr(i)*h    ! r'e kadar olan yuk
    end do
    tail(size(nr)) = 0.0_dp
    do i = size(nr)-1, 1, -1
      tail(i) = tail(i+1) + 4.0_dp*pi*r(i+1)*nr(i+1)*h ! r'den dis kabuk katkisi
    end do
    vh = cum / r + tail                                ! V_H(r) = Q(r)/r + int_r^inf 4 pi r' n dr'
    eh = 0.5_dp * sum(4.0_dp*pi*r**2 * nr * vh) * h
  end subroutine hartree

  subroutine xc(nr, vx, vc, ex_, ec_, mode)
    real(dp), intent(in) :: nr(:)
    real(dp), intent(out) :: vx(:), vc(:), ex_(:), ec_(:)
    integer, intent(in) :: mode
    real(dp) :: rs, dd
    integer :: i
    vx = 0.0_dp; vc = 0.0_dp; ex_ = 0.0_dp; ec_ = 0.0_dp
    if (mode == 1) return
    do i = 1, size(nr)
      if (nr(i) < 1.0e-14_dp) cycle
      ex_(i) = -0.75_dp * (3.0_dp/pi)**(1.0_dp/3.0_dp) * nr(i)**(1.0_dp/3.0_dp)   ! Dirac degisimi
      vx(i)  = 4.0_dp/3.0_dp * ex_(i)                                            ! v_x = dE_x/dn
      if (mode == 3) then
        rs = (3.0_dp / (4.0_dp*pi*nr(i)))**(1.0_dp/3.0_dp)
        ec_(i) = pw92(rs)
        dd = 1.0e-5_dp * rs
        vc(i) = ec_(i) - rs/3.0_dp * (pw92(rs+dd) - pw92(rs-dd)) / (2.0_dp*dd)  ! v_c = e_c - (rs/3) de_c/drs
      end if
    end do
  end subroutine xc

  function pw92(rs) result(e)
    real(dp), intent(in) :: rs
    real(dp) :: e, A, a1, b1, b2, b3, b4
    A = 0.0310907_dp; a1 = 0.21370_dp
    b1 = 7.5957_dp; b2 = 3.5876_dp; b3 = 1.6382_dp; b4 = 0.49294_dp
    e = -2.0_dp*A*(1.0_dp + a1*rs) * log(1.0_dp + 1.0_dp / (2.0_dp*A*(b1*sqrt(rs) + b2*rs + &
        b3*rs**1.5_dp + b4*rs**2)))
  end function pw92

  subroutine lowest(veff, u, eps)                     ! en dusuk ozcift: ters iterasyon + Thomas algoritmasi
    real(dp), intent(in) :: veff(:)
    real(dp), intent(inout) :: u(:)
    real(dp), intent(out) :: eps
    real(dp) :: x(n), dg(n), cp(n), sig, bb, num
    integer :: i, k
    sig = minval(veff) - 0.05_dp                       ! kayma: H - sig ters cevrilir
    do k = 1, 40
      dg = 1.0_dp/h**2 + veff - sig                    ! uc-kosegen matris: kosegen
      cp(1) = -0.5_dp/h**2 / dg(1); x(1) = u(1)/dg(1)
      do i = 2, n
        bb = dg(i) + 0.5_dp/h**2 * cp(i-1)
        cp(i) = -0.5_dp/h**2 / bb
        x(i) = (u(i) + 0.5_dp/h**2 * x(i-1)) / bb
      end do
      u(n) = x(n)
      do i = n-1, 1, -1
        u(i) = x(i) - cp(i) * u(i+1)
      end do
      u = u / sqrt(sum(u**2) * h)
    end do
    num = 0.0_dp                                       ! Rayleigh bolumu: eps = <u|H|u>
    do i = 1, n
      num = num + u(i) * ((1.0_dp/h**2 + veff(i)) * u(i))
      if (i > 1) num = num - 0.5_dp/h**2 * u(i) * u(i-1)
      if (i < n) num = num - 0.5_dp/h**2 * u(i) * u(i+1)
    end do
    eps = num * h
  end subroutine lowest
end program ks_helyum
