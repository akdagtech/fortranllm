# Örnek 4.1: Embedding araması ve sinüs konum kodlaması (PyTorch karşılığı)
import torch, torch.nn as nn
torch.manual_seed(5)
V, d = 5, 4
E = nn.Embedding(V, d)                     # embedding tablosu (V x d)
pos = torch.arange(4).unsqueeze(1).double()
i = torch.arange(d // 2).double()
freq = 1.0 / 10000.0 ** (2 * i / d)
PE = torch.zeros(4, d, dtype=torch.float64)
PE[:, 0::2] = torch.sin(pos * freq)
PE[:, 1::2] = torch.cos(pos * freq)
print("Konum kodlamasi PE(pos, :) :")
for p in range(4):
    print(f"pos={p}  ", " ".join(f"{v:9.5f}" for v in PE[p]))
ids = torch.tensor([2, 4, 1])              # 0 tabanli kimlikler
X = E(ids) + PE[:3].float()                # embedding arama + konum
print("Girdi matrisi X = E[ids] + PE (T x d):")
print(X.detach())

