! Örnek 9.6: Boru hattı çizelgesi ve kabarcık oranı
! Derleme: gfortran -O2  ornek_09_06.f90 -o ornek
program pipeline
  implicit none
  integer, parameter :: p = 4, m = 6
  integer :: s, t, mb, ms(5)
  print '(A)', 'zaman ->  (sayi = mikro-batch numarasi, . = bosta)'
  do s = 1, p
    write(*,'(A,I1,A)', advance='no') 'stage ', s, ' | '
    do t = 0, m + p - 2
      mb = t - (s - 1) + 1                           ! bu stage'in bu adimdaki mikro-batch'i
      if (mb >= 1 .and. mb <= m) then
        write(*,'(I3)', advance='no') mb
      else
        write(*,'(A3)', advance='no') ' .'
      end if
    end do
    print *
  end do
  print '(A,F6.3)', 'kabarcik orani (p=4, m=6) = ', real(p-1) / real(m+p-1)
  ms = [1, 4, 8, 16, 32]
  print '(A)', 'p = 4 icin:  m     kabarcik orani'
  do t = 1, 5
    print '(I14,F15.3)', ms(t), real(p-1) / real(ms(t)+p-1)
  end do
end program pipeline
