! Örnek 12.1: Kutudaki parçacık: sonlu farklar ve Jacobi yöntemi
! Derleme: gfortran -O2  ornek_12_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module eig_mod
  use prec_mod
  implicit none
contains
  subroutine jacobi_eig(A0, w, Vv)               ! simetrik matris: A = V diag(w) V^T, ozdegerler artan sirada
    real(dp), intent(in)  :: A0(:,:)
    real(dp), intent(out) :: w(:), Vv(:,:)
    real(dp), allocatable :: A(:,:)
    integer :: n, i, j, k, sweep
    real(dp) :: off, c, s, t, aij, tau, tmp
    n = size(A0,1)
    allocate(A(n,n)); A = A0
    Vv = 0.0_dp
    do i = 1, n
      Vv(i,i) = 1.0_dp
    end do
    do sweep = 1, 60
      off = 0.0_dp
      do j = 2, n
        do i = 1, j-1
          off = off + A(i,j)**2
        end do
      end do
      if (off < 1.0e-22_dp) exit
      do j = 2, n
        do i = 1, j-1
          aij = A(i,j)
          if (abs(aij) < 1.0e-300_dp) cycle
          tau = (A(j,j) - A(i,i)) / (2.0_dp*aij)
          t = sign(1.0_dp, tau) / (abs(tau) + sqrt(1.0_dp + tau*tau))
          c = 1.0_dp / sqrt(1.0_dp + t*t); s = t*c
          do k = 1, n                              ! A <- A J
            tmp = A(k,i); A(k,i) = c*tmp - s*A(k,j); A(k,j) = s*tmp + c*A(k,j)
          end do
          do k = 1, n                              ! A <- J^T A
            tmp = A(i,k); A(i,k) = c*tmp - s*A(j,k); A(j,k) = s*tmp + c*A(j,k)
          end do
          do k = 1, n                              ! ozvektorleri biriktir
            tmp = Vv(k,i); Vv(k,i) = c*tmp - s*Vv(k,j); Vv(k,j) = s*tmp + c*Vv(k,j)
          end do
        end do
      end do
    end do
    do i = 1, n
      w(i) = A(i,i)
    end do
    do i = 1, n-1                                  ! artan sirala
      k = minloc(w(i:n), dim=1) + i - 1
      if (k /= i) then
        tmp = w(i); w(i) = w(k); w(k) = tmp
        do j = 1, n
          tmp = Vv(j,i); Vv(j,i) = Vv(j,k); Vv(j,k) = tmp
        end do
      end if
    end do
  end subroutine jacobi_eig
end module eig_mod

program kutu
  use eig_mod
  implicit none
  integer, parameter :: n = 200
  real(dp), parameter :: pi = 3.141592653589793_dp, L = 1.0_dp
  real(dp) :: H(n,n), w(n), Vv(n,n), h_, ex
  integer :: i, k, nodes
  h_ = L / (n + 1)
  H = 0.0_dp
  do i = 1, n
    H(i,i) = 1.0_dp / h_**2
    if (i < n) then
      H(i,i+1) = -0.5_dp / h_**2; H(i+1,i) = -0.5_dp / h_**2
    end if
  end do
  call jacobi_eig(H, w, Vv)
  print '(A)', ' n    E(sayisal)    E(analitik)    fark      bagil hata'
  do k = 1, 5
    ex = (k*pi/L)**2 / 2.0_dp
    print '(I3,3F14.6,ES11.2)', k, w(k), ex, w(k)-ex, abs(w(k)-ex)/ex
  end do
  nodes = 0                                          ! 3. durumun dugum (isaret degisimi) sayisi
  do i = 1, n-1
    if (Vv(i,3) * Vv(i+1,3) < 0.0_dp) nodes = nodes + 1
  end do
  print '(A,F10.6)', '<psi1|psi1> = ', sum(Vv(:,1)**2)
  print '(A,ES10.2)', '<psi1|psi2> = ', sum(Vv(:,1)*Vv(:,2))
  print '(A,I0)', '3. durumun dugum sayisi = ', nodes
end program kutu
