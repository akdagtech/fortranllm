! Örnek 2.8: Başlatma ölçeği: 20 katman boyunca sinyal
! Derleme: gfortran -O2  ornek_02_08.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program baslatma
  use rng_mod
  implicit none
  integer, parameter :: n = 64, nl = 20
  integer, parameter :: show(5) = [1, 2, 5, 10, 20]
  real(dp) :: W(n,n), x(n), sc(3), rec(5,3), rr(5,2)
  integer :: k, l, j
  call rng_seed(3)
  sc = [0.02_dp, 1.0_dp/sqrt(real(n,dp)), 0.5_dp]
  do k = 1, 3                                    ! tanh
    call randn1(x, 1.0_dp)
    do l = 1, nl
      call randn2(W, sc(k))
      x = tanh(matmul(x, W))
      do j = 1, 5
        if (l == show(j)) rec(j,k) = sqrt(sum(x**2) / n)
      end do
    end do
  end do
  print '(A)', 'TANH  katman   std=0.02   std=1/sqrt(n)   std=0.5'
  do j = 1, 5
    print '(I11,3ES14.3)', show(j), rec(j,:)
  end do
  do k = 1, 2                                    ! ReLU
    call randn1(x, 1.0_dp)
    do l = 1, nl
      call randn2(W, merge(1.0_dp, sqrt(2.0_dp), k == 1) / sqrt(real(n,dp)))
      x = max(0.0_dp, matmul(x, W))
      do j = 1, 5
        if (l == show(j)) rr(j,k) = sqrt(sum(x**2) / n)
      end do
    end do
  end do
  print '(A)', 'RELU  katman   Xavier    He'
  do j = 1, 5
    print '(I11,2ES14.3)', show(j), rr(j,:)
  end do
end program baslatma
