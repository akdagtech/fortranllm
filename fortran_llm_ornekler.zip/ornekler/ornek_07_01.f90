! Örnek 7.1: HTML etiketlerini ve varlıklarını temizle
! Derleme: gfortran -O2  ornek_07_01.f90 -o ornek
program html_temizle
  implicit none
  character(len=:), allocatable :: s, t
  s = '<html><head><title>Baslik</title></head><body>' // &
      '<h1>Merhaba &amp; hos geldin</h1>' // &
      '<p>LLM   egitimi&nbsp;icin<br>veri temizle &lt;3.</p>' // &
      '<script>var x = 1;</script></body></html>'
  t = remove_between(s, '<head', '</head>')
  t = remove_between(t, '<script', '</script>')
  t = strip_tags(t)
  t = replace_all(t, '&lt;', '<')
  t = replace_all(t, '&gt;', '>')
  t = replace_all(t, '&nbsp;', ' ')
  t = replace_all(t, '&amp;', '&')                   ! en son: cift cozmeyi onle
  do while (index(t, '  ') > 0)
    t = replace_all(t, '  ', ' ')
  end do
  print '(A,A)', 'ham   : ', s
  print '(A,A)', 'temiz : ', trim(adjustl(t))
contains
  function strip_tags(x) result(r)                   ! <...> aralarini ' ' ile degistir
    character(len=*), intent(in) :: x
    character(len=:), allocatable :: r
    logical :: in_tag
    integer :: i
    r = ''; in_tag = .false.
    do i = 1, len(x)
      if (x(i:i) == '<') then
        in_tag = .true.
      else if (x(i:i) == '>' .and. in_tag) then
        in_tag = .false.; r = r // ' '
      else if (.not. in_tag) then
        r = r // x(i:i)
      end if
    end do
  end function strip_tags

  function remove_between(x, a, b) result(r)
    character(len=*), intent(in) :: x, a, b
    character(len=:), allocatable :: r
    integer :: p, q
    r = x
    do
      p = index(r, a)
      if (p == 0) exit
      q = index(r(p:), b)
      if (q == 0) then
        r = r(:p-1); exit
      end if
      r = r(:p-1) // r(p+q-1+len(b):)
    end do
  end function remove_between

  function replace_all(x, a, b) result(r)
    character(len=*), intent(in) :: x, a, b
    character(len=:), allocatable :: r
    integer :: p, i
    r = ''; i = 1
    do
      p = index(x(i:), a)
      if (p == 0) then
        r = r // x(i:); exit
      end if
      r = r // x(i:i+p-2) // b
      i = i + p - 1 + len(a)
    end do
  end function replace_all
end program html_temizle
