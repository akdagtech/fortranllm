! Örnek 4.4: Projeksiyonlu attention ve nedensellik (causality) testi
! Derleme: gfortran -O2  ornek_04_04.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module attn_mod
  use prec_mod
  implicit none
contains
  subroutine softmax_rows(S)               ! her satiri ayri softmax'la
    real(dp), intent(inout) :: S(:,:)
    integer :: i
    do i = 1, size(S,1)
      S(i,:) = exp(S(i,:) - maxval(S(i,:)))
      S(i,:) = S(i,:) / sum(S(i,:))
    end do
  end subroutine softmax_rows

  subroutine causal_attention(Q, K, V, A, O)
    real(dp), intent(in)  :: Q(:,:), K(:,:), V(:,:)    ! (T,dk), (T,dk), (T,dv)
    real(dp), intent(out) :: A(:,:), O(:,:)            ! (T,T), (T,dv)
    integer :: T, i, j
    T = size(Q,1)
    A = matmul(Q, transpose(K)) / sqrt(real(size(Q,2), dp))
    do i = 1, T
      do j = i+1, T
        A(i,j) = -1.0e30_dp                             ! gelecegi maskele
      end do
    end do
    call softmax_rows(A)
    O = matmul(A, V)
  end subroutine causal_attention
end module attn_mod

program proj_attn
  use rng_mod
  use attn_mod
  implicit none
  integer, parameter :: T = 6, d = 8
  real(dp) :: X(T,d), X2(T,d), Wq(d,d), Wk(d,d), Wv(d,d)
  real(dp) :: A(T,T), O1(T,d), O2(T,d)
  call rng_seed(21)
  call randn2(X, 1.0_dp)
  call randn2(Wq, 0.5_dp); call randn2(Wk, 0.5_dp); call randn2(Wv, 0.5_dp)
  call causal_attention(matmul(X,Wq), matmul(X,Wk), matmul(X,Wv), A, O1)
  X2 = X
  X2(T,:) = X2(T,:) + 5.0_dp                 ! SON token'i degistir
  call causal_attention(matmul(X2,Wq), matmul(X2,Wk), matmul(X2,Wv), A, O2)
  print '(A,ES10.2)', 'ilk 5 satirin degisimi (max)  = ', maxval(abs(O1(1:T-1,:) - O2(1:T-1,:)))
  print '(A,ES10.2)', 'son satirin degisimi (max)    = ', maxval(abs(O1(T,:) - O2(T,:)))
end program proj_attn
