! Örnek 11.3: Model 3: Tek katmanlı, tek başlı attention dil modeli
! Derleme: gfortran -O2  ornek_11_03.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module lmdata
  use rng_mod
  implicit none
  character(len=*), parameter :: corpus = &
    'bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken ' // &
    'pireler berber iken ben annemin besigini tangir tungur sallar iken. ' // &
    'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. ' // &
    'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. ' // &
    'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. ' // &
    'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. ' // &
    'yolcular gelir su icer dinlenir sonra yoluna devam edermis. '
  integer, parameter :: NCH = len(corpus), V = 23     ! V: sozluk boyutu (asagida dogrulanir)
  integer :: ids(NCH), ntrain = 0
  character(len=1) :: chars(64)
contains
  subroutine build_vocab()                         ! karakter -> kimlik (1..V)
    integer :: i, c, nv, map(0:127)
    logical :: seen(0:127)
    seen = .false.
    do i = 1, NCH
      seen(ichar(corpus(i:i))) = .true.
    end do
    nv = 0; map = -1
    do c = 0, 127
      if (seen(c)) then
        nv = nv + 1; map(c) = nv; chars(nv) = char(c)
      end if
    end do
    if (nv /= V) error stop 'V yanlis: sozluk boyutunu guncelle'
    do i = 1, NCH
      ids(i) = map(ichar(corpus(i:i)))
    end do
    ntrain = int(0.85_dp * NCH)                      ! ilk %85 egitim, kalan dogrulama
  end subroutine build_vocab

  function decode(a) result(s)                     ! kimlikler -> metin
    integer, intent(in) :: a(:)
    character(len=size(a)) :: s
    integer :: i
    do i = 1, size(a)
      s(i:i) = chars(a(i))
    end do
  end function decode

  subroutine softmax_vec(z, p)
    real(dp), intent(in)  :: z(:)
    real(dp), intent(out) :: p(:)
    p = exp(z - maxval(z)); p = p / sum(p)
  end subroutine softmax_vec

  subroutine adam_step(p, g, m, s, t, lr)          ! tek vektor uzerinde Adam
    real(dp), intent(inout) :: p(:), m(:), s(:)
    real(dp), intent(in)    :: g(:), lr
    integer, intent(in)     :: t
    real(dp), parameter :: b1 = 0.9_dp, b2 = 0.999_dp, eps = 1.0e-8_dp
    m = b1 * m + (1.0_dp - b1) * g
    s = b2 * s + (1.0_dp - b2) * g * g
    p = p - lr * (m / (1.0_dp - b1**t)) / (sqrt(s / (1.0_dp - b2**t)) + eps)
  end subroutine adam_step
end module lmdata

program attn_lm
  use lmdata
  implicit none
  integer, parameter :: d = 16, TT = 16, nb = 8
  real(dp), allocatable, target :: th(:), gr(:)
  real(dp), allocatable :: m1(:), s1(:), g0(:)
  real(dp), pointer :: Em(:,:), Pe(:,:), Wq(:,:), Wk(:,:), Wv(:,:), Wo(:,:)
  real(dp), pointer :: gE(:,:), gPe(:,:), gWq(:,:), gWk(:,:), gWv(:,:), gWo(:,:)
  integer :: nth, o, step, b, s0, i, k, n, nxt
  real(dp) :: loss, lsum, lp, lm, num, maxrel, old, pr(V)
  integer :: gen(160)
  call build_vocab()
  nth = V*d + TT*d + 4*d*d
  allocate(th(nth), gr(nth), m1(nth), s1(nth), g0(nth))
  o = 0
  Em(1:V,1:d)   => th(o+1:o+V*d);   gE(1:V,1:d)   => gr(o+1:o+V*d);   o = o + V*d
  Pe(1:TT,1:d)  => th(o+1:o+TT*d);  gPe(1:TT,1:d) => gr(o+1:o+TT*d);  o = o + TT*d
  Wq(1:d,1:d)   => th(o+1:o+d*d);   gWq(1:d,1:d)  => gr(o+1:o+d*d);   o = o + d*d
  Wk(1:d,1:d)   => th(o+1:o+d*d);   gWk(1:d,1:d)  => gr(o+1:o+d*d);   o = o + d*d
  Wv(1:d,1:d)   => th(o+1:o+d*d);   gWv(1:d,1:d)  => gr(o+1:o+d*d);   o = o + d*d
  Wo(1:d,1:d)   => th(o+1:o+d*d);   gWo(1:d,1:d)  => gr(o+1:o+d*d)
  call rng_seed(21)
  call randn2(Em, 0.3_dp); call randn2(Pe, 0.1_dp)
  call randn2(Wq, 0.25_dp); call randn2(Wk, 0.25_dp)
  call randn2(Wv, 0.25_dp); call randn2(Wo, 0.25_dp)
  m1 = 0.0_dp; s1 = 0.0_dp
  ! ---- gradyan kontrolu (tek pencere)
  gr = 0.0_dp
  call fwd_bwd(ids(1:TT), ids(2:TT+1), TT, .true., loss, pr)
  g0 = gr
  maxrel = 0.0_dp
  do i = 1, 14
    k = 1 + mod(i * 131, nth)
    old = th(k)
    th(k) = old + 1.0e-6_dp; call fwd_bwd(ids(1:TT), ids(2:TT+1), TT, .false., lp, pr)
    th(k) = old - 1.0e-6_dp; call fwd_bwd(ids(1:TT), ids(2:TT+1), TT, .false., lm, pr)
    th(k) = old
    num = (lp - lm) / 2.0e-6_dp
    maxrel = max(maxrel, abs(num - g0(k)) / max(1.0e-8_dp, abs(num) + abs(g0(k))))
  end do
  print '(A,ES10.2)', 'gradyan kontrolu, en buyuk bagil hata = ', maxrel
  print '(A,I0,A,F7.4,A,F7.4)', 'parametre sayisi = ', nth, '  baslangic kaybi = ', loss, &
        '  ln V = ', log(real(V, dp))
  ! ---- egitim
  do step = 1, 4000
    gr = 0.0_dp; lsum = 0.0_dp
    do b = 1, nb
      s0 = 1 + int(uniform() * (ntrain - TT))      ! rastgele egitim penceresi
      call fwd_bwd(ids(s0:s0+TT-1), ids(s0+1:s0+TT), TT, .true., loss, pr)
      lsum = lsum + loss
    end do
    gr = gr / nb
    call adam_step(th, gr, m1, s1, step, 0.01_dp)
    if (step == 1 .or. mod(step, 1000) == 0) then
      print '(A,I5,A,F8.4,A,F8.4)', 'adim ', step, '  egitim=', eval(1, ntrain), &
            '  dogrulama=', eval(ntrain+1, NCH)
    end if
  end do
  ! ---- metin uret (sicaklik 0.8), baglam penceresi en fazla TT karakter
  call rng_seed(9)
  gen(1:8) = ids(1:8)
  do i = 9, 160
    n = min(i - 1, TT)
    call fwd_bwd(gen(i-n:i-1), gen(i-n:i-1), n, .false., loss, pr)
    pr = pr ** (1.0_dp / 0.8_dp); pr = pr / sum(pr)
    call sample(pr, nxt)
    gen(i) = nxt
  end do
  print '(A)', 'uretilen metin (ilk 8 karakter komut):'
  print '(A)', decode(gen)
contains
  subroutine smrows(Mx)
    real(dp), intent(inout) :: Mx(:,:)
    integer :: r
    do r = 1, size(Mx,1)
      Mx(r,:) = exp(Mx(r,:) - maxval(Mx(r,:)))
      Mx(r,:) = Mx(r,:) / sum(Mx(r,:))
    end do
  end subroutine smrows

  subroutine fwd_bwd(xi, yi, n, dograd, l, plast)   ! ileri gecis (+ geri gecis)
    integer, intent(in) :: n, xi(n), yi(n)
    logical, intent(in) :: dograd
    real(dp), intent(out) :: l, plast(V)
    real(dp) :: Xm(n,d), Q(n,d), K(n,d), Vv(n,d), A(n,n), Z(n,d), Hh(n,d), Pr(n,V)
    real(dp) :: dL(n,V), dH(n,d), dZ(n,d), dA(n,n), dV(n,d), dS(n,n), dQ(n,d), dK(n,d), dX(n,d)
    real(dp) :: sc
    integer :: t, r
    sc = 1.0_dp / sqrt(real(d, dp))
    do t = 1, n
      Xm(t,:) = Em(xi(t),:) + Pe(t,:)               ! token + konum embedding
    end do
    Q = matmul(Xm, Wq); K = matmul(Xm, Wk); Vv = matmul(Xm, Wv)
    A = matmul(Q, transpose(K)) * sc
    do r = 1, n - 1
      A(r, r+1:n) = -1.0e30_dp                      ! causal mask
    end do
    call smrows(A)
    Z  = matmul(A, Vv)
    Hh = Xm + matmul(Z, Wo)                          ! residual
    Pr = matmul(Hh, transpose(Em))                   ! logits (weight tying)
    call smrows(Pr)
    l = 0.0_dp
    do t = 1, n
      l = l - log(Pr(t, yi(t)))
    end do
    l = l / n
    plast = Pr(n,:)
    if (.not. dograd) return
    dL = Pr
    do t = 1, n
      dL(t, yi(t)) = dL(t, yi(t)) - 1.0_dp
    end do
    dL = dL / n
    dH = matmul(dL, Em)
    gE = gE + matmul(transpose(dL), Hh)              ! cikis tarafi
    gWo = gWo + matmul(transpose(Z), dH)
    dZ = matmul(dH, transpose(Wo))
    dA = matmul(dZ, transpose(Vv))
    dV = matmul(transpose(A), dZ)
    do r = 1, n                                      ! softmax geri yayilimi
      dS(r,:) = A(r,:) * (dA(r,:) - sum(A(r,:) * dA(r,:)))
    end do
    dS = dS * sc
    dQ = matmul(dS, K)
    dK = matmul(transpose(dS), Q)
    dX = dH + matmul(dQ, transpose(Wq)) + matmul(dK, transpose(Wk)) + matmul(dV, transpose(Wv))
    gWq = gWq + matmul(transpose(Xm), dQ)
    gWk = gWk + matmul(transpose(Xm), dK)
    gWv = gWv + matmul(transpose(Xm), dV)
    do t = 1, n
      gE(xi(t),:) = gE(xi(t),:) + dX(t,:)           ! giris tarafi
    end do
    gPe(1:n,:) = gPe(1:n,:) + dX
  end subroutine fwd_bwd

  function eval(lo, hi) result(l)                    ! [lo,hi] araligindaki pencereler
    integer, intent(in) :: lo, hi
    real(dp) :: l, lw, pl(V)
    integer :: s, cnt
    l = 0.0_dp; cnt = 0
    do s = lo, hi - TT, 4
      call fwd_bwd(ids(s:s+TT-1), ids(s+1:s+TT), TT, .false., lw, pl)
      l = l + lw; cnt = cnt + 1
    end do
    l = l / cnt
  end function eval

  subroutine sample(p, k)
    real(dp), intent(in) :: p(:)
    integer, intent(out) :: k
    real(dp) :: u, cs
    u = uniform(); cs = 0.0_dp
    do k = 1, size(p)
      cs = cs + p(k)
      if (u <= cs) return
    end do
    k = size(p)
  end subroutine sample
end program attn_lm
