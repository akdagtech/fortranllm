! Örnek 1.8: Öğrenme oranı çok küçükse, çok büyükse?
! Derleme: gfortran -O2  ornek_01_08.f90 -o ornek
program lrdene
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: lrs(6), x
  integer :: i, k
  lrs = [0.01_dp, 0.1_dp, 0.5_dp, 0.9_dp, 1.0_dp, 1.1_dp]
  do i = 1, 6
    x = 0.0_dp
    do k = 1, 20
      x = x - lrs(i) * 2.0_dp * (x - 3.0_dp)
    end do
    print '(A,F5.2,A,ES13.5,A,F8.4)', 'lr=', lrs(i), ' x(20)=', x, &
          ' carpan=', 1.0_dp - 2.0_dp*lrs(i)
  end do
end program lrdene
