! Örnek 4.8: Tam bir Transformer bloğu
! Derleme: gfortran -O2  ornek_04_08.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module attn_mod
  use prec_mod
  implicit none
contains
  subroutine softmax_rows(S)               ! her satiri ayri softmax'la
    real(dp), intent(inout) :: S(:,:)
    integer :: i
    do i = 1, size(S,1)
      S(i,:) = exp(S(i,:) - maxval(S(i,:)))
      S(i,:) = S(i,:) / sum(S(i,:))
    end do
  end subroutine softmax_rows

  subroutine causal_attention(Q, K, V, A, O)
    real(dp), intent(in)  :: Q(:,:), K(:,:), V(:,:)    ! (T,dk), (T,dk), (T,dv)
    real(dp), intent(out) :: A(:,:), O(:,:)            ! (T,T), (T,dv)
    integer :: T, i, j
    T = size(Q,1)
    A = matmul(Q, transpose(K)) / sqrt(real(size(Q,2), dp))
    do i = 1, T
      do j = i+1, T
        A(i,j) = -1.0e30_dp                             ! gelecegi maskele
      end do
    end do
    call softmax_rows(A)
    O = matmul(A, V)
  end subroutine causal_attention
end module attn_mod

module mha_mod
  use attn_mod
  implicit none
contains
  subroutine mha(X, Wq, Wk, Wv, Wo, nh, Y)
    real(dp), intent(in)  :: X(:,:), Wq(:,:), Wk(:,:), Wv(:,:), Wo(:,:)
    integer, intent(in)   :: nh
    real(dp), intent(out) :: Y(:,:)
    integer :: T, d, dh, h, c1, c2
    real(dp), allocatable :: Q(:,:), K(:,:), V(:,:), A(:,:), Oh(:,:), O(:,:)
    T = size(X,1); d = size(X,2); dh = d / nh
    allocate(Q(T,d), K(T,d), V(T,d), A(T,T), Oh(T,dh), O(T,d))
    Q = matmul(X, Wq); K = matmul(X, Wk); V = matmul(X, Wv)
    do h = 1, nh                                   ! her head icin sutun dilimi
      c1 = (h-1)*dh + 1; c2 = h*dh
      call causal_attention(Q(:,c1:c2), K(:,c1:c2), V(:,c1:c2), A, Oh)
      O(:,c1:c2) = Oh                              ! head ciktilarini yan yana koy
    end do
    Y = matmul(O, Wo)
  end subroutine mha
end module mha_mod

module norm_mod
  use prec_mod
  implicit none
contains
  subroutine layernorm_rows(X, gamma, beta, Y)
    real(dp), intent(in)  :: X(:,:), gamma(:), beta(:)
    real(dp), intent(out) :: Y(:,:)
    real(dp) :: mu, v
    integer :: i
    do i = 1, size(X,1)
      mu = sum(X(i,:)) / size(X,2)
      v  = sum((X(i,:) - mu)**2) / size(X,2)
      Y(i,:) = gamma * (X(i,:) - mu) / sqrt(v + 1.0e-5_dp) + beta
    end do
  end subroutine layernorm_rows

  subroutine rmsnorm_rows(X, gamma, Y)
    real(dp), intent(in)  :: X(:,:), gamma(:)
    real(dp), intent(out) :: Y(:,:)
    integer :: i
    do i = 1, size(X,1)
      Y(i,:) = gamma * X(i,:) / sqrt(sum(X(i,:)**2) / size(X,2) + 1.0e-5_dp)
    end do
  end subroutine rmsnorm_rows
end module norm_mod

module ffn_mod
  use prec_mod
  implicit none
contains
  elemental function gelu(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = 0.5_dp * x * (1.0_dp + tanh(0.7978845608028654_dp * (x + 0.044715_dp * x**3)))
  end function gelu

  subroutine ffn(X, W1, b1, W2, b2, Y)
    real(dp), intent(in)  :: X(:,:), W1(:,:), b1(:), W2(:,:), b2(:)
    real(dp), intent(out) :: Y(:,:)
    real(dp), allocatable :: Hd(:,:)
    integer :: T
    T = size(X,1)
    allocate(Hd(T, size(W1,2)))
    Hd = gelu(matmul(X, W1) + spread(b1, 1, T))
    Y  = matmul(Hd, W2) + spread(b2, 1, T)
  end subroutine ffn
end module ffn_mod

module blk_mod
  use mha_mod
  use norm_mod
  use ffn_mod
  use rng_mod
  implicit none
  type blk_t
    real(dp), allocatable :: g1(:), g2(:)
    real(dp), allocatable :: Wq(:,:), Wk(:,:), Wv(:,:), Wo(:,:)
    real(dp), allocatable :: W1(:,:), b1(:), W2(:,:), b2(:)
  end type blk_t
contains
  subroutine blk_init(p, d, std)
    type(blk_t), intent(out) :: p
    integer, intent(in) :: d
    real(dp), intent(in) :: std
    allocate(p%g1(d), p%g2(d), p%Wq(d,d), p%Wk(d,d), p%Wv(d,d), p%Wo(d,d))
    allocate(p%W1(d,4*d), p%b1(4*d), p%W2(4*d,d), p%b2(d))
    p%g1 = 1.0_dp; p%g2 = 1.0_dp; p%b1 = 0.0_dp; p%b2 = 0.0_dp
    call randn2(p%Wq, std); call randn2(p%Wk, std)
    call randn2(p%Wv, std); call randn2(p%Wo, std)
    call randn2(p%W1, std); call randn2(p%W2, std)
  end subroutine blk_init

  subroutine blk_forward(p, X, nh, Y)
    type(blk_t), intent(in) :: p
    real(dp), intent(in)  :: X(:,:)
    integer, intent(in)   :: nh
    real(dp), intent(out) :: Y(:,:)
    real(dp), allocatable :: Xn(:,:), Z(:,:)
    allocate(Xn(size(X,1),size(X,2)), Z(size(X,1),size(X,2)))
    call rmsnorm_rows(X, p%g1, Xn)                       ! 1) norm
    call mha(Xn, p%Wq, p%Wk, p%Wv, p%Wo, nh, Z)          !    attention
    Y = X + Z                                            !    residual
    call rmsnorm_rows(Y, p%g2, Xn)                       ! 2) norm
    call ffn(Xn, p%W1, p%b1, p%W2, p%b2, Z)              !    FFN
    Y = Y + Z                                            !    residual
  end subroutine blk_forward
end module blk_mod

program blok_test
  use blk_mod
  implicit none
  integer, parameter :: T = 6, d = 8, nh = 2
  type(blk_t) :: p
  real(dp) :: X(T,d), X2(T,d), Y1(T,d), Y2(T,d)
  call rng_seed(4)
  call blk_init(p, d, 0.3_dp)
  call randn2(X, 1.0_dp)
  call blk_forward(p, X, nh, Y1)
  X2 = X; X2(T,:) = X2(T,:) - 3.0_dp
  call blk_forward(p, X2, nh, Y2)
  print '(A,ES10.2)', 'onceki satirlarin degisimi = ', maxval(abs(Y1(1:T-1,:) - Y2(1:T-1,:)))
  print '(A,F8.4)',   'giris RMS = ', sqrt(sum(X**2)/size(X))
  print '(A,F8.4)',   'cikis RMS = ', sqrt(sum(Y1**2)/size(Y1))
end program blok_test
