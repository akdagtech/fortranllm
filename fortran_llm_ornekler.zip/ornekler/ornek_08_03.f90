! Örnek 8.3: Warmup + cosine öğrenme oranı çizelgesi
! Derleme: gfortran -O2  ornek_08_03.f90 -o ornek
program lr_cizelge
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  integer :: steps(9), i
  steps = [0, 50, 100, 200, 400, 600, 800, 900, 1000]
  print '(A)', '  adim       lr'
  do i = 1, 9
    print '(I6,ES12.3)', steps(i), lr_at(steps(i), 1000, 100, 6.0e-4_dp, 6.0e-5_dp)
  end do
contains
  function lr_at(t, tmax, warm, lmax, lmin) result(lr)
    integer, intent(in) :: t, tmax, warm
    real(dp), intent(in) :: lmax, lmin
    real(dp) :: lr, prog
    real(dp), parameter :: pi = 3.141592653589793_dp
    if (t < warm) then
      lr = lmax * real(t, dp) / real(warm, dp)
    else
      prog = real(t - warm, dp) / real(tmax - warm, dp)
      lr = lmin + 0.5_dp * (lmax - lmin) * (1.0_dp + cos(pi * prog))
    end if
  end function lr_at
end program lr_cizelge
