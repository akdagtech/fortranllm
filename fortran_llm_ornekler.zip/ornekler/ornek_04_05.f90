! Örnek 4.5: Multi-head attention modülü
! Derleme: gfortran -O2  ornek_04_05.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module attn_mod
  use prec_mod
  implicit none
contains
  subroutine softmax_rows(S)               ! her satiri ayri softmax'la
    real(dp), intent(inout) :: S(:,:)
    integer :: i
    do i = 1, size(S,1)
      S(i,:) = exp(S(i,:) - maxval(S(i,:)))
      S(i,:) = S(i,:) / sum(S(i,:))
    end do
  end subroutine softmax_rows

  subroutine causal_attention(Q, K, V, A, O)
    real(dp), intent(in)  :: Q(:,:), K(:,:), V(:,:)    ! (T,dk), (T,dk), (T,dv)
    real(dp), intent(out) :: A(:,:), O(:,:)            ! (T,T), (T,dv)
    integer :: T, i, j
    T = size(Q,1)
    A = matmul(Q, transpose(K)) / sqrt(real(size(Q,2), dp))
    do i = 1, T
      do j = i+1, T
        A(i,j) = -1.0e30_dp                             ! gelecegi maskele
      end do
    end do
    call softmax_rows(A)
    O = matmul(A, V)
  end subroutine causal_attention
end module attn_mod

module mha_mod
  use attn_mod
  implicit none
contains
  subroutine mha(X, Wq, Wk, Wv, Wo, nh, Y)
    real(dp), intent(in)  :: X(:,:), Wq(:,:), Wk(:,:), Wv(:,:), Wo(:,:)
    integer, intent(in)   :: nh
    real(dp), intent(out) :: Y(:,:)
    integer :: T, d, dh, h, c1, c2
    real(dp), allocatable :: Q(:,:), K(:,:), V(:,:), A(:,:), Oh(:,:), O(:,:)
    T = size(X,1); d = size(X,2); dh = d / nh
    allocate(Q(T,d), K(T,d), V(T,d), A(T,T), Oh(T,dh), O(T,d))
    Q = matmul(X, Wq); K = matmul(X, Wk); V = matmul(X, Wv)
    do h = 1, nh                                   ! her head icin sutun dilimi
      c1 = (h-1)*dh + 1; c2 = h*dh
      call causal_attention(Q(:,c1:c2), K(:,c1:c2), V(:,c1:c2), A, Oh)
      O(:,c1:c2) = Oh                              ! head ciktilarini yan yana koy
    end do
    Y = matmul(O, Wo)
  end subroutine mha
end module mha_mod

program mha_test
  use rng_mod
  use mha_mod
  implicit none
  integer, parameter :: T = 5, d = 8, nh = 2
  real(dp) :: X(T,d), X2(T,d), Wq(d,d), Wk(d,d), Wv(d,d), Wo(d,d), Y1(T,d), Y2(T,d)
  call rng_seed(8)
  call randn2(X, 1.0_dp)
  call randn2(Wq, 0.4_dp); call randn2(Wk, 0.4_dp)
  call randn2(Wv, 0.4_dp); call randn2(Wo, 0.4_dp)
  call mha(X, Wq, Wk, Wv, Wo, nh, Y1)
  X2 = X; X2(T,:) = 0.0_dp
  call mha(X2, Wq, Wk, Wv, Wo, nh, Y2)
  print '(A,I0,A,I0)', 'cikti boyutu: ', size(Y1,1), ' x ', size(Y1,2)
  print '(A,I0)', 'parametre sayisi 4*d^2 = ', 4*d*d
  print '(A,ES10.2)', 'onceki satirlarin degisimi = ', maxval(abs(Y1(1:T-1,:) - Y2(1:T-1,:)))
end program mha_test
