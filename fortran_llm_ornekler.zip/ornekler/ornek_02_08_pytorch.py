# Örnek 2.8: Başlatma ölçeği: 20 katman boyunca sinyal (PyTorch karşılığı)
import torch, math
torch.manual_seed(3)
n, nl = 64, 20
show = [1, 2, 5, 10, 20]
def rms(act, std):
    x = torch.randn(n); out = []
    for l in range(1, nl + 1):
        x = act(x @ (torch.randn(n, n) * std))
        if l in show: out.append(x.pow(2).mean().sqrt().item())
    return out
tanh_r = [rms(torch.tanh, s) for s in [0.02, 1 / math.sqrt(n), 0.5]]
print("TANH  katman   std=0.02   std=1/sqrt(n)   std=0.5")
for j, l in enumerate(show):
    print(f"{l:11d}" + "".join(f"{tanh_r[k][j]:14.3e}" for k in range(3)))
relu = torch.relu
rr = [rms(relu, 1 / math.sqrt(n)), rms(relu, math.sqrt(2 / n))]
print("RELU  katman   Xavier    He")
for j, l in enumerate(show):
    print(f"{l:11d}" + "".join(f"{rr[k][j]:14.3e}" for k in range(2)))
# hazir baslaticilar: nn.init.xavier_normal_, nn.init.kaiming_normal_
w = torch.empty(n, n); torch.nn.init.kaiming_normal_(w, nonlinearity='relu')
print("kaiming_normal_ std =", round(w.std().item(), 4), " (sqrt(2/n) =", round(math.sqrt(2 / n), 4), ")")

