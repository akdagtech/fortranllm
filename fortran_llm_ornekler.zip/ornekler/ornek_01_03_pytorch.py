# Örnek 1.3: Matris çarpımı: elle ve matmul ile (PyTorch karşılığı)
import torch
A = torch.tensor([[1., 2, 3], [4, 5, 6]], dtype=torch.float64)
B = torch.tensor([[7., 8], [9, 10], [11, 12]], dtype=torch.float64)
C = torch.zeros(2, 2, dtype=torch.float64)
for i in range(2):
    for j in range(2):
        for k in range(3):
            C[i, j] += A[i, k] * B[k, j]
D = A @ B                                  # matmul / torch.mm ile ayni
for i in range(2):
    print("C satiri:", " ".join(f"{v:8.1f}" for v in C[i]))
print("max |C - D| =", (C - D).abs().max().item())
print("einsum ile  :", torch.einsum('ik,kj->ij', A, B).tolist())

