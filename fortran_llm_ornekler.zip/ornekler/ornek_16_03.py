# Örnek 16.3: Fortran HF verisinden H₂ için ML potansiyeli
import torch, torch.nn as nn, numpy as np
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
torch.manual_seed(0); torch.set_default_dtype(torch.float64)
# ---- Fortran RHF/STO-3G programindan (Ornek 13.2) uretilen H2 enerjileri (R: Bohr, E: Hartree)
R_DATA = [
    0.7, 0.8, 0.9, 1.0, 1.1, 1.2, 1.3, 1.4, 1.5,
    1.6, 1.7, 1.8, 1.9, 2.0, 2.1, 2.2, 2.3, 2.4,
    2.5, 2.6, 2.7, 2.8, 2.9, 3.0, 3.1, 3.2, 3.3,
    3.4, 3.5, 3.6, 3.7, 3.8, 3.9, 4.0, 4.1, 4.2,
    4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 5.0, 5.1,
    5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 5.9, 6.0,
]
E_DATA = [
    -0.8371303, -0.94730793, -1.0194971, -1.0659995, -1.0945641, -1.1103339,
    -1.1168711, -1.1167143, -1.1116959, -1.103141, -1.0920059, -1.0789822,
    -1.0645769, -1.0491709, -1.0330609, -1.0164857, -0.99964323, -0.98269933,
    -0.96579368, -0.94904315, -0.93254452, -0.91637682, -0.90060359, -0.885275,
    -0.87042979, -0.85609692, -0.84229704, -0.82904365, -0.81634416, -0.80420065,
    -0.79261066, -0.78156784, -0.7710625, -0.76108225, -0.75161246, -0.74263681,
    -0.73413773, -0.72609682, -0.71849519, -0.7113138, -0.70453368, -0.69813612,
    -0.69210281, -0.68641592, -0.6810582, -0.67601293, -0.67126398, -0.66679577,
    -0.66259329, -0.65864203, -0.654928, -0.6514377, -0.64815813, -0.64507675,
]
R = torch.tensor(R_DATA)[:, None]; E = torch.tensor(E_DATA)[:, None]
perm = torch.randperm(len(R)); te, tr = perm[:10], perm[10:]               # 44 egitim, 10 test
net = nn.Sequential(nn.Linear(1, 32), nn.Tanh(), nn.Linear(32, 32), nn.Tanh(), nn.Linear(32, 1))
energy = lambda r: net(1.0 / r)                                            # girdi ozelligi 1/R
opt = torch.optim.Adam(net.parameters(), lr=5e-3)
for ep in range(1, 6001):
    loss = ((energy(R[tr]) - E[tr]) ** 2).mean()
    opt.zero_grad(); loss.backward(); opt.step()
    if ep in (1, 1000, 3000, 6000):
        print(f"epoch {ep:5d}  egitim MSE = {loss.item():.2e}   test max |hata| = {(energy(R[te]) - E[te]).abs().max().item():.4f} Eh")
r = torch.tensor([[2.0]], requires_grad=True)                              # geometri optimizasyonu: R <- R - lr dE/dR
for it in range(80):
    g, = torch.autograd.grad(energy(r).sum(), r)
    r = (r - 0.8 * g).detach().requires_grad_(True)
g, = torch.autograd.grad(energy(r).sum(), r, create_graph=True); k, = torch.autograd.grad(g.sum(), r)
mu = 1836.152673 / 2
print(f"ML potansiyeli:  R_denge = {r.item():.4f} Bohr   k = {k.item():.4f} Eh/Bohr^2   omega = {np.sqrt(k.item() / mu) * 219474.63:.0f} cm^-1")
print("Fortran RHF   :  R_denge = 1.3459 Bohr   k = 0.5729 Eh/Bohr^2   omega = 5483 cm^-1   (Ornek 13.4)")
rr = torch.linspace(0.7, 6.0, 200)[:, None].requires_grad_(True)
e = energy(rr); f, = torch.autograd.grad(e.sum(), rr)
fig, ax = plt.subplots(1, 2, figsize=(7.4, 3.0))
ax[0].plot(R, E, "o", ms=3, c="#e76f51", label="Fortran RHF (egitim+test)"); ax[0].plot(rr.detach(), e.detach(), c="#1d3557", label="sinir agi E(R)")
ax[0].set_xlabel("R (Bohr)"); ax[0].set_ylabel("E (Eh)"); ax[0].legend(); ax[0].set_title("ML potansiyeli: enerji")
ax[1].plot(rr.detach(), -f.detach(), c="#1d3557"); ax[1].axhline(0, c="k", lw=0.6); ax[1].set_xlabel("R (Bohr)"); ax[1].set_ylabel("F = -dE/dR (Eh/Bohr)")
ax[1].set_title("Kuvvet (autograd)"); plt.tight_layout(); plt.savefig("f_h2_ml.png", dpi=170)
