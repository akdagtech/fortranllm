# Örnek 11.1: Model 1: Nöral bigram dil modeli (PyTorch karşılığı)
import torch, torch.nn as nn, torch.nn.functional as F
corpus = ('bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken '
          'pireler berber iken ben annemin besigini tangir tungur sallar iken. '
          'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. '
          'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. '
          'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. '
          'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. '
          'yolcular gelir su icer dinlenir sonra yoluna devam edermis. ')
chars = sorted(set(corpus)); V = len(chars); ix = {c: i for i, c in enumerate(chars)}
ids = torch.tensor([ix[c] for c in corpus]); NCH = len(ids); ntrain = int(0.85 * NCH)
decode = lambda a: ''.join(chars[i] for i in a)

torch.manual_seed(5)
W = nn.Parameter(torch.zeros(V, V))                      # logits tablosu: satir = onceki karakter
opt = torch.optim.Adam([W], lr=0.05)
xtr, ytr = ids[:ntrain - 1], ids[1:ntrain]
xva, yva = ids[ntrain:-1], ids[ntrain + 1:]
print(f"karakter={NCH}  sozluk V={V}  egitim={ntrain}"); print(f"ln V = {torch.log(torch.tensor(float(V))):.4f}")
for step in range(1, 301):
    loss = F.cross_entropy(W[xtr], ytr)
    opt.zero_grad(); loss.backward(); opt.step()
    if step == 1 or step % 100 == 0:
        with torch.no_grad(): vl = F.cross_entropy(W[xva], yva)
        print(f"adim {step:4d}  egitim={loss.item():8.4f}  dogrulama={vl.item():8.4f}")
cnt = torch.zeros(V, V); cnt.index_put_((xtr, ytr), torch.ones(len(xtr)), accumulate=True)
pc = cnt / cnt.sum(1, keepdim=True).clamp(min=1)
opt_loss = -(cnt * torch.where(cnt > 0, pc.log(), torch.zeros(1))).sum() / len(xtr)
print(f"sayim tabanli en iyi egitim kaybi = {opt_loss:.4f}")
cur, gen = ids[0].item(), [ids[0].item()]
for _ in range(99):
    cur = torch.multinomial(torch.softmax(W[cur].detach(), 0), 1).item(); gen.append(cur)
print("uretilen metin:"); print(decode(gen))

