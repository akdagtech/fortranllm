# Örnek 5.8: Aktivasyon yeniden hesaplama ile aynı gradyan (PyTorch karşılığı)
import torch, torch.nn as nn
from torch.utils.checkpoint import checkpoint_sequential
torch.set_default_dtype(torch.float64)
L, seg = 64, 8
class Layer(nn.Module):
    def __init__(self, w):
        super().__init__(); self.w = nn.Parameter(torch.tensor(w))
    def forward(self, y): return torch.tanh(self.w * y)
ws = [0.9 + 0.2 * torch.sin(torch.tensor(float(k))).item() for k in range(1, L + 1)]
net = nn.Sequential(*[Layer(w) for w in ws])
y0 = torch.tensor(0.5)
net(y0).backward()                               # normal: tum aktivasyonlar saklanir
g1 = torch.stack([l.w.grad for l in net]).clone()
for p in net.parameters(): p.grad = None
out = checkpoint_sequential(net, seg, y0, use_reentrant=False)   # 8 parca, aktivasyonlar yeniden hesaplanir
out.backward()
g2 = torch.stack([l.w.grad for l in net])
print("max |dw1 - dw2|            =", (g1 - g2).abs().max().item())
print("normal : saklanan aktivasyon =", L + 1)
print("ckpt   : saklanan (en fazla) =", L // seg + 1 + seg + 1)

