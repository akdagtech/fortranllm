! Örnek 9.4: Veri paralelliğini simüle et: all-reduce = tam batch gradyanı
! Derleme: gfortran -O2  ornek_09_04.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program veri_paralel
  use rng_mod
  implicit none
  integer, parameter :: N = 32, W = 4, per = N / W
  real(dp) :: x(N), y(N), w1, b1, g_full(2), g_loc(2,W), g_avg(2)
  integer :: k, i0, i1
  call rng_seed(3)
  do k = 1, N
    x(k) = gauss()
    y(k) = 3.0_dp * x(k) - 1.0_dp + 0.2_dp * gauss()
  end do
  w1 = 0.5_dp; b1 = 0.0_dp
  g_full(1) = sum(2.0_dp * (w1*x + b1 - y) * x) / N
  g_full(2) = sum(2.0_dp * (w1*x + b1 - y)) / N
  do k = 1, W                                       ! her isci kendi dilimi icin
    i0 = (k-1)*per + 1; i1 = k*per
    g_loc(1,k) = sum(2.0_dp * (w1*x(i0:i1) + b1 - y(i0:i1)) * x(i0:i1)) / per
    g_loc(2,k) = sum(2.0_dp * (w1*x(i0:i1) + b1 - y(i0:i1))) / per
    print '(A,I1,A,2F10.5)', 'isci ', k, ' yerel gradyan : ', g_loc(:,k)
  end do
  g_avg = sum(g_loc, dim=2) / W                     ! all-reduce (ortalama)
  print '(A,2F10.5)', 'all-reduce ortalama  : ', g_avg
  print '(A,2F10.5)', 'tek isci tam batch   : ', g_full
  print '(A,ES10.2)', 'fark = ', maxval(abs(g_avg - g_full))
end program veri_paralel
