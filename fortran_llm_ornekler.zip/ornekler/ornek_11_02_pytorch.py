# Örnek 11.2: Model 2: MLP dil modeli (elle geri yayılım + gradyan kontrolü) (PyTorch karşılığı)
import torch, torch.nn as nn, torch.nn.functional as F
corpus = ('bir varmis bir yokmus. evvel zaman icinde kalbur saman icinde develer tellal iken '
          'pireler berber iken ben annemin besigini tangir tungur sallar iken. '
          'cok gezdim cok gordum ama hic yorulmadim. yol uzundu ama yuregim sicakti. '
          'gece oldu yildizlar cikti ve herkes sessizce uykuya daldi. '
          'sabah olunca horozlar otti kuslar sarki soyledi ve yeni bir gun basladi. '
          'dag basinda bir cesme varmis suyu soguk mu soguk tatli mi tatli. '
          'yolcular gelir su icer dinlenir sonra yoluna devam edermis. ')
chars = sorted(set(corpus)); V = len(chars); ix = {c: i for i, c in enumerate(chars)}
ids = torch.tensor([ix[c] for c in corpus]); NCH = len(ids); ntrain = int(0.85 * NCH)
decode = lambda a: ''.join(chars[i] for i in a)

torch.manual_seed(11)
NC, ED, NH = 3, 8, 48
class MLPLM(nn.Module):
    def __init__(s):
        super().__init__()
        s.E = nn.Embedding(V, ED); s.l1 = nn.Linear(NC * ED, NH); s.l2 = nn.Linear(NH, V)
        for p in s.parameters(): nn.init.normal_(p, std=0.3)
        nn.init.zeros_(s.l1.bias); nn.init.zeros_(s.l2.bias)
    def forward(s, ctx):                                     # ctx: (B, NC)
        return s.l2(torch.tanh(s.l1(s.E(ctx).flatten(1))))
m = MLPLM(); opt = torch.optim.Adam(m.parameters(), lr=0.01)
pos = lambda lo, hi: torch.arange(lo, hi + 1)
ctx_of = lambda tp: torch.stack([ids[tp - NC + 1 + j] for j in range(NC)], 1)
def ev(lo, hi):
    tp = pos(lo, hi)
    with torch.no_grad(): return F.cross_entropy(m(ctx_of(tp)), ids[tp + 1]).item()
print("parametre sayisi =", sum(p.numel() for p in m.parameters()))
for step in range(1, 3001):
    tp = NC - 1 + torch.randint(0, ntrain - NC - 1, (64,))         # 0 tabanli konumlar
    loss = F.cross_entropy(m(ctx_of(tp)), ids[tp + 1])
    opt.zero_grad(); loss.backward(); opt.step()
    if step == 1 or step % 500 == 0:
        print(f"adim {step:5d}  egitim={ev(NC - 1, ntrain - 2):8.4f}  dogrulama={ev(ntrain + NC - 1, NCH - 2):8.4f}")
gen = ids[:NC].tolist()
for _ in range(150 - NC):
    with torch.no_grad(): p = torch.softmax(m(torch.tensor([gen[-NC:]]))[0] / 0.8, 0)
    gen.append(torch.multinomial(p, 1).item())
print("uretilen metin:"); print(decode(gen))

