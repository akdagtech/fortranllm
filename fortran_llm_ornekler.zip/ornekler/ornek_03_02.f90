! Örnek 3.2: Momentum'un etkin adımı
! Derleme: gfortran -O2  ornek_03_02.f90 -o ornek
program momentum_hiz
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: v, beta, g
  integer :: k
  beta = 0.9_dp; g = 1.0_dp; v = 0.0_dp
  do k = 1, 30
    v = beta * v + g
    if (k <= 5 .or. mod(k, 5) == 0) print '(A,I3,A,F9.5)', 'adim ', k, '   v = ', v
  end do
  print '(A,F9.5)', 'teorik sinir g/(1-beta) = ', g / (1.0_dp - beta)
end program momentum_hiz
