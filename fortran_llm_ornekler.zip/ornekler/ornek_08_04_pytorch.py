# Örnek 8.4: Global norm ile gradyan kırpma (PyTorch karşılığı)
import torch
p1 = torch.nn.Parameter(torch.zeros(2)); p2 = torch.nn.Parameter(torch.zeros(2))
p1.grad = torch.tensor([3.0, 4.0]); p2.grad = torch.tensor([0.0, 12.0])
norm = torch.nn.utils.clip_grad_norm_([p1, p2], max_norm=1.0)       # global norm kirpma
print(f"global norm (once) = {norm:8.4f}")
print("g1, g2 (sonra)     =", [round(v, 5) for v in p1.grad.tolist()], [round(v, 5) for v in p2.grad.tolist()])
print(f"global norm (sonra)= {torch.sqrt(p1.grad.pow(2).sum() + p2.grad.pow(2).sum()):8.4f}")
q1 = torch.nn.Parameter(torch.zeros(2)); q2 = torch.nn.Parameter(torch.zeros(2))
q1.grad = torch.tensor([0.3, 0.4]); q2.grad = torch.tensor([0.0, 0.2])
n2 = torch.nn.utils.clip_grad_norm_([q1, q2], max_norm=1.0)
print(f"kucuk gradyan: norm = {n2:8.4f}   (degismez: {q1.grad.tolist()})")

