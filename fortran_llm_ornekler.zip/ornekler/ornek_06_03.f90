! Örnek 6.3: Türkçeye uygun küçük harf dönüşümü
! Derleme: gfortran -O2  ornek_06_03.f90 -o ornek
program normalizasyon
  implicit none
  character(len=:), allocatable :: s, naif, tr
  integer :: i, c
  s = 'ISTANBUL  İzmir   ÇAY  Şeker'
  naif = s
  do i = 1, len(naif)                               ! yalniz ASCII A-Z -> a-z
    c = ichar(naif(i:i))
    if (c >= 65 .and. c <= 90) naif(i:i) = char(c + 32)
  end do
  tr = tr_lower(s)
  do while (index(tr, '  ') > 0)                    ! bosluklari tekle
    tr = replace_all(tr, '  ', ' ')
  end do
  print '(A,A)', 'girdi          : ', s
  print '(A,A)', 'naif (ASCII)   : ', naif
  print '(A,A)', 'Turkce kurali  : ', tr
contains
  function tr_lower(x) result(r)
    character(len=*), intent(in) :: x
    character(len=:), allocatable :: r
    integer :: i, c
    r = replace_all(x, 'İ', 'i')
    r = replace_all(r, 'I', 'ı')
    r = replace_all(r, 'Ç', 'ç')
    r = replace_all(r, 'Ğ', 'ğ')
    r = replace_all(r, 'Ö', 'ö')
    r = replace_all(r, 'Ş', 'ş')
    r = replace_all(r, 'Ü', 'ü')
    do i = 1, len(r)                                 ! kalan ASCII buyuk harfler
      c = ichar(r(i:i))
      if (c >= 65 .and. c <= 90) r(i:i) = char(c + 32)
    end do
  end function tr_lower

  function replace_all(x, a, b) result(r)
    character(len=*), intent(in) :: x, a, b
    character(len=:), allocatable :: r
    integer :: p, i
    r = ''
    i = 1
    do
      p = index(x(i:), a)
      if (p == 0) then
        r = r // x(i:)
        exit
      end if
      r = r // x(i:i+p-2) // b
      i = i + p - 1 + len(a)
    end do
  end function replace_all
end program normalizasyon
