! Örnek 10.4: Dağılımdan örnekleme (ters CDF) ve doğrulama
! Derleme: gfortran -O2  ornek_10_04.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program ornekleme
  use rng_mod
  implicit none
  integer, parameter :: V = 4, ns = 20000
  real(dp) :: p(V), cdf(V), u
  integer :: cnt(V), i, k
  p = [0.5_dp, 0.3_dp, 0.15_dp, 0.05_dp]
  cdf(1) = p(1)
  do k = 2, V
    cdf(k) = cdf(k-1) + p(k)                        ! kumulatif dagilim
  end do
  call rng_seed(77)
  cnt = 0
  do i = 1, ns
    u = uniform()
    do k = 1, V
      if (u <= cdf(k)) exit                         ! u'yu asan ilk token
    end do
    k = min(k, V)
    cnt(k) = cnt(k) + 1
  end do
  print '(A,4F8.4)', 'gercek p    : ', p
  print '(A,4F8.4)', 'deneysel    : ', real(cnt, dp) / ns
end program ornekleme
