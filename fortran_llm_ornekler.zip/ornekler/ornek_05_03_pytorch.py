# Örnek 5.3: Bloklu (tiled) matris çarpımı (PyTorch karşılığı)
import torch, time
torch.set_num_threads(1)
n, bs = 1024, 256
A = torch.rand(n, n, dtype=torch.float64); B = torch.rand(n, n, dtype=torch.float64)
t0 = time.perf_counter(); C1 = A @ B; t1 = time.perf_counter() - t0
C2 = torch.zeros(n, n, dtype=torch.float64)
t0 = time.perf_counter()
for i in range(0, n, bs):                        # bloklar halinde carpim (tiling)
    for j in range(0, n, bs):
        for k in range(0, n, bs):
            C2[i:i+bs, j:j+bs] += A[i:i+bs, k:k+bs] @ B[k:k+bs, j:j+bs]
t2 = time.perf_counter() - t0
fl = 2.0 * n ** 3
print(f"tek parca  : {t1:7.3f} s  {fl / t1 / 1e9:7.2f} GFLOP/s")
print(f"bloklu     : {t2:7.3f} s  {fl / t2 / 1e9:7.2f} GFLOP/s")
print("max fark   =", (C1 - C2).abs().max().item())

