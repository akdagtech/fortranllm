! Örnek 13.1: Hückel teorisi: benzen, butadien ve diğerleri
! Derleme: gfortran -O2  ornek_13_01.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module eig_mod
  use prec_mod
  implicit none
contains
  subroutine jacobi_eig(A0, w, Vv)               ! simetrik matris: A = V diag(w) V^T, ozdegerler artan sirada
    real(dp), intent(in)  :: A0(:,:)
    real(dp), intent(out) :: w(:), Vv(:,:)
    real(dp), allocatable :: A(:,:)
    integer :: n, i, j, k, sweep
    real(dp) :: off, c, s, t, aij, tau, tmp
    n = size(A0,1)
    allocate(A(n,n)); A = A0
    Vv = 0.0_dp
    do i = 1, n
      Vv(i,i) = 1.0_dp
    end do
    do sweep = 1, 60
      off = 0.0_dp
      do j = 2, n
        do i = 1, j-1
          off = off + A(i,j)**2
        end do
      end do
      if (off < 1.0e-22_dp) exit
      do j = 2, n
        do i = 1, j-1
          aij = A(i,j)
          if (abs(aij) < 1.0e-300_dp) cycle
          tau = (A(j,j) - A(i,i)) / (2.0_dp*aij)
          t = sign(1.0_dp, tau) / (abs(tau) + sqrt(1.0_dp + tau*tau))
          c = 1.0_dp / sqrt(1.0_dp + t*t); s = t*c
          do k = 1, n                              ! A <- A J
            tmp = A(k,i); A(k,i) = c*tmp - s*A(k,j); A(k,j) = s*tmp + c*A(k,j)
          end do
          do k = 1, n                              ! A <- J^T A
            tmp = A(i,k); A(i,k) = c*tmp - s*A(j,k); A(j,k) = s*tmp + c*A(j,k)
          end do
          do k = 1, n                              ! ozvektorleri biriktir
            tmp = Vv(k,i); Vv(k,i) = c*tmp - s*Vv(k,j); Vv(k,j) = s*tmp + c*Vv(k,j)
          end do
        end do
      end do
    end do
    do i = 1, n
      w(i) = A(i,i)
    end do
    do i = 1, n-1                                  ! artan sirala
      k = minloc(w(i:n), dim=1) + i - 1
      if (k /= i) then
        tmp = w(i); w(i) = w(k); w(k) = tmp
        do j = 1, n
          tmp = Vv(j,i); Vv(j,i) = Vv(j,k); Vv(j,k) = tmp
        end do
      end if
    end do
  end subroutine jacobi_eig
end module eig_mod

program huckel
  use eig_mod
  implicit none
  integer :: e_allil(2,2), e_but(2,3), e_benz(2,6), e_cb(2,4), e_hex(2,5)
  e_allil = reshape([1,2, 2,3], [2,2])
  e_but   = reshape([1,2, 2,3, 3,4], [2,3])
  e_benz  = reshape([1,2, 2,3, 3,4, 4,5, 5,6, 6,1], [2,6])
  e_cb    = reshape([1,2, 2,3, 3,4, 4,1], [2,4])
  e_hex   = reshape([1,2, 2,3, 3,4, 4,5, 5,6], [2,5])
  call molekul('allil katyonu (2 e) ', 3, e_allil, 2)
  call molekul('butadien      (4 e) ', 4, e_but, 4)
  call molekul('benzen        (6 e) ', 6, e_benz, 6)
  call molekul('siklobutadien (4 e) ', 4, e_cb, 4)
  call molekul('heksatrien    (6 e) ', 6, e_hex, 6)
contains
  subroutine molekul(ad, n, edges, ne)
    character(len=*), intent(in) :: ad
    integer, intent(in) :: n, edges(:,:), ne
    real(dp) :: A(n,n), w(n), Vv(n,n), x(n), occ(n), esum
    integer :: k
    A = 0.0_dp
    do k = 1, size(edges, 2)                         ! komsuluk matrisi A (molekul grafi!)
      A(edges(1,k), edges(2,k)) = 1.0_dp
      A(edges(2,k), edges(1,k)) = 1.0_dp
    end do
    call jacobi_eig(A, w, Vv)                        ! E = alpha + x*beta, x = A'nin ozdegerleri
    do k = 1, n
      x(k) = w(n+1-k)                                ! beta < 0: buyuk x = daha kararli orbital
      occ(k) = min(2.0_dp, max(0.0_dp, real(ne - 2*(k-1), dp)))
    end do
    esum = sum(occ * x)
    write(*,'(A,A,6F8.3)') ad, ' x = ', x
    write(*,'(A,F8.4,A,F8.4,A)') '   E_pi = n*alpha + (', esum, ') beta,  delokalizasyon = ', esum - ne, ' beta'
    if (n == 4 .and. size(edges,2) == 3) then        ! butadien: pi-bag mertebeleri
      do k = 1, 3
        write(*,'(A,I1,A,I1,A,F7.4)') '   pi-bag mertebesi C', edges(1,k), '-C', edges(2,k), ' = ', &
              bond_order(Vv, n, edges(1,k), edges(2,k), ne)
      end do
    end if
  end subroutine molekul

  function bond_order(Vv, n, i, j, ne) result(p)     ! p_ij = sum_k n_k c_ik c_jk
    real(dp), intent(in) :: Vv(:,:)
    integer, intent(in) :: n, i, j, ne
    real(dp) :: p
    integer :: k
    p = 0.0_dp
    do k = 1, n
      p = p + min(2.0_dp, max(0.0_dp, real(ne - 2*(k-1), dp))) * Vv(i,n+1-k) * Vv(j,n+1-k)
    end do
  end function bond_order
end program huckel
