! Örnek 8.7: Eğitim bütçesi hesaplayıcısı
! Derleme: gfortran -O2  ornek_08_07.f90 -o ornek
program butce
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: tok_adim, params, tok_gerek, adim, veri, epoch
  tok_adim = 32.0_dp * 1024.0_dp * 4.0_dp
  params   = 124.0e6_dp
  tok_gerek = 20.0_dp * params
  adim  = tok_gerek / tok_adim
  veri  = 10.0e9_dp
  epoch = tok_gerek / veri
  print '(A,F12.0)', 'token / adim                  = ', tok_adim
  print '(A,F12.3,A)', 'gereken token (20 x param)    = ', tok_gerek / 1.0e9_dp, ' milyar'
  print '(A,F12.0)', 'optimizer adim sayisi         = ', adim
  print '(A,F12.3)', 'epoch (10 milyar tokenlik veri) = ', epoch
  print '(A,F12.0)', '10 milyar token icin adim     = ', veri / tok_adim
end program butce
