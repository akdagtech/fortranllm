# Örnek 5.4: OpenMP ile paralel matris çarpımı (PyTorch karşılığı)
import torch, time, os
n = 700
A = torch.rand(n, n, dtype=torch.float64); B = torch.rand(n, n, dtype=torch.float64)
print("kullanilabilir isleme birimi sayisi:", os.cpu_count())
ref = A @ B
for nt in [1, 2, 4]:
    torch.set_num_threads(nt)                    # OpenMP'deki omp_set_num_threads karsiligi
    t0 = time.perf_counter(); C = A @ B; t = time.perf_counter() - t0
    print(f"is parcacigi={nt:2d} sure={t:8.3f} s fark={(C - ref).abs().max().item():.2e}")

