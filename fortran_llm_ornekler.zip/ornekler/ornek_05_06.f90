! Örnek 5.6: Toplama hassasiyeti ve BF16 yuvarlama
! Derleme: gfortran -O2  ornek_05_06.f90 -o ornek
program karisik_hassasiyet
  implicit none
  real(4) :: s32, x, y, xb, sbf
  real(8) :: s64
  integer :: i
  s32 = 0.0; s64 = 0.0d0
  do i = 1, 10000000
    s32 = s32 + 1.0e-4
    s64 = s64 + 1.0d-4
  end do
  print '(A,F12.4)', '(a) FP32 toplam : ', s32
  print '(A,F12.4)', '    FP64 toplam : ', s64
  x = 3.14159265
  y = to_bf16(x)
  print '(A,F10.7,A,F10.7,A,ES9.2)', '(b) pi FP32=', x, '  BF16=', y, '  bagil hata=', abs(y-x)/x
  print '(A,ES10.3,A,ES10.3)', '    epsilon FP32=', epsilon(1.0), '   BF16=', 2.0**(-7)
  xb = to_bf16(0.01); sbf = 0.0; s32 = 0.0
  do i = 1, 1000
    sbf = to_bf16(sbf + xb)             ! akumulator da BF16 (kotu)
    s32 = s32 + xb                      ! akumulator FP32 (iyi)
  end do
  print '(A,F9.4)', '(c) BF16 akumulator : ', sbf
  print '(A,F9.4)', '    FP32 akumulator : ', s32
contains
  function to_bf16(x) result(y)         ! alt 16 biti en yakina yuvarla
    real(4), intent(in) :: x
    real(4) :: y
    integer(4) :: ib
    ib = transfer(x, ib)
    ib = ib + 32767 + iand(ishft(ib, -16), 1)
    ib = iand(ib, not(65535_4))
    y = transfer(ib, y)
  end function to_bf16
end program karisik_hassasiyet
