! Örnek 13.3: H₂ potansiyel enerji eğrisi
! Derleme: gfortran -O2  ornek_13_03.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module eig_mod
  use prec_mod
  implicit none
contains
  subroutine jacobi_eig(A0, w, Vv)               ! simetrik matris: A = V diag(w) V^T, ozdegerler artan sirada
    real(dp), intent(in)  :: A0(:,:)
    real(dp), intent(out) :: w(:), Vv(:,:)
    real(dp), allocatable :: A(:,:)
    integer :: n, i, j, k, sweep
    real(dp) :: off, c, s, t, aij, tau, tmp
    n = size(A0,1)
    allocate(A(n,n)); A = A0
    Vv = 0.0_dp
    do i = 1, n
      Vv(i,i) = 1.0_dp
    end do
    do sweep = 1, 60
      off = 0.0_dp
      do j = 2, n
        do i = 1, j-1
          off = off + A(i,j)**2
        end do
      end do
      if (off < 1.0e-22_dp) exit
      do j = 2, n
        do i = 1, j-1
          aij = A(i,j)
          if (abs(aij) < 1.0e-300_dp) cycle
          tau = (A(j,j) - A(i,i)) / (2.0_dp*aij)
          t = sign(1.0_dp, tau) / (abs(tau) + sqrt(1.0_dp + tau*tau))
          c = 1.0_dp / sqrt(1.0_dp + t*t); s = t*c
          do k = 1, n                              ! A <- A J
            tmp = A(k,i); A(k,i) = c*tmp - s*A(k,j); A(k,j) = s*tmp + c*A(k,j)
          end do
          do k = 1, n                              ! A <- J^T A
            tmp = A(i,k); A(i,k) = c*tmp - s*A(j,k); A(j,k) = s*tmp + c*A(j,k)
          end do
          do k = 1, n                              ! ozvektorleri biriktir
            tmp = Vv(k,i); Vv(k,i) = c*tmp - s*Vv(k,j); Vv(k,j) = s*tmp + c*Vv(k,j)
          end do
        end do
      end do
    end do
    do i = 1, n
      w(i) = A(i,i)
    end do
    do i = 1, n-1                                  ! artan sirala
      k = minloc(w(i:n), dim=1) + i - 1
      if (k /= i) then
        tmp = w(i); w(i) = w(k); w(k) = tmp
        do j = 1, n
          tmp = Vv(j,i); Vv(j,i) = Vv(j,k); Vv(j,k) = tmp
        end do
      end if
    end do
  end subroutine jacobi_eig
end module eig_mod

module hf_mod
  use eig_mod
  implicit none
  integer, parameter :: ng = 3                    ! STO-3G: 3 ilkel gauss
  real(dp), parameter :: pi = 3.141592653589793_dp
  real(dp), parameter :: coef(3) = [0.15432897_dp, 0.53532814_dp, 0.44463454_dp]
  real(dp), parameter :: alpha_H(3)  = [3.42525091_dp, 0.62391373_dp, 0.16885540_dp]
  real(dp), parameter :: alpha_He(3) = [6.36242139_dp, 1.15892300_dp, 0.31364979_dp]
contains
  function boys0(t) result(f)                    ! F0(t) = int_0^1 exp(-t u^2) du
    real(dp), intent(in) :: t
    real(dp) :: f
    if (t < 1.0e-8_dp) then
      f = 1.0_dp - t/3.0_dp
    else
      f = 0.5_dp * sqrt(pi/t) * erf(sqrt(t))
    end if
  end function boys0

  function d2(a, b) result(r)
    real(dp), intent(in) :: a(3), b(3)
    real(dp) :: r
    r = sum((a-b)**2)
  end function d2

  subroutine scf_energy(nat, Z, R, etot, verbose, niter)
    integer, intent(in)  :: nat
    real(dp), intent(in) :: Z(nat), R(3,nat)
    real(dp), intent(out) :: etot
    logical, intent(in) :: verbose
    integer, intent(out), optional :: niter
    real(dp) :: al(3,nat), nrm(3,nat)
    real(dp), allocatable :: S(:,:), T(:,:), Vn(:,:), Hc(:,:), G(:,:), F(:,:), Fp(:,:)
    real(dp), allocatable :: X(:,:), C(:,:), P(:,:), eri(:,:,:,:)
    real(dp), allocatable :: s_w(:), s_V(:,:), e(:), V2(:,:)
    real(dp) :: ee, eold, enuc
    integer :: i, j, k, l, a, b, c_, d_, it, nocc, nbf
    nbf = nat
    do i = 1, nat
      if (Z(i) < 1.5_dp) then
        al(:,i) = alpha_H
      else
        al(:,i) = alpha_He
      end if
      nrm(:,i) = (2.0_dp*al(:,i)/pi)**0.75_dp * coef
    end do
    allocate(S(nbf,nbf), T(nbf,nbf), Vn(nbf,nbf), Hc(nbf,nbf), G(nbf,nbf), F(nbf,nbf))
    allocate(Fp(nbf,nbf), X(nbf,nbf))
    allocate(C(nbf,nbf), P(nbf,nbf), eri(nbf,nbf,nbf,nbf))
    allocate(s_w(nbf), s_V(nbf,nbf), e(nbf), V2(nbf,nbf))
    S = 0; T = 0; Vn = 0
    do i = 1, nbf
      do j = 1, nbf
        do a = 1, ng
          do b = 1, ng
            call prim1(al(a,i), al(b,j), R(:,i), R(:,j), nrm(a,i)*nrm(b,j), S(i,j), T(i,j), Vn(i,j))
          end do
        end do
      end do
    end do
    do i = 1, nbf
      do j = 1, nbf
        do a = 1, ng
          do b = 1, ng
            do k = 1, nat
              Vn(i,j) = Vn(i,j) + nrm(a,i)*nrm(b,j) * &
                        nuc(al(a,i), al(b,j), R(:,i), R(:,j), R(:,k), Z(k))
            end do
          end do
        end do
      end do
    end do
    Hc = T + Vn
    eri = 0
    do i = 1, nbf; do j = 1, nbf; do k = 1, nbf; do l = 1, nbf
      do a = 1, ng; do b = 1, ng; do c_ = 1, ng; do d_ = 1, ng
        eri(i,j,k,l) = eri(i,j,k,l) + nrm(a,i)*nrm(b,j)*nrm(c_,k)*nrm(d_,l) * &
             g4(al(a,i), al(b,j), al(c_,k), al(d_,l), R(:,i), R(:,j), R(:,k), R(:,l))
      end do; end do; end do; end do
    end do; end do; end do; end do
    enuc = 0
    do i = 1, nat-1
      do j = i+1, nat
        enuc = enuc + Z(i)*Z(j)/sqrt(d2(R(:,i), R(:,j)))
      end do
    end do
    call jacobi_eig(S, s_w, s_V)                   ! X = S^(-1/2) (Lowdin)
    X = 0
    do i = 1, nbf
      do j = 1, nbf
        do k = 1, nbf
          X(i,j) = X(i,j) + s_V(i,k) * s_V(j,k) / sqrt(s_w(k))
        end do
      end do
    end do
    nocc = nint(sum(Z)) / 2
    P = 0; eold = 0.0_dp
    do it = 1, 100
      G = 0
      do i = 1, nbf; do j = 1, nbf
        do k = 1, nbf; do l = 1, nbf
          G(i,j) = G(i,j) + P(k,l) * (eri(i,j,l,k) - 0.5_dp*eri(i,k,l,j))
        end do; end do
      end do; end do
      F = Hc + G
      Fp = matmul(transpose(X), matmul(F, X))
      call jacobi_eig(Fp, e, V2)
      C = matmul(X, V2)
      P = 0
      do i = 1, nbf; do j = 1, nbf
        do k = 1, nocc
          P(i,j) = P(i,j) + 2.0_dp * C(i,k) * C(j,k)
        end do
      end do; end do
      ee = 0.5_dp * sum(P * (Hc + F))
      if (verbose) print '(A,I3,A,F16.10,A,F16.10)', 'SCF ', it, '  E_elek=', ee, &
                                                     '  E_toplam=', ee + enuc
      if (abs(ee - eold) < 1.0e-11_dp) exit
      eold = ee
    end do
    etot = ee + enuc
    if (present(niter)) niter = it
    if (verbose) then
      print '(A,4F12.6)', 'orbital enerjileri (Eh):', e(1:min(4,nbf))
      print '(A,2F10.6)', 'C(:,1) = ', C(1:min(2,nbf),1)
    end if
  end subroutine scf_energy

  subroutine prim1(a, b, A_, B_, nn, S, T, V)
    real(dp), intent(in) :: a, b, A_(3), B_(3), nn
    real(dp), intent(inout) :: S, T, V
    real(dp) :: p, mu, rab2, sab
    p = a + b; mu = a*b/p; rab2 = d2(A_, B_)
    sab = (pi/p)**1.5_dp * exp(-mu*rab2)
    S = S + nn * sab
    T = T + nn * mu * (3.0_dp - 2.0_dp*mu*rab2) * sab
  end subroutine prim1

  function nuc(a, b, A_, B_, C_, Zc) result(v)
    real(dp), intent(in) :: a, b, A_(3), B_(3), C_(3), Zc
    real(dp) :: v, p, Pc(3)
    p = a + b; Pc = (a*A_ + b*B_)/p
    v = -Zc * 2.0_dp*pi/p * exp(-a*b/p*d2(A_,B_)) * boys0(p*d2(Pc, C_))
  end function nuc

  function g4(a, b, c, d, A_, B_, C_, D_) result(v)
    real(dp), intent(in) :: a, b, c, d, A_(3), B_(3), C_(3), D_(3)
    real(dp) :: v, p, q, Pp(3), Qq(3)
    p = a + b; q = c + d
    Pp = (a*A_ + b*B_)/p; Qq = (c*C_ + d*D_)/q
    v = 2.0_dp*pi**2.5_dp / (p*q*sqrt(p+q)) * exp(-a*b/p*d2(A_,B_) - c*d/q*d2(C_,D_)) &
        * boys0(p*q/(p+q)*d2(Pp,Qq))
  end function g4
end module hf_mod

program pes
  use hf_mod
  implicit none
  real(dp), parameter :: e_atom = -0.4665819_dp          ! H atomu, STO-3G (UHF)
  real(dp) :: Z(2), R(3,2), E, rr(14)
  integer :: i
  Z = [1.0_dp, 1.0_dp]
  rr = [0.6_dp, 0.8_dp, 1.0_dp, 1.2_dp, 1.4_dp, 1.6_dp, 1.8_dp, 2.0_dp, 2.5_dp, 3.0_dp, &
        4.0_dp, 5.0_dp, 6.0_dp, 8.0_dp]
  print '(A)', '  R (Bohr)    E (Eh)      E - 2E(H) (Eh)   (eV)'
  do i = 1, size(rr)
    R = 0.0_dp; R(3,2) = rr(i)
    call scf_energy(2, Z, R, E, .false.)
    print '(F9.2,F13.6,F14.6,F10.3)', rr(i), E, E - 2.0_dp*e_atom, (E - 2.0_dp*e_atom)*27.2114_dp
  end do
end program pes
