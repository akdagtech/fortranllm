! Örnek 6.2: UTF-8 çözücü: baytlardan kod noktalarına
! Derleme: gfortran -O2  ornek_06_02.f90 -o ornek
program utf8_coz
  implicit none
  character(len=:), allocatable :: s
  integer :: i, n, b, cp, nbytes, k
  s = 'İstanbul ığ ' // char(240) // char(159) // char(152) // char(128)
  n = len(s)
  i = 1
  do while (i <= n)
    b = ichar(s(i:i))
    if (b < 128) then
      cp = b;                                   nbytes = 1
    else if (b < 224) then
      cp = iand(b, 31);  nbytes = 2
    else if (b < 240) then
      cp = iand(b, 15);  nbytes = 3
    else
      cp = iand(b, 7);   nbytes = 4
    end if
    do k = 1, nbytes - 1                        ! devam baytlari: alt 6 biti ekle
      cp = cp * 64 + iand(ichar(s(i+k:i+k)), 63)
    end do
    write(*,'(A,Z6.6,A,I1,A)') 'U+', cp, '  (', nbytes, ' bayt)'
    i = i + nbytes
  end do
end program utf8_coz
