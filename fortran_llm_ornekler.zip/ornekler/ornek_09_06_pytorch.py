# Örnek 9.6: Boru hattı çizelgesi ve kabarcık oranı (PyTorch karşılığı)
p, m = 4, 6
print("zaman ->  (sayi = mikro-batch numarasi, . = bosta)")
for s in range(1, p + 1):
    row = ""
    for t in range(m + p - 1):
        mb = t - (s - 1) + 1
        row += f"{mb:3d}" if 1 <= mb <= m else "  ."
    print(f"stage {s} | {row}")
print(f"kabarcik orani (p=4, m=6) = {(p - 1) / (m + p - 1):.3f}")
print("p = 4 icin:  m     kabarcik orani")
for mm in [1, 4, 8, 16, 32]:
    print(f"{mm:14d}{(p - 1) / (mm + p - 1):15.3f}")

