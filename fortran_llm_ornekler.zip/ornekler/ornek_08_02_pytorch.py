# Örnek 8.2: Mini-batch gradyanının gürültüsü ~ 1/√B (PyTorch karşılığı)
import torch
torch.manual_seed(17)
N, ntr = 10000, 2000
x = torch.randn(N, dtype=torch.float64); y = 2 * x + 0.5 * torch.randn(N, dtype=torch.float64)
gi = 2 * (0 * x - y) * x                              # w = 0 iken ornek basina gradyan
print(f"tam veri gradyani = {gi.mean():9.4f}")
print("    B     ortalama     std      std*sqrt(B)")
for B in [1, 4, 16, 64]:
    idx = torch.randint(0, N, (ntr, B))               # ntr kez, B rastgele ornek
    gm = gi[idx].mean(1)                              # mini-batch gradyanlari
    print(f"{B:5d}{gm.mean():11.4f}{gm.std():11.4f}{gm.std() * B ** 0.5:11.4f}")

