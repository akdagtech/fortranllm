! Örnek 2.5: Softmax + çapraz entropi gradyanı ve sayısal kararlılık
! Derleme: gfortran -O2  ornek_02_05.f90 -o ornek
program smax
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: z(3), p(3), g(3), onehot(3), zz(3), pp(3), lp, lm, gn(3), h
  real(dp) :: big(3), naive(3), stable(3)
  integer :: k, i
  z = [2.0_dp, 1.0_dp, 0.1_dp]; k = 2; h = 1.0e-6_dp
  call softmax(z, p)
  onehot = 0.0_dp; onehot(k) = 1.0_dp
  g = p - onehot
  print '(A,3F10.6)', 'p            = ', p
  print '(A,F10.6)',  'kayip -log p2= ', -log(p(k))
  do i = 1, 3
    zz = z; zz(i) = z(i) + h; call softmax(zz, pp); lp = -log(pp(k))
    zz = z; zz(i) = z(i) - h; call softmax(zz, pp); lm = -log(pp(k))
    gn(i) = (lp - lm) / (2*h)
  end do
  print '(A,3F10.6)', 'grad p-onehot= ', g
  print '(A,3F10.6)', 'sayisal grad = ', gn
  big = [1000.0_dp, 1001.0_dp, 1002.0_dp]
  naive = exp(big) / sum(exp(big))           ! exp(1000) tasar -> Inf/Inf = NaN
  call softmax(big, stable)
  print '(A,3F10.6)', 'saf softmax  = ', naive
  print '(A,3F10.6)', 'kararli      = ', stable
contains
  subroutine softmax(a, q)
    real(dp), intent(in)  :: a(:)
    real(dp), intent(out) :: q(:)
    q = exp(a - maxval(a))                   ! en buyuk deger 0 olur, tasma yok
    q = q / sum(q)
  end subroutine softmax
end program smax
