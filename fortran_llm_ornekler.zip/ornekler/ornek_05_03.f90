! Örnek 5.3: Bloklu (tiled) matris çarpımı
! Derleme: gfortran -O2  ornek_05_03.f90 -o ornek
program tiled
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 1024, bs = 64
  real(dp), allocatable :: A(:,:), B(:,:), C1(:,:), C2(:,:)
  real(dp) :: t0, t1, t2, fl
  integer :: i, j, k, ii, jj, kk
  allocate(A(n,n), B(n,n), C1(n,n), C2(n,n))
  call random_number(A); call random_number(B)
  fl = 2.0_dp * real(n, dp)**3
  C1 = 0.0_dp; t0 = now()
  do j = 1, n
    do k = 1, n
      do i = 1, n
        C1(i,j) = C1(i,j) + A(i,k) * B(k,j)
      end do
    end do
  end do
  t1 = now()
  C2 = 0.0_dp
  do jj = 1, n, bs                                   ! bloklar
    do kk = 1, n, bs
      do ii = 1, n, bs
        do j = jj, min(jj+bs-1, n)                   ! blok icinde jki
          do k = kk, min(kk+bs-1, n)
            do i = ii, min(ii+bs-1, n)
              C2(i,j) = C2(i,j) + A(i,k) * B(k,j)
            end do
          end do
        end do
      end do
    end do
  end do
  t2 = now()
  print '(A,F8.3,A,F7.2,A)', 'jki     : ', t1-t0, ' s  ', fl/(t1-t0)/1.0e9_dp, ' GFLOP/s'
  print '(A,F8.3,A,F7.2,A)', 'bloklu  : ', t2-t1, ' s  ', fl/(t2-t1)/1.0e9_dp, ' GFLOP/s'
  print '(A,ES10.2)', 'max fark = ', maxval(abs(C1 - C2))
contains
  function now() result(t)
    integer(8) :: c, r
    real(dp) :: t
    call system_clock(c, r)
    t = real(c, dp) / real(r, dp)
  end function now
end program tiled
