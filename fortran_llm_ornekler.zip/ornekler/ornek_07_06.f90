! Örnek 7.6: Token akışını paketle, ikili dosyaya yaz, rastgele erişimle oku
! Derleme: gfortran -O2  ornek_07_06.f90 -o ornek
program paketleme
  implicit none
  integer, parameter :: T = 4, EOS = 1
  integer :: d1(3) = [5, 6, 7], d2(2) = [8, 9], d3(5) = [10, 11, 12, 13, 14]
  integer(4), allocatable :: stream(:)
  integer(4) :: x(T), y(T)
  integer :: u, n, k, i, nseq
  integer(8) :: fsize
  stream = [d1, EOS, d2, EOS, d3, EOS]              ! belgeleri EOS ile birlestir
  n = size(stream)
  open(newunit=u, file='veri.bin', access='stream', form='unformatted', status='replace')
  write(u) stream
  close(u)
  open(newunit=u, file='veri.bin', access='stream', form='unformatted', status='old')
  inquire(unit=u, size=fsize)
  print '(A,I0,A,I0,A)', 'akis uzunlugu = ', n, ' token, dosya = ', fsize, ' bayt'
  nseq = (n - 1) / T
  do k = 0, nseq - 1
    i = k * T                                       ! 0 tabanli token konumu
    read(u, pos=4*i + 1) x                          ! her token 4 bayt
    read(u, pos=4*(i+1) + 1) y                      ! bir token kaydirilmis hedef
    print '(A,4I4,A,4I4)', 'x =', x, '   y =', y
  end do
  close(u)
end program paketleme
