# Örnek 9.7: Online softmax: blok blok attention, aynı sonuç (PyTorch karşılığı)
import torch, torch.nn.functional as F
torch.manual_seed(31)
n, dv, bs = 10, 3, 3
s = 2 * torch.randn(n, dtype=torch.float64); V = torch.randn(n, dv, dtype=torch.float64)
o_ref = torch.softmax(s, 0) @ V                          # standart: tum skorlar bellekte
m = torch.tensor(-float("inf"), dtype=torch.float64); l = torch.tensor(0.0, dtype=torch.float64)
acc = torch.zeros(dv, dtype=torch.float64)
for i0 in range(0, n, bs):                               # online softmax: blok blok
    sb, vb = s[i0:i0 + bs], V[i0:i0 + bs]
    mnew = torch.maximum(m, sb.max())
    scale = torch.exp(m - mnew)                          # eski birikimi duzelt
    e = torch.exp(sb - mnew)
    l = l * scale + e.sum(); acc = acc * scale + e @ vb; m = mnew
    print(f"blok {i0+1:2d}-{min(i0+bs, n):2d}  kosan max={m:8.4f}  kosan toplam={l:8.4f}")
o = acc / l
print("standart  :", [round(v, 6) for v in o_ref.tolist()])
print("online    :", [round(v, 6) for v in o.tolist()])
print("fark =", (o - o_ref).abs().max().item())
q = torch.randn(1, 1, 1, 8); k = torch.randn(1, 1, 5, 8); v = torch.randn(1, 1, 5, 8)
print("F.scaled_dot_product_attention (GPU'da FlashAttention cekirdegi kullanir):",
      tuple(F.scaled_dot_product_attention(q, k, v).shape))

