! Örnek 5.8: Aktivasyon yeniden hesaplama ile aynı gradyan
! Derleme: gfortran -O2  ornek_05_08.f90 -o ornek
program checkpointing
  implicit none
  integer, parameter :: dp = kind(1.0d0), L = 64, seg = 8
  real(dp) :: w(L), y(0:L), dw1(L), dw2(L), cp(0:L/seg), ys(0:seg)
  real(dp) :: dy, dz, yy
  integer :: k, s, j, k0, nrecomp
  do k = 1, L
    w(k) = 0.9_dp + 0.2_dp * sin(real(k, dp))
  end do
  ! (1) hepsini sakla
  y(0) = 0.5_dp
  do k = 1, L
    y(k) = tanh(w(k) * y(k-1))
  end do
  dy = 1.0_dp
  do k = L, 1, -1
    dz = dy * (1.0_dp - y(k)**2)
    dw1(k) = dz * y(k-1)
    dy = dz * w(k)
  end do
  ! (2) yalniz kontrol noktalari
  yy = 0.5_dp; cp(0) = yy
  do k = 1, L
    yy = tanh(w(k) * yy)
    if (mod(k, seg) == 0) cp(k/seg) = yy
  end do
  dy = 1.0_dp; nrecomp = 0
  do s = L/seg, 1, -1
    k0 = (s-1) * seg
    ys(0) = cp(s-1)
    do j = 1, seg                              ! segmenti yeniden hesapla
      ys(j) = tanh(w(k0+j) * ys(j-1)); nrecomp = nrecomp + 1
    end do
    do j = seg, 1, -1                          ! segmentin geri gecisi
      k = k0 + j
      dz = dy * (1.0_dp - ys(j)**2)
      dw2(k) = dz * ys(j-1)
      dy = dz * w(k)
    end do
  end do
  print '(A,ES10.2)', 'max |dw1 - dw2|            = ', maxval(abs(dw1 - dw2))
  print '(A,I0)', 'normal : saklanan aktivasyon = ', L + 1
  print '(A,I0)', 'ckpt   : saklanan (en fazla) = ', L/seg + 1 + seg + 1
  print '(A,I0,A,I0,A)', 'ekstra ileri hesap = ', nrecomp, ' adim (normal ileri gecis: ', L, ')'
end program checkpointing
