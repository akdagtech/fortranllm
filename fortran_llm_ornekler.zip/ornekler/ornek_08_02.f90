! Örnek 8.2: Mini-batch gradyanının gürültüsü ~ 1/√B
! Derleme: gfortran -O2  ornek_08_02.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program batch_gurultu
  use rng_mod
  implicit none
  integer, parameter :: N = 10000, ntr = 2000
  integer, parameter :: bsz(4) = [1, 4, 16, 64]
  real(dp) :: x(N), y(N), gi(N), s1, s2, gm, mean_, sd
  integer :: ib, tr, k, i
  call rng_seed(17)
  do i = 1, N
    x(i) = gauss()
    y(i) = 2.0_dp * x(i) + 0.5_dp * gauss()
  end do
  gi = 2.0_dp * (0.0_dp * x - y) * x               ! w = 0 iken ornek basina gradyan
  print '(A,F9.4)', 'tam veri gradyani = ', sum(gi) / N
  print '(A)', '    B     ortalama     std      std*sqrt(B)'
  do ib = 1, 4
    s1 = 0.0_dp; s2 = 0.0_dp
    do tr = 1, ntr
      gm = 0.0_dp
      do k = 1, bsz(ib)
        i = 1 + int(uniform() * N)                 ! rastgele ornek
        gm = gm + gi(i)
      end do
      gm = gm / bsz(ib)                            ! mini-batch ortalamasi
      s1 = s1 + gm; s2 = s2 + gm**2
    end do
    mean_ = s1 / ntr
    sd = sqrt(s2 / ntr - mean_**2)
    print '(I5,3F11.4)', bsz(ib), mean_, sd, sd * sqrt(real(bsz(ib), dp))
  end do
end program batch_gurultu
