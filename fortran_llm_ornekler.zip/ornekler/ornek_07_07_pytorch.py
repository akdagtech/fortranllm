# Örnek 7.7: E-posta adreslerini maskele (PII temizliği) (PyTorch karşılığı)
import re
s = "Bana ali.veli@ornek.com adresinden yaz, ya da mehmet@site.org kullan."
t = re.sub(r"[\w.+-]+@[\w-]+\.[\w.]+(?<![.,])", "<EMAIL>", s)
print("once  :", s)
print("sonra :", t)

