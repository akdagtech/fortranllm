# Örnek 15.1: Molekül → graf: RDKit, komşuluk matrisi ve spektrum
import numpy as np
from rdkit import Chem

for ad, smi in [("etanol", "CCO"), ("butadien", "C=CC=C"), ("benzen", "c1ccccc1"),
                ("siklopropan x2", "C1CC1.C1CC1")]:
    m = Chem.MolFromSmiles(smi)
    A = Chem.GetAdjacencyMatrix(m).astype(float)          # komsuluk matrisi (agir atomlar)
    deg = A.sum(1)
    L = np.diag(deg) - A                                  # graf Laplasyeni L = D - A
    print(f"--- {ad} ({smi}):  {m.GetNumAtoms()} agir atom, {m.GetNumBonds()} bag")
    print("  atomlar     :", [a.GetSymbol() for a in m.GetAtoms()])
    ei = [(b.GetBeginAtomIdx(), b.GetEndAtomIdx()) for b in m.GetBonds()]
    print("  kenar listesi:", ei, "  (PyG: edge_index, her kenar iki yonlu)")
    print("  derece      :", deg.astype(int).tolist())
    print("  A ozdegerleri:", np.round(np.sort(np.linalg.eigvalsh(A))[::-1], 3).tolist())
    ev = np.linalg.eigvalsh(L)
    print("  L ozdegerleri:", np.round(ev, 3).tolist(), "  sifir ozdeger sayisi =", int((ev < 1e-9).sum()), "(= bagli bilesen sayisi)")
