! Örnek 9.3: Eğitim süresi tahmini: 6ND kuralı
! Derleme: gfortran -O2  ornek_09_03.f90 -o ornek
program flop_hesap
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp), parameter :: peak = 312.0e12_dp, mfu = 0.40_dp
  call tahmin('124M, 20 token/param ', 124.0e6_dp, 20.0_dp*124.0e6_dp)
  call tahmin('124M, 300B token     ', 124.0e6_dp, 300.0e9_dp)
  call tahmin('7B, 1T token         ', 7.0e9_dp, 1.0e12_dp)
contains
  subroutine tahmin(ad, n, d)
    character(len=*), intent(in) :: ad
    real(dp), intent(in) :: n, d
    real(dp) :: flop, sec
    flop = 6.0_dp * n * d
    sec  = flop / (peak * mfu)                     ! tek GPU icin saniye
    print '(A,A,ES10.2,A,F9.1,A,F8.2,A)', ad, ' FLOP=', flop, '   GPU-gun=', sec/86400.0_dp, &
          '   256 GPU ile ', sec/86400.0_dp/256.0_dp, ' gun'
  end subroutine tahmin
end program flop_hesap
