# Örnek 3.3: Kötü koşullanmış yüzeyde GD, Momentum ve Adam (PyTorch karşılığı)
import torch
def run(make_opt, steps=200):
    p = torch.tensor([5.0, 5.0], dtype=torch.float64, requires_grad=True)
    opt = make_opt([p]); hist = {}
    for k in range(1, steps + 1):
        f = p[0] ** 2 + 100 * p[1] ** 2
        opt.zero_grad(); f.backward(); opt.step()
        if k in (1, 10, 20, 50, 100, 200):
            hist[k] = (p[0] ** 2 + 100 * p[1] ** 2).item()
    return hist
gd  = run(lambda ps: torch.optim.SGD(ps, lr=0.0099))
mo  = run(lambda ps: torch.optim.SGD(ps, lr=0.01, momentum=0.9))
ad  = run(lambda ps: torch.optim.Adam(ps, lr=0.3))
print("  adim          GD      Momentum          Adam")
for k in gd: print(f"{k:6d}{gd[k]:14.3e}{mo[k]:14.3e}{ad[k]:14.3e}")

