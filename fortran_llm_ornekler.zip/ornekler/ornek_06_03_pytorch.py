# Örnek 6.3: Türkçeye uygun küçük harf dönüşümü (PyTorch karşılığı)
import re, unicodedata
s = "ISTANBUL  İzmir   ÇAY  Şeker"
print("girdi          :", s)
print("naif .lower()  :", s.lower())          # Python 'I' -> 'i' yapar, 'İ' -> 'i̇' (birlesik nokta!)
def tr_lower(x):
    x = x.replace("İ", "i").replace("I", "ı")
    return x.lower()
t = re.sub(r"\s+", " ", tr_lower(s))
print("Turkce kurali  :", t)
print("NFC normalize  :", unicodedata.normalize("NFC", "i\u0307") == "\u0130".lower())

