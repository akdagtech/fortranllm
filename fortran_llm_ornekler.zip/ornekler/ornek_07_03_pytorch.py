# Örnek 7.3: Birebir tekrarları hash ile bul (PyTorch karşılığı)
import hashlib, re
docs = ["Bugun hava cok guzel.", "Yarin yagmur yagacak.", "BUGUN   hava  cok guzel.",
        "Model egitimi icin veri gerekir.", "yarin yagmur yagacak.", "Bugun hava cok kotu."]
norm = lambda s: re.sub(r"\s+", " ", s.lower()).strip()
seen = {}
for j, d in enumerate(docs, 1):
    h = hashlib.sha1(norm(d).encode()).hexdigest()[:12]
    if h in seen: print(f"belge {j} = belge {seen[h]} kopyasi   hash={h}")
    else: seen[h] = j
print(f"toplam {len(docs)} belge, tekil {len(seen)}")

