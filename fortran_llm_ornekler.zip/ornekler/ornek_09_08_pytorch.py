# Örnek 9.8: INT8 ve INT4 quantization: aykırı değer sorunu (PyTorch karşılığı)
import torch
torch.manual_seed(8)
w = 0.05 * torch.randn(16); w[4] = 0.60                  # aykiri deger
def quant(w, bits, gs):
    qmax = 2 ** (bits - 1) - 1
    g = w.view(-1, gs)
    sc = g.abs().amax(1, keepdim=True) / qmax
    return (sc * torch.clamp(torch.round(g / sc), -qmax, qmax)).view(-1)
rms = lambda a: a.pow(2).mean().sqrt().item()
print(f"agirlik RMS      = {rms(w):.4f}")
for bits in (8, 4):
    for gs, ad in [(16, "per-tensor  "), (4, "per-group(4)")]:
        print(f"INT{bits} {ad} RMS hata = {rms(w - quant(w, bits, gs)):.2e}")

