! Örnek 1.4: Sayısal türev ve adım boyutu h
! Derleme: gfortran -O2  ornek_01_04.f90 -o ornek
program turev
  implicit none
  integer, parameter :: dp = kind(1.0d0)
  real(dp) :: x, h, num, ana
  integer :: k
  x = 2.0_dp
  ana = 3.0_dp * x**2
  do k = 1, 12, 1
    h = 10.0_dp**(-k)
    num = ((x+h)**3 - (x-h)**3) / (2.0_dp*h)
    print '(A,ES8.1,A,F16.10,A,ES9.2)', 'h=', h, '  turev=', num, '  hata=', abs(num-ana)
  end do
end program turev
