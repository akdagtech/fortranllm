# Örnek 5.6: Toplama hassasiyeti ve BF16 yuvarlama (PyTorch karşılığı)
import torch
x = torch.full((10_000_000,), 1e-4, dtype=torch.float32)
print("(a) FP32 sirali toplam (cumsum):", round(torch.cumsum(x, 0)[-1].item(), 4))
print("    FP32 torch.sum (ikili agac): ", round(x.sum().item(), 4), "  <- kutuphane daha akilli toplar")
print("    FP64 toplam                : ", round(x.double().sum().item(), 4))
pi = torch.tensor(3.14159265, dtype=torch.float32)
bf = pi.to(torch.bfloat16).float()
print(f"(b) pi FP32={pi.item():.7f}  BF16={bf.item():.7f}  bagil hata={abs(bf - pi).item() / pi.item():.2e}")
print("    epsilon FP32 =", torch.finfo(torch.float32).eps, "  BF16 =", torch.finfo(torch.bfloat16).eps,
      "  FP16 =", torch.finfo(torch.float16).eps)
xb = torch.tensor(0.01).to(torch.bfloat16)
sbf = torch.tensor(0.0, dtype=torch.bfloat16); s32 = torch.tensor(0.0, dtype=torch.float32)
for _ in range(1000):
    sbf = sbf + xb                               # BF16 akumulator (her toplama BF16'ya yuvarlanir)
    s32 = s32 + xb.float()                       # FP32 akumulator
print("(c) BF16 akumulator :", round(sbf.float().item(), 4))
print("    FP32 akumulator :", round(s32.item(), 4))

