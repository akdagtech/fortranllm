# Örnek 3.4: Adam'ın ilk adımları: bias düzeltmesi neden gerekli? (PyTorch karşılığı)
import torch
theta = torch.tensor(1.0, dtype=torch.float64, requires_grad=True)
opt = torch.optim.Adam([theta], lr=0.1, betas=(0.9, 0.999), eps=1e-8)
print(" t        m          s          mhat       shat       adim    theta")
for t in range(1, 5):
    theta.grad = torch.tensor(0.5, dtype=torch.float64)    # sabit gradyan
    before = theta.item()
    opt.step()
    st = opt.state[theta]
    m, s = st['exp_avg'].item(), st['exp_avg_sq'].item()
    mh, sh = m / (1 - 0.9 ** t), s / (1 - 0.999 ** t)
    print(f"{t:2d}{m:11.6f}{s:11.6f}{mh:11.6f}{sh:11.6f}{before - theta.item():11.6f}{theta.item():11.6f}")

