! Örnek 1.2: Modül ve eleman bazlı fonksiyon: sigmoid
! Derleme: gfortran -O2  ornek_01_02.f90 -o ornek
module aktivasyon
  implicit none
  integer, parameter :: dp = kind(1.0d0)
contains
  elemental function sigmoid(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = 1.0_dp / (1.0_dp + exp(-x))
  end function sigmoid
end module aktivasyon

program ornek
  use aktivasyon
  implicit none
  real(dp) :: x(5)
  integer :: i
  x = [-2.0_dp, -1.0_dp, 0.0_dp, 1.0_dp, 2.0_dp]
  do i = 1, size(x)
    print '(A,F5.1,A,F8.4)', 'sigmoid(', x(i), ') = ', sigmoid(x(i))
  end do
  print '(A,5F8.4)', 'hepsi birden: ', sigmoid(x)
end program ornek
