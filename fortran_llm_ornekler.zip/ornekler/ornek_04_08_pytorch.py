# Örnek 4.8: Tam bir Transformer bloğu (PyTorch karşılığı)
import torch, torch.nn as nn
import torch.nn.functional as F

class Block(nn.Module):                     # pre-norm, RMSNorm'lu Transformer blogu
    def __init__(self, d, nh):
        super().__init__()
        self.nh = nh
        self.n1, self.n2 = nn.RMSNorm(d, eps=1e-5), nn.RMSNorm(d, eps=1e-5)
        self.qkv = nn.Linear(d, 3 * d, bias=False)
        self.proj = nn.Linear(d, d, bias=False)
        self.ffn = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(approximate='tanh'), nn.Linear(4 * d, d))
    def forward(self, x):                   # x: (B, T, d)
        B, T, d = x.shape
        q, k, v = self.qkv(self.n1(x)).chunk(3, dim=-1)
        q, k, v = (t.view(B, T, self.nh, d // self.nh).transpose(1, 2) for t in (q, k, v))
        a = F.scaled_dot_product_attention(q, k, v, is_causal=True)   # causal multi-head attention
        x = x + self.proj(a.transpose(1, 2).reshape(B, T, d))         # residual 1
        return x + self.ffn(self.n2(x))                               # residual 2

torch.manual_seed(4)
blk = Block(8, 2)
for p in blk.parameters():
    if p.dim() > 1: nn.init.normal_(p, std=0.3)
X = torch.randn(1, 6, 8)
X2 = X.clone(); X2[0, -1] -= 3.0
Y1, Y2 = blk(X), blk(X2)
print("onceki satirlarin degisimi =", f"{(Y1[0, :-1] - Y2[0, :-1]).abs().max().item():.2e}")
print("giris RMS =", round(X.pow(2).mean().sqrt().item(), 4))
print("cikis RMS =", round(Y1.pow(2).mean().sqrt().item(), 4))

