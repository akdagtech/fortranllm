! Örnek 6.5: Embedding tablosu, özel tokenlar ve padding
! Derleme: gfortran -O2  ornek_06_05.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program ozel_tokenlar
  use rng_mod
  implicit none
  integer, parameter :: V = 10, d = 4, B = 3, T = 5
  character(len=6) :: vocab(0:V-1)
  integer :: ids(B,T), b1, t1, cnt
  logical :: mask(B,T)
  real(dp) :: E(V,d), pooled(d)
  vocab = [character(len=6) :: '<PAD>', '<BOS>', '<EOS>', 'ev', 'ler', 'de', &
                               'kitap', 'oku', 'du', 'm']
  ! diziler: [BOS ev ler de EOS], [BOS kitap EOS], [BOS oku du m EOS]
  ids = reshape([1,3,4,5,2,  1,6,2,0,0,  1,7,8,9,2], [B,T], order=[2,1])
  mask = (ids /= 0)                               ! PAD olmayan konumlar
  call rng_seed(3)
  call randn2(E, 1.0_dp)
  E(1,:) = 0.0_dp                                 ! PAD embedding'i sifir (padding_idx)
  do b1 = 1, B
    write(*,'(A,I1,A)', advance='no') 'dizi ', b1, ': '
    do t1 = 1, T
      if (mask(b1,t1)) write(*,'(A,A)', advance='no') trim(vocab(ids(b1,t1))), ' '
    end do
    print *
  end do
  print '(A)', 'ids (0 = PAD):'
  do b1 = 1, B
    print '(5I4)', ids(b1,:)
  end do
  print '(A)', 'maske:'
  do b1 = 1, B
    print '(5L4)', mask(b1,:)
  end do
  do b1 = 1, B                                    ! maskeli ortalama (mean pooling)
    pooled = 0.0_dp; cnt = 0
    do t1 = 1, T
      if (mask(b1,t1)) then
        pooled = pooled + E(ids(b1,t1)+1, :)
        cnt = cnt + 1
      end if
    end do
    print '(A,I1,A,I1,A,4F8.3)', 'dizi ', b1, ' (', cnt, ' token) ort: ', pooled / cnt
  end do
end program ozel_tokenlar
