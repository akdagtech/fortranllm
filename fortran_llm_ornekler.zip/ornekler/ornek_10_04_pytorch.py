# Örnek 10.4: Dağılımdan örnekleme (ters CDF) ve doğrulama (PyTorch karşılığı)
import torch
torch.manual_seed(77)
p = torch.tensor([0.5, 0.3, 0.15, 0.05])
draw = torch.multinomial(p, 20000, replacement=True)     # ters CDF ile ayni mantik
print("gercek p    :", [round(v, 4) for v in p.tolist()])
print("deneysel    :", [round(v, 4) for v in (torch.bincount(draw, minlength=4) / 20000).tolist()])

