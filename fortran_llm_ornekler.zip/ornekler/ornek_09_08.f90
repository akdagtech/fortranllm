! Örnek 9.8: INT8 ve INT4 quantization: aykırı değer sorunu
! Derleme: gfortran -O2  ornek_09_08.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

program kuantizasyon
  use rng_mod
  implicit none
  integer, parameter :: n = 16
  real(dp) :: w(n), dq(n)
  call rng_seed(8)
  call randn1(w, 0.05_dp)
  w(5) = 0.60_dp                                    ! aykiri deger
  print '(A,F8.4)', 'agirlik RMS      = ', sqrt(sum(w**2) / n)
  call quantize(w, 8, n, dq)
  print '(A,ES10.2)', 'INT8 per-tensor   RMS hata = ', sqrt(sum((w-dq)**2) / n)
  call quantize(w, 8, 4, dq)
  print '(A,ES10.2)', 'INT8 per-group(4) RMS hata = ', sqrt(sum((w-dq)**2) / n)
  call quantize(w, 4, n, dq)
  print '(A,ES10.2)', 'INT4 per-tensor   RMS hata = ', sqrt(sum((w-dq)**2) / n)
  call quantize(w, 4, 4, dq)
  print '(A,ES10.2)', 'INT4 per-group(4) RMS hata = ', sqrt(sum((w-dq)**2) / n)
contains
  subroutine quantize(w, bits, gs, deq)
    real(dp), intent(in)  :: w(:)
    integer, intent(in)   :: bits, gs
    real(dp), intent(out) :: deq(:)
    integer :: i0, i1, qmax
    real(dp) :: sc
    qmax = 2**(bits - 1) - 1                        ! INT8: 127, INT4: 7
    do i0 = 1, size(w), gs
      i1 = min(i0 + gs - 1, size(w))
      sc = maxval(abs(w(i0:i1))) / qmax
      if (sc == 0.0_dp) sc = 1.0_dp
      deq(i0:i1) = sc * real(max(-qmax, min(qmax, nint(w(i0:i1) / sc))), dp)
    end do
  end subroutine quantize
end program kuantizasyon
