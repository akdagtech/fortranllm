! Örnek 5.5: Bellek bant genişliğini ölç (vector triad)
! Derleme: gfortran -O2  ornek_05_05.f90 -o ornek
program triad
  implicit none
  integer, parameter :: dp = kind(1.0d0), n = 10000000, nrep = 10
  real(dp), allocatable :: a(:), b(:), c(:)
  real(dp) :: s, t0, t1, bytes, ai
  integer :: i, r
  allocate(a(n), b(n), c(n))
  b = 1.0_dp; c = 2.0_dp; a = 0.0_dp; s = 3.0_dp
  t0 = now()
  do r = 1, nrep
    do i = 1, n
      a(i) = b(i) + s * c(i)
    end do
    b(1) = a(n) * 1.0e-12_dp           ! derleyicinin dongu atlamasini engelle
  end do
  t1 = now()
  bytes = real(nrep, dp) * 3.0_dp * 8.0_dp * real(n, dp)   ! 2 okuma + 1 yazma
  ai = 2.0_dp / 24.0_dp                                    ! 2 FLOP / 24 bayt
  print '(A,F8.2,A)', 'bant genisligi        : ', bytes/(t1-t0)/1.0e9_dp, ' GB/s'
  print '(A,F8.4)',   'aritmetik yogunluk    : ', ai
  print '(A,F8.2,A)', 'ulasilan performans   : ', ai * bytes/(t1-t0)/1.0e9_dp, ' GFLOP/s'
contains
  function now() result(t)
    integer(8) :: cnt, rate
    real(dp) :: t
    call system_clock(cnt, rate)
    t = real(cnt, dp) / real(rate, dp)
  end function now
end program triad
