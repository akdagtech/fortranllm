# Örnek 1.6: Kısmi türevler ve gradyanın yönü (PyTorch karşılığı)
import torch
xy = torch.tensor([1.0, 2.0], dtype=torch.float64, requires_grad=True)
f = lambda v: v[0]**2 + 3*v[0]*v[1] + v[1]**2
f(xy).backward()
g = xy.grad
print("autograd grad =", [round(v, 4) for v in g.tolist()])
u = g / g.norm()                           # gradyan yonunde birim vektor
h = 1e-6
d1 = (f(xy.detach() + h*u) - f(xy.detach())) / h
d2 = (f(xy.detach() + h*torch.tensor([1., 0.], dtype=torch.float64)) - f(xy.detach())) / h
print(f"|grad|                  = {g.norm():.4f}")
print(f"gradyan yonundeki egim  = {d1:.4f}")
print(f"x ekseni yonundeki egim = {d2:.4f}")

