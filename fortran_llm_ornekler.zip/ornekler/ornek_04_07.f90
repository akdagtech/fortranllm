! Örnek 4.7: FFN ve residual bağlantı
! Derleme: gfortran -O2  ornek_04_07.f90 -o ornek
module prec_mod
  implicit none
  integer, parameter :: dp = kind(1.0d0)
end module prec_mod

module rng_mod
  use prec_mod
  implicit none
  integer(8), save :: rng_state = 12345_8
contains
  subroutine rng_seed(s)
    integer, intent(in) :: s
    rng_state = int(s, 8)
  end subroutine rng_seed

  function uniform() result(u)          ! (0,1) arasi duzgun sayi
    real(dp) :: u
    rng_state = mod(rng_state * 1103515245_8 + 12345_8, 2147483648_8)
    u = (real(rng_state, dp) + 0.5_dp) / 2147483648.0_dp
  end function uniform

  function gauss() result(g)            ! standart normal (Box-Muller)
    real(dp) :: g, u1, u2
    u1 = uniform()
    u2 = uniform()
    g = sqrt(-2.0_dp * log(u1)) * cos(6.283185307179586_dp * u2)
  end function gauss

  subroutine randn1(a, s)               ! vektoru N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:)
    real(dp), intent(in) :: s
    integer :: i
    do i = 1, size(a)
      a(i) = s * gauss()
    end do
  end subroutine randn1

  subroutine randn2(a, s)               ! matrisi N(0, s^2) ile doldur
    real(dp), intent(out) :: a(:,:)
    real(dp), intent(in) :: s
    integer :: i, j
    do j = 1, size(a,2)
      do i = 1, size(a,1)
        a(i,j) = s * gauss()
      end do
    end do
  end subroutine randn2
end module rng_mod

module ffn_mod
  use prec_mod
  implicit none
contains
  elemental function gelu(x) result(y)
    real(dp), intent(in) :: x
    real(dp) :: y
    y = 0.5_dp * x * (1.0_dp + tanh(0.7978845608028654_dp * (x + 0.044715_dp * x**3)))
  end function gelu

  subroutine ffn(X, W1, b1, W2, b2, Y)
    real(dp), intent(in)  :: X(:,:), W1(:,:), b1(:), W2(:,:), b2(:)
    real(dp), intent(out) :: Y(:,:)
    real(dp), allocatable :: Hd(:,:)
    integer :: T
    T = size(X,1)
    allocate(Hd(T, size(W1,2)))
    Hd = gelu(matmul(X, W1) + spread(b1, 1, T))
    Y  = matmul(Hd, W2) + spread(b2, 1, T)
  end subroutine ffn
end module ffn_mod

program ffn_test
  use rng_mod
  use ffn_mod
  implicit none
  integer, parameter :: T = 3, d = 4
  real(dp) :: X(T,d), W1(d,4*d), b1(4*d), W2(4*d,d), b2(d), Y(T,d)
  call rng_seed(2)
  call randn2(X, 1.0_dp)
  call randn2(W1, 0.02_dp); call randn2(W2, 0.02_dp)
  b1 = 0.0_dp; b2 = 0.0_dp
  call ffn(X, W1, b1, W2, b2, Y)
  print '(A,ES10.2)', '|FFN(x)| en buyuk eleman        = ', maxval(abs(Y))
  print '(A,ES10.2)', '|x + FFN(x) - x| en buyuk fark   = ', maxval(abs((X + Y) - X))
  print '(A,I0)', 'parametre sayisi        = ', size(W1) + size(b1) + size(W2) + size(b2)
  print '(A,I0)', '8*d^2 + 5*d             = ', 8*d*d + 5*d
end program ffn_test
