# Örnek 5.1: Döngü sırası: i-dış mı, j-dış mı? (PyTorch karşılığı)
import torch, time
torch.set_num_threads(1)
n = 3000
a = torch.ones(n, n, dtype=torch.float64)
def tm(fn, rep=5):
    fn(); t0 = time.perf_counter()
    for _ in range(rep): fn()
    return (time.perf_counter() - t0) / rep
# PyTorch dizileri SATIR-ANA (C duzeni) saklar: Fortran'in tersi!
t_contig = tm(lambda: a * 1.0001 + 1.0)                 # bellekte ardisik gezinme
t_strided = tm(lambda: a.t() * 1.0001 + 1.0)            # transpoze gorunum: bellekte n adim atlayarak
print(f"ardisik erisim  : {t_contig:8.3f} s")
print(f"atlamali erisim : {t_strided:8.3f} s")
print(f"fark            : {t_strided / t_contig:8.1f} kat")
print("a.stride() =", a.stride(), "  a.t().stride() =", a.t().stride())

