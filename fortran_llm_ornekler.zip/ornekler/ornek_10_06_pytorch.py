# Örnek 10.6: KV cache belleği ve kayan pencere (sliding window) (PyTorch karşılığı)
kv = lambda L, T, d, b: 2 * L * T * d * b
print(f"GPT-2 small (L=12,  d=768,  T=1024): {kv(12,1024,768,2)/1e6:9.1f} MB")
print(f"7B tipi     (L=32,  d=4096, T=4096): {kv(32,4096,4096,2)/1e9:9.2f} GB")
print(f"70B tipi    (L=80,  d=8192, T=4096): {kv(80,4096,8192,2)/1e9:9.2f} GB")
W = 8
toks = list(range(100, 112))
print("pencere = 8 token, BOS (ilk token) her zaman korunur:")
for t in range(8, 13):
    ctx = toks[:t] if t <= W else [toks[0]] + toks[t - W + 1:t]
    print(f"adim {t:2d} :", " ".join(f"{v:4d}" for v in ctx))

